gdjs.fonsCode = {};
gdjs.fonsCode.GDbackObjects1_1final = [];

gdjs.fonsCode.GDl_9595buttonObjects1_1final = [];

gdjs.fonsCode.GDr_9595buttonObjects1_1final = [];

gdjs.fonsCode.GDfon0Objects1= [];
gdjs.fonsCode.GDfon0Objects2= [];
gdjs.fonsCode.GDfon0Objects3= [];
gdjs.fonsCode.GDfon0Objects4= [];
gdjs.fonsCode.GDfon1Objects1= [];
gdjs.fonsCode.GDfon1Objects2= [];
gdjs.fonsCode.GDfon1Objects3= [];
gdjs.fonsCode.GDfon1Objects4= [];
gdjs.fonsCode.GDfon2Objects1= [];
gdjs.fonsCode.GDfon2Objects2= [];
gdjs.fonsCode.GDfon2Objects3= [];
gdjs.fonsCode.GDfon2Objects4= [];
gdjs.fonsCode.GDfon3Objects1= [];
gdjs.fonsCode.GDfon3Objects2= [];
gdjs.fonsCode.GDfon3Objects3= [];
gdjs.fonsCode.GDfon3Objects4= [];
gdjs.fonsCode.GDfon4Objects1= [];
gdjs.fonsCode.GDfon4Objects2= [];
gdjs.fonsCode.GDfon4Objects3= [];
gdjs.fonsCode.GDfon4Objects4= [];
gdjs.fonsCode.GDfon5Objects1= [];
gdjs.fonsCode.GDfon5Objects2= [];
gdjs.fonsCode.GDfon5Objects3= [];
gdjs.fonsCode.GDfon5Objects4= [];
gdjs.fonsCode.GDpickerObjects1= [];
gdjs.fonsCode.GDpickerObjects2= [];
gdjs.fonsCode.GDpickerObjects3= [];
gdjs.fonsCode.GDpickerObjects4= [];
gdjs.fonsCode.GDlockerObjects1= [];
gdjs.fonsCode.GDlockerObjects2= [];
gdjs.fonsCode.GDlockerObjects3= [];
gdjs.fonsCode.GDlockerObjects4= [];
gdjs.fonsCode.GDcostObjects1= [];
gdjs.fonsCode.GDcostObjects2= [];
gdjs.fonsCode.GDcostObjects3= [];
gdjs.fonsCode.GDcostObjects4= [];
gdjs.fonsCode.GDtext_9595pickObjects1= [];
gdjs.fonsCode.GDtext_9595pickObjects2= [];
gdjs.fonsCode.GDtext_9595pickObjects3= [];
gdjs.fonsCode.GDtext_9595pickObjects4= [];
gdjs.fonsCode.GDbuyObjects1= [];
gdjs.fonsCode.GDbuyObjects2= [];
gdjs.fonsCode.GDbuyObjects3= [];
gdjs.fonsCode.GDbuyObjects4= [];
gdjs.fonsCode.GDgrass_9595blockObjects1= [];
gdjs.fonsCode.GDgrass_9595blockObjects2= [];
gdjs.fonsCode.GDgrass_9595blockObjects3= [];
gdjs.fonsCode.GDgrass_9595blockObjects4= [];
gdjs.fonsCode.GDblockObjects1= [];
gdjs.fonsCode.GDblockObjects2= [];
gdjs.fonsCode.GDblockObjects3= [];
gdjs.fonsCode.GDblockObjects4= [];
gdjs.fonsCode.GDmenuObjects1= [];
gdjs.fonsCode.GDmenuObjects2= [];
gdjs.fonsCode.GDmenuObjects3= [];
gdjs.fonsCode.GDmenuObjects4= [];
gdjs.fonsCode.GDhomeObjects1= [];
gdjs.fonsCode.GDhomeObjects2= [];
gdjs.fonsCode.GDhomeObjects3= [];
gdjs.fonsCode.GDhomeObjects4= [];
gdjs.fonsCode.GDresetObjects1= [];
gdjs.fonsCode.GDresetObjects2= [];
gdjs.fonsCode.GDresetObjects3= [];
gdjs.fonsCode.GDresetObjects4= [];
gdjs.fonsCode.GDspikeObjects1= [];
gdjs.fonsCode.GDspikeObjects2= [];
gdjs.fonsCode.GDspikeObjects3= [];
gdjs.fonsCode.GDspikeObjects4= [];
gdjs.fonsCode.GDend_9595homeObjects1= [];
gdjs.fonsCode.GDend_9595homeObjects2= [];
gdjs.fonsCode.GDend_9595homeObjects3= [];
gdjs.fonsCode.GDend_9595homeObjects4= [];
gdjs.fonsCode.GDend_9595resetObjects1= [];
gdjs.fonsCode.GDend_9595resetObjects2= [];
gdjs.fonsCode.GDend_9595resetObjects3= [];
gdjs.fonsCode.GDend_9595resetObjects4= [];
gdjs.fonsCode.GDrobot_9595enemyObjects1= [];
gdjs.fonsCode.GDrobot_9595enemyObjects2= [];
gdjs.fonsCode.GDrobot_9595enemyObjects3= [];
gdjs.fonsCode.GDrobot_9595enemyObjects4= [];
gdjs.fonsCode.GDslime_9595enemyObjects1= [];
gdjs.fonsCode.GDslime_9595enemyObjects2= [];
gdjs.fonsCode.GDslime_9595enemyObjects3= [];
gdjs.fonsCode.GDslime_9595enemyObjects4= [];
gdjs.fonsCode.GDrob_9595enemy_9595rightObjects1= [];
gdjs.fonsCode.GDrob_9595enemy_9595rightObjects2= [];
gdjs.fonsCode.GDrob_9595enemy_9595rightObjects3= [];
gdjs.fonsCode.GDrob_9595enemy_9595rightObjects4= [];
gdjs.fonsCode.GDrob_9595enemy_9595leftObjects1= [];
gdjs.fonsCode.GDrob_9595enemy_9595leftObjects2= [];
gdjs.fonsCode.GDrob_9595enemy_9595leftObjects3= [];
gdjs.fonsCode.GDrob_9595enemy_9595leftObjects4= [];
gdjs.fonsCode.GDheroObjects1= [];
gdjs.fonsCode.GDheroObjects2= [];
gdjs.fonsCode.GDheroObjects3= [];
gdjs.fonsCode.GDheroObjects4= [];
gdjs.fonsCode.GDsawObjects1= [];
gdjs.fonsCode.GDsawObjects2= [];
gdjs.fonsCode.GDsawObjects3= [];
gdjs.fonsCode.GDsawObjects4= [];
gdjs.fonsCode.GDcoin_9595markerObjects1= [];
gdjs.fonsCode.GDcoin_9595markerObjects2= [];
gdjs.fonsCode.GDcoin_9595markerObjects3= [];
gdjs.fonsCode.GDcoin_9595markerObjects4= [];
gdjs.fonsCode.GDcoin_9595marker2Objects1= [];
gdjs.fonsCode.GDcoin_9595marker2Objects2= [];
gdjs.fonsCode.GDcoin_9595marker2Objects3= [];
gdjs.fonsCode.GDcoin_9595marker2Objects4= [];
gdjs.fonsCode.GDcoinsObjects1= [];
gdjs.fonsCode.GDcoinsObjects2= [];
gdjs.fonsCode.GDcoinsObjects3= [];
gdjs.fonsCode.GDcoinsObjects4= [];
gdjs.fonsCode.GDcoins2Objects1= [];
gdjs.fonsCode.GDcoins2Objects2= [];
gdjs.fonsCode.GDcoins2Objects3= [];
gdjs.fonsCode.GDcoins2Objects4= [];
gdjs.fonsCode.GDkey_9595lockerObjects1= [];
gdjs.fonsCode.GDkey_9595lockerObjects2= [];
gdjs.fonsCode.GDkey_9595lockerObjects3= [];
gdjs.fonsCode.GDkey_9595lockerObjects4= [];
gdjs.fonsCode.GDr_9595buttonObjects1= [];
gdjs.fonsCode.GDr_9595buttonObjects2= [];
gdjs.fonsCode.GDr_9595buttonObjects3= [];
gdjs.fonsCode.GDr_9595buttonObjects4= [];
gdjs.fonsCode.GDl_9595buttonObjects1= [];
gdjs.fonsCode.GDl_9595buttonObjects2= [];
gdjs.fonsCode.GDl_9595buttonObjects3= [];
gdjs.fonsCode.GDl_9595buttonObjects4= [];
gdjs.fonsCode.GDbackObjects1= [];
gdjs.fonsCode.GDbackObjects2= [];
gdjs.fonsCode.GDbackObjects3= [];
gdjs.fonsCode.GDbackObjects4= [];
gdjs.fonsCode.GDlockObjects1= [];
gdjs.fonsCode.GDlockObjects2= [];
gdjs.fonsCode.GDlockObjects3= [];
gdjs.fonsCode.GDlockObjects4= [];
gdjs.fonsCode.GDcamObjects1= [];
gdjs.fonsCode.GDcamObjects2= [];
gdjs.fonsCode.GDcamObjects3= [];
gdjs.fonsCode.GDcamObjects4= [];
gdjs.fonsCode.GDfonikObjects1= [];
gdjs.fonsCode.GDfonikObjects2= [];
gdjs.fonsCode.GDfonikObjects3= [];
gdjs.fonsCode.GDfonikObjects4= [];


gdjs.fonsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cam"), gdjs.fonsCode.GDcamObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.fonsCode.GDcamObjects1.length !== 0 ? gdjs.fonsCode.GDcamObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.fonsCode.GDcamObjects1.length ;i < len;++i) {
    gdjs.fonsCode.GDcamObjects1[i].hide();
}
}}

}


};gdjs.fonsCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.fonsCode.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.fonsCode.GDbackObjects2.length;i<l;++i) {
    if ( gdjs.fonsCode.GDbackObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.fonsCode.GDbackObjects2[k] = gdjs.fonsCode.GDbackObjects2[i];
        ++k;
    }
}
gdjs.fonsCode.GDbackObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67015996);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.fonsCode.GDbackObjects2 */
{for(var i = 0, len = gdjs.fonsCode.GDbackObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDbackObjects2[i].setAnimationName("back");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.fonsCode.GDr_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.fonsCode.GDr_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.fonsCode.GDr_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.fonsCode.GDr_9595buttonObjects2[k] = gdjs.fonsCode.GDr_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.fonsCode.GDr_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67017076);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.fonsCode.GDr_9595buttonObjects2 */
{for(var i = 0, len = gdjs.fonsCode.GDr_9595buttonObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDr_9595buttonObjects2[i].setAnimationName("r_button");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.fonsCode.GDl_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.fonsCode.GDl_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.fonsCode.GDl_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.fonsCode.GDl_9595buttonObjects2[k] = gdjs.fonsCode.GDl_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.fonsCode.GDl_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67013348);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.fonsCode.GDl_9595buttonObjects2 */
{for(var i = 0, len = gdjs.fonsCode.GDl_9595buttonObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDl_9595buttonObjects2[i].setAnimationName("l_button");
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon0Objects2Objects = Hashtable.newFrom({"fon0": gdjs.fonsCode.GDfon0Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects3Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects3});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDbuyObjects2Objects = Hashtable.newFrom({"buy": gdjs.fonsCode.GDbuyObjects2});
gdjs.fonsCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("key_locker"), gdjs.fonsCode.GDkey_9595lockerObjects3);
/* Reuse gdjs.fonsCode.GDlockerObjects3 */
{for(var i = 0, len = gdjs.fonsCode.GDkey_9595lockerObjects3.length ;i < len;++i) {
    gdjs.fonsCode.GDkey_9595lockerObjects3[i].setPosition((( gdjs.fonsCode.GDlockerObjects3.length === 0 ) ? 0 :gdjs.fonsCode.GDlockerObjects3[0].getCenterXInScene()),(( gdjs.fonsCode.GDlockerObjects3.length === 0 ) ? 0 :gdjs.fonsCode.GDlockerObjects3[0].getCenterYInScene()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("buy"), gdjs.fonsCode.GDbuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDbuyObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.fonsCode.GDcostObjects2);
gdjs.copyArray(runtimeScene.getObjects("key_locker"), gdjs.fonsCode.GDkey_9595lockerObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDkey_9595lockerObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDkey_9595lockerObjects2[i].setPosition(-(999),-(999));
}
}{for(var i = 0, len = gdjs.fonsCode.GDcostObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects2[i].setString("...");
}
}}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDbuyObjects2Objects = Hashtable.newFrom({"buy": gdjs.fonsCode.GDbuyObjects2});
gdjs.fonsCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.fonsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.fonsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.fonsCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.fonsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.fonsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.fonsCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.fonsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.fonsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.fonsCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.fonsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.fonsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.fonsCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.fonsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.fonsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.fonsCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.fonsCode.GDcostObjects2, gdjs.fonsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "fon_1", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.fonsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.fonsCode.GDcostObjects3[0].getVariables()).get("text_cost"))));
}
{ //Subevents
gdjs.fonsCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.fonsCode.GDcostObjects2, gdjs.fonsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "fon_2", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.fonsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.fonsCode.GDcostObjects3[0].getVariables()).get("text_cost"))));
}
{ //Subevents
gdjs.fonsCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.fonsCode.GDcostObjects2, gdjs.fonsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "fon_3", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.fonsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.fonsCode.GDcostObjects3[0].getVariables()).get("text_cost"))));
}
{ //Subevents
gdjs.fonsCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 4;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.fonsCode.GDcostObjects2, gdjs.fonsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "fon_4", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.fonsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.fonsCode.GDcostObjects3[0].getVariables()).get("text_cost"))));
}
{ //Subevents
gdjs.fonsCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.fonsCode.GDcostObjects2, gdjs.fonsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "fon_5", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.fonsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.fonsCode.GDcostObjects3[0].getVariables()).get("text_cost"))));
}
{ //Subevents
gdjs.fonsCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.fonsCode.GDcostObjects2 */
{for(var i = 0, len = gdjs.fonsCode.GDcostObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects2[i].returnVariable(gdjs.fonsCode.GDcostObjects2[i].getVariables().get("text_cost")).setNumber(0);
}
}{for(var i = 0, len = gdjs.fonsCode.GDcostObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects2[i].returnVariable(gdjs.fonsCode.GDcostObjects2[i].getVariables().get("text_cost")).setString("buy");
}
}}

}


};gdjs.fonsCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("buy"), gdjs.fonsCode.GDbuyObjects2);
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.fonsCode.GDcostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDbuyObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.fonsCode.GDcostObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.fonsCode.GDcostObjects2[0].getVariables()).get("text_cost")));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.fonsCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon1Objects2Objects = Hashtable.newFrom({"fon1": gdjs.fonsCode.GDfon1Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon1Objects3Objects = Hashtable.newFrom({"fon1": gdjs.fonsCode.GDfon1Objects3});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects3Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects3});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon1Objects2Objects = Hashtable.newFrom({"fon1": gdjs.fonsCode.GDfon1Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects2});
gdjs.fonsCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.fonsCode.GDfon1Objects2, gdjs.fonsCode.GDfon1Objects3);

gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon1Objects3Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.fonsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.fonsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects3[i].setString("50");
}
}{for(var i = 0, len = gdjs.fonsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects3[i].returnVariable(gdjs.fonsCode.GDcostObjects3[i].getVariables().get("text_cost")).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}}

}


{

/* Reuse gdjs.fonsCode.GDfon1Objects2 */
gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon1Objects2Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(1);
}}

}


};gdjs.fonsCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("fon1"), gdjs.fonsCode.GDfon1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon1Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.fonsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDtext_9595pickObjects2[i].setString("лес");
}
}
{ //Subevents
gdjs.fonsCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon2Objects2Objects = Hashtable.newFrom({"fon2": gdjs.fonsCode.GDfon2Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon2Objects3Objects = Hashtable.newFrom({"fon2": gdjs.fonsCode.GDfon2Objects3});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects3Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects3});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon2Objects2Objects = Hashtable.newFrom({"fon2": gdjs.fonsCode.GDfon2Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects2});
gdjs.fonsCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.fonsCode.GDfon2Objects2, gdjs.fonsCode.GDfon2Objects3);

gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon2Objects3Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.fonsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.fonsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects3[i].setString("50");
}
}{for(var i = 0, len = gdjs.fonsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects3[i].returnVariable(gdjs.fonsCode.GDcostObjects3[i].getVariables().get("text_cost")).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(2);
}}

}


{

/* Reuse gdjs.fonsCode.GDfon2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon2Objects2Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(2);
}}

}


};gdjs.fonsCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("fon2"), gdjs.fonsCode.GDfon2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon2Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.fonsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDtext_9595pickObjects2[i].setString("ад");
}
}
{ //Subevents
gdjs.fonsCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon3Objects2Objects = Hashtable.newFrom({"fon3": gdjs.fonsCode.GDfon3Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon3Objects3Objects = Hashtable.newFrom({"fon3": gdjs.fonsCode.GDfon3Objects3});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects3Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects3});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon3Objects2Objects = Hashtable.newFrom({"fon3": gdjs.fonsCode.GDfon3Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects2});
gdjs.fonsCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.fonsCode.GDfon3Objects2, gdjs.fonsCode.GDfon3Objects3);

gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon3Objects3Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.fonsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.fonsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects3[i].setString("50");
}
}{for(var i = 0, len = gdjs.fonsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects3[i].returnVariable(gdjs.fonsCode.GDcostObjects3[i].getVariables().get("text_cost")).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(3);
}}

}


{

/* Reuse gdjs.fonsCode.GDfon3Objects2 */
gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon3Objects2Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(3);
}}

}


};gdjs.fonsCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("fon3"), gdjs.fonsCode.GDfon3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.fonsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDtext_9595pickObjects2[i].setString("море");
}
}
{ //Subevents
gdjs.fonsCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon4Objects2Objects = Hashtable.newFrom({"fon4": gdjs.fonsCode.GDfon4Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon4Objects3Objects = Hashtable.newFrom({"fon4": gdjs.fonsCode.GDfon4Objects3});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects3Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects3});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon4Objects2Objects = Hashtable.newFrom({"fon4": gdjs.fonsCode.GDfon4Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects2});
gdjs.fonsCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.fonsCode.GDfon4Objects2, gdjs.fonsCode.GDfon4Objects3);

gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon4Objects3Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.fonsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.fonsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects3[i].setString("50");
}
}{for(var i = 0, len = gdjs.fonsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects3[i].returnVariable(gdjs.fonsCode.GDcostObjects3[i].getVariables().get("text_cost")).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(4);
}}

}


{

/* Reuse gdjs.fonsCode.GDfon4Objects2 */
gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon4Objects2Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(4);
}}

}


};gdjs.fonsCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("fon4"), gdjs.fonsCode.GDfon4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon4Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.fonsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDtext_9595pickObjects2[i].setString("зима");
}
}
{ //Subevents
gdjs.fonsCode.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon5Objects1Objects = Hashtable.newFrom({"fon5": gdjs.fonsCode.GDfon5Objects1});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon5Objects2Objects = Hashtable.newFrom({"fon5": gdjs.fonsCode.GDfon5Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon5Objects1Objects = Hashtable.newFrom({"fon5": gdjs.fonsCode.GDfon5Objects1});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects1Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects1});
gdjs.fonsCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.fonsCode.GDfon5Objects1, gdjs.fonsCode.GDfon5Objects2);

gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon5Objects2Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.fonsCode.GDcostObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDcostObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects2[i].setString("50");
}
}{for(var i = 0, len = gdjs.fonsCode.GDcostObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects2[i].returnVariable(gdjs.fonsCode.GDcostObjects2[i].getVariables().get("text_cost")).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(5);
}}

}


{

/* Reuse gdjs.fonsCode.GDfon5Objects1 */
gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon5Objects1Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(5);
}}

}


};gdjs.fonsCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("fon5"), gdjs.fonsCode.GDfon5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon5Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.fonsCode.GDtext_9595pickObjects1);
{for(var i = 0, len = gdjs.fonsCode.GDtext_9595pickObjects1.length ;i < len;++i) {
    gdjs.fonsCode.GDtext_9595pickObjects1[i].setString("пустыня");
}
}
{ //Subevents
gdjs.fonsCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.fonsCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("fon0"), gdjs.fonsCode.GDfon0Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon0Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.fonsCode.GDtext_9595pickObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(0);
}{for(var i = 0, len = gdjs.fonsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDtext_9595pickObjects2[i].setString("класика");
}
}}

}


{


gdjs.fonsCode.eventsList2(runtimeScene);
}


{


gdjs.fonsCode.eventsList9(runtimeScene);
}


{


gdjs.fonsCode.eventsList11(runtimeScene);
}


{


gdjs.fonsCode.eventsList13(runtimeScene);
}


{


gdjs.fonsCode.eventsList15(runtimeScene);
}


{


gdjs.fonsCode.eventsList17(runtimeScene);
}


{


gdjs.fonsCode.eventsList19(runtimeScene);
}


};gdjs.fonsCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67016620);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.fonsCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.fonsCode.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.fonsCode.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}
{ //Subevents
gdjs.fonsCode.eventsList22(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.fonsCode.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("fon0"), gdjs.fonsCode.GDfon0Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.fonsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDpickerObjects2[i].setPosition((( gdjs.fonsCode.GDfon0Objects2.length === 0 ) ? 0 :gdjs.fonsCode.GDfon0Objects2[0].getCenterXInScene()),(( gdjs.fonsCode.GDfon0Objects2.length === 0 ) ? 0 :gdjs.fonsCode.GDfon0Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("fon1"), gdjs.fonsCode.GDfon1Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.fonsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDpickerObjects2[i].setPosition((( gdjs.fonsCode.GDfon1Objects2.length === 0 ) ? 0 :gdjs.fonsCode.GDfon1Objects2[0].getCenterXInScene()),(( gdjs.fonsCode.GDfon1Objects2.length === 0 ) ? 0 :gdjs.fonsCode.GDfon1Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("fon2"), gdjs.fonsCode.GDfon2Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.fonsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDpickerObjects2[i].setPosition((( gdjs.fonsCode.GDfon2Objects2.length === 0 ) ? 0 :gdjs.fonsCode.GDfon2Objects2[0].getCenterXInScene()),(( gdjs.fonsCode.GDfon2Objects2.length === 0 ) ? 0 :gdjs.fonsCode.GDfon2Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("fon3"), gdjs.fonsCode.GDfon3Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.fonsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDpickerObjects2[i].setPosition((( gdjs.fonsCode.GDfon3Objects2.length === 0 ) ? 0 :gdjs.fonsCode.GDfon3Objects2[0].getCenterXInScene()),(( gdjs.fonsCode.GDfon3Objects2.length === 0 ) ? 0 :gdjs.fonsCode.GDfon3Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("fon4"), gdjs.fonsCode.GDfon4Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.fonsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.fonsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDpickerObjects2[i].setPosition((( gdjs.fonsCode.GDfon4Objects2.length === 0 ) ? 0 :gdjs.fonsCode.GDfon4Objects2[0].getCenterXInScene()),(( gdjs.fonsCode.GDfon4Objects2.length === 0 ) ? 0 :gdjs.fonsCode.GDfon4Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("fon5"), gdjs.fonsCode.GDfon5Objects1);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.fonsCode.GDpickerObjects1);
{for(var i = 0, len = gdjs.fonsCode.GDpickerObjects1.length ;i < len;++i) {
    gdjs.fonsCode.GDpickerObjects1[i].setPosition((( gdjs.fonsCode.GDfon5Objects1.length === 0 ) ? 0 :gdjs.fonsCode.GDfon5Objects1[0].getCenterXInScene()),(( gdjs.fonsCode.GDfon5Objects1.length === 0 ) ? 0 :gdjs.fonsCode.GDfon5Objects1[0].getCenterYInScene()));
}
}}

}


};gdjs.fonsCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67043348);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.fonsCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon1Objects2Objects = Hashtable.newFrom({"fon1": gdjs.fonsCode.GDfon1Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon2Objects2Objects = Hashtable.newFrom({"fon2": gdjs.fonsCode.GDfon2Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon3Objects2Objects = Hashtable.newFrom({"fon3": gdjs.fonsCode.GDfon3Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon4Objects2Objects = Hashtable.newFrom({"fon4": gdjs.fonsCode.GDfon4Objects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects1Objects = Hashtable.newFrom({"locker": gdjs.fonsCode.GDlockerObjects1});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon5Objects1Objects = Hashtable.newFrom({"fon5": gdjs.fonsCode.GDfon5Objects1});
gdjs.fonsCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("fon1"), gdjs.fonsCode.GDfon1Objects2);
gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon1Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "fon_1");
}
if (isConditionTrue_0) {
/* Reuse gdjs.fonsCode.GDlockerObjects2 */
{for(var i = 0, len = gdjs.fonsCode.GDlockerObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDlockerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("fon2"), gdjs.fonsCode.GDfon2Objects2);
gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "fon_2");
}
if (isConditionTrue_0) {
/* Reuse gdjs.fonsCode.GDlockerObjects2 */
{for(var i = 0, len = gdjs.fonsCode.GDlockerObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDlockerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("fon3"), gdjs.fonsCode.GDfon3Objects2);
gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon3Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "fon_3");
}
if (isConditionTrue_0) {
/* Reuse gdjs.fonsCode.GDlockerObjects2 */
{for(var i = 0, len = gdjs.fonsCode.GDlockerObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDlockerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("fon4"), gdjs.fonsCode.GDfon4Objects2);
gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects2Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon4Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "fon_4");
}
if (isConditionTrue_0) {
/* Reuse gdjs.fonsCode.GDlockerObjects2 */
{for(var i = 0, len = gdjs.fonsCode.GDlockerObjects2.length ;i < len;++i) {
    gdjs.fonsCode.GDlockerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("fon5"), gdjs.fonsCode.GDfon5Objects1);
gdjs.copyArray(runtimeScene.getObjects("locker"), gdjs.fonsCode.GDlockerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDlockerObjects1Objects, gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDfon5Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "fon_5");
}
if (isConditionTrue_0) {
/* Reuse gdjs.fonsCode.GDlockerObjects1 */
{for(var i = 0, len = gdjs.fonsCode.GDlockerObjects1.length ;i < len;++i) {
    gdjs.fonsCode.GDlockerObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.fonsCode.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.fonsCode.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDbackObjects2Objects = Hashtable.newFrom({"back": gdjs.fonsCode.GDbackObjects2});
gdjs.fonsCode.asyncCallback67053924 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "fon", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)));
}}
gdjs.fonsCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.fonsCode.asyncCallback67053924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDr_95959595buttonObjects2Objects = Hashtable.newFrom({"r_button": gdjs.fonsCode.GDr_9595buttonObjects2});
gdjs.fonsCode.asyncCallback67054916 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats2", false);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}
gdjs.fonsCode.eventsList29 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.fonsCode.asyncCallback67054916(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDbackObjects2Objects = Hashtable.newFrom({"back": gdjs.fonsCode.GDbackObjects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDr_95959595buttonObjects2Objects = Hashtable.newFrom({"r_button": gdjs.fonsCode.GDr_9595buttonObjects2});
gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDl_95959595buttonObjects2Objects = Hashtable.newFrom({"l_button": gdjs.fonsCode.GDl_9595buttonObjects2});
gdjs.fonsCode.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.fonsCode.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDbackObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.fonsCode.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.fonsCode.GDr_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDr_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.fonsCode.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.fonsCode.GDbackObjects1.length = 0;

gdjs.fonsCode.GDl_9595buttonObjects1.length = 0;

gdjs.fonsCode.GDr_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.fonsCode.GDbackObjects1_1final.length = 0;
gdjs.fonsCode.GDl_9595buttonObjects1_1final.length = 0;
gdjs.fonsCode.GDr_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.fonsCode.GDbackObjects2);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDbackObjects2Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.fonsCode.GDbackObjects2.length; j < jLen ; ++j) {
        if ( gdjs.fonsCode.GDbackObjects1_1final.indexOf(gdjs.fonsCode.GDbackObjects2[j]) === -1 )
            gdjs.fonsCode.GDbackObjects1_1final.push(gdjs.fonsCode.GDbackObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.fonsCode.GDr_9595buttonObjects2);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDr_95959595buttonObjects2Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.fonsCode.GDr_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.fonsCode.GDr_9595buttonObjects1_1final.indexOf(gdjs.fonsCode.GDr_9595buttonObjects2[j]) === -1 )
            gdjs.fonsCode.GDr_9595buttonObjects1_1final.push(gdjs.fonsCode.GDr_9595buttonObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.fonsCode.GDl_9595buttonObjects2);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.fonsCode.mapOfGDgdjs_9546fonsCode_9546GDl_95959595buttonObjects2Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.fonsCode.GDl_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.fonsCode.GDl_9595buttonObjects1_1final.indexOf(gdjs.fonsCode.GDl_9595buttonObjects2[j]) === -1 )
            gdjs.fonsCode.GDl_9595buttonObjects1_1final.push(gdjs.fonsCode.GDl_9595buttonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.fonsCode.GDbackObjects1_1final, gdjs.fonsCode.GDbackObjects1);
gdjs.copyArray(gdjs.fonsCode.GDl_9595buttonObjects1_1final, gdjs.fonsCode.GDl_9595buttonObjects1);
gdjs.copyArray(gdjs.fonsCode.GDr_9595buttonObjects1_1final, gdjs.fonsCode.GDr_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.fonsCode.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67052908);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.fonsCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.fonsCode.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.fonsCode.GDcoins2Objects1);
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.fonsCode.GDcostObjects1);
{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "coin", runtimeScene, runtimeScene.getScene().getVariables().get("coins"));
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("coins")));
}{for(var i = 0, len = gdjs.fonsCode.GDcoins2Objects1.length ;i < len;++i) {
    gdjs.fonsCode.GDcoins2Objects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}{for(var i = 0, len = gdjs.fonsCode.GDcostObjects1.length ;i < len;++i) {
    gdjs.fonsCode.GDcostObjects1[i].returnVariable(gdjs.fonsCode.GDcostObjects1[i].getVariables().get("text_cost")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "fon", runtimeScene, runtimeScene.getScene().getVariables().get("fon"));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("fon")));
}
{ //Subevents
gdjs.fonsCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.fonsCode.eventsList1(runtimeScene);
}


{


gdjs.fonsCode.eventsList21(runtimeScene);
}


{


gdjs.fonsCode.eventsList23(runtimeScene);
}


{


gdjs.fonsCode.eventsList25(runtimeScene);
}


{


gdjs.fonsCode.eventsList27(runtimeScene);
}


{


gdjs.fonsCode.eventsList31(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.fonsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.fonsCode.GDfon0Objects1.length = 0;
gdjs.fonsCode.GDfon0Objects2.length = 0;
gdjs.fonsCode.GDfon0Objects3.length = 0;
gdjs.fonsCode.GDfon0Objects4.length = 0;
gdjs.fonsCode.GDfon1Objects1.length = 0;
gdjs.fonsCode.GDfon1Objects2.length = 0;
gdjs.fonsCode.GDfon1Objects3.length = 0;
gdjs.fonsCode.GDfon1Objects4.length = 0;
gdjs.fonsCode.GDfon2Objects1.length = 0;
gdjs.fonsCode.GDfon2Objects2.length = 0;
gdjs.fonsCode.GDfon2Objects3.length = 0;
gdjs.fonsCode.GDfon2Objects4.length = 0;
gdjs.fonsCode.GDfon3Objects1.length = 0;
gdjs.fonsCode.GDfon3Objects2.length = 0;
gdjs.fonsCode.GDfon3Objects3.length = 0;
gdjs.fonsCode.GDfon3Objects4.length = 0;
gdjs.fonsCode.GDfon4Objects1.length = 0;
gdjs.fonsCode.GDfon4Objects2.length = 0;
gdjs.fonsCode.GDfon4Objects3.length = 0;
gdjs.fonsCode.GDfon4Objects4.length = 0;
gdjs.fonsCode.GDfon5Objects1.length = 0;
gdjs.fonsCode.GDfon5Objects2.length = 0;
gdjs.fonsCode.GDfon5Objects3.length = 0;
gdjs.fonsCode.GDfon5Objects4.length = 0;
gdjs.fonsCode.GDpickerObjects1.length = 0;
gdjs.fonsCode.GDpickerObjects2.length = 0;
gdjs.fonsCode.GDpickerObjects3.length = 0;
gdjs.fonsCode.GDpickerObjects4.length = 0;
gdjs.fonsCode.GDlockerObjects1.length = 0;
gdjs.fonsCode.GDlockerObjects2.length = 0;
gdjs.fonsCode.GDlockerObjects3.length = 0;
gdjs.fonsCode.GDlockerObjects4.length = 0;
gdjs.fonsCode.GDcostObjects1.length = 0;
gdjs.fonsCode.GDcostObjects2.length = 0;
gdjs.fonsCode.GDcostObjects3.length = 0;
gdjs.fonsCode.GDcostObjects4.length = 0;
gdjs.fonsCode.GDtext_9595pickObjects1.length = 0;
gdjs.fonsCode.GDtext_9595pickObjects2.length = 0;
gdjs.fonsCode.GDtext_9595pickObjects3.length = 0;
gdjs.fonsCode.GDtext_9595pickObjects4.length = 0;
gdjs.fonsCode.GDbuyObjects1.length = 0;
gdjs.fonsCode.GDbuyObjects2.length = 0;
gdjs.fonsCode.GDbuyObjects3.length = 0;
gdjs.fonsCode.GDbuyObjects4.length = 0;
gdjs.fonsCode.GDgrass_9595blockObjects1.length = 0;
gdjs.fonsCode.GDgrass_9595blockObjects2.length = 0;
gdjs.fonsCode.GDgrass_9595blockObjects3.length = 0;
gdjs.fonsCode.GDgrass_9595blockObjects4.length = 0;
gdjs.fonsCode.GDblockObjects1.length = 0;
gdjs.fonsCode.GDblockObjects2.length = 0;
gdjs.fonsCode.GDblockObjects3.length = 0;
gdjs.fonsCode.GDblockObjects4.length = 0;
gdjs.fonsCode.GDmenuObjects1.length = 0;
gdjs.fonsCode.GDmenuObjects2.length = 0;
gdjs.fonsCode.GDmenuObjects3.length = 0;
gdjs.fonsCode.GDmenuObjects4.length = 0;
gdjs.fonsCode.GDhomeObjects1.length = 0;
gdjs.fonsCode.GDhomeObjects2.length = 0;
gdjs.fonsCode.GDhomeObjects3.length = 0;
gdjs.fonsCode.GDhomeObjects4.length = 0;
gdjs.fonsCode.GDresetObjects1.length = 0;
gdjs.fonsCode.GDresetObjects2.length = 0;
gdjs.fonsCode.GDresetObjects3.length = 0;
gdjs.fonsCode.GDresetObjects4.length = 0;
gdjs.fonsCode.GDspikeObjects1.length = 0;
gdjs.fonsCode.GDspikeObjects2.length = 0;
gdjs.fonsCode.GDspikeObjects3.length = 0;
gdjs.fonsCode.GDspikeObjects4.length = 0;
gdjs.fonsCode.GDend_9595homeObjects1.length = 0;
gdjs.fonsCode.GDend_9595homeObjects2.length = 0;
gdjs.fonsCode.GDend_9595homeObjects3.length = 0;
gdjs.fonsCode.GDend_9595homeObjects4.length = 0;
gdjs.fonsCode.GDend_9595resetObjects1.length = 0;
gdjs.fonsCode.GDend_9595resetObjects2.length = 0;
gdjs.fonsCode.GDend_9595resetObjects3.length = 0;
gdjs.fonsCode.GDend_9595resetObjects4.length = 0;
gdjs.fonsCode.GDrobot_9595enemyObjects1.length = 0;
gdjs.fonsCode.GDrobot_9595enemyObjects2.length = 0;
gdjs.fonsCode.GDrobot_9595enemyObjects3.length = 0;
gdjs.fonsCode.GDrobot_9595enemyObjects4.length = 0;
gdjs.fonsCode.GDslime_9595enemyObjects1.length = 0;
gdjs.fonsCode.GDslime_9595enemyObjects2.length = 0;
gdjs.fonsCode.GDslime_9595enemyObjects3.length = 0;
gdjs.fonsCode.GDslime_9595enemyObjects4.length = 0;
gdjs.fonsCode.GDrob_9595enemy_9595rightObjects1.length = 0;
gdjs.fonsCode.GDrob_9595enemy_9595rightObjects2.length = 0;
gdjs.fonsCode.GDrob_9595enemy_9595rightObjects3.length = 0;
gdjs.fonsCode.GDrob_9595enemy_9595rightObjects4.length = 0;
gdjs.fonsCode.GDrob_9595enemy_9595leftObjects1.length = 0;
gdjs.fonsCode.GDrob_9595enemy_9595leftObjects2.length = 0;
gdjs.fonsCode.GDrob_9595enemy_9595leftObjects3.length = 0;
gdjs.fonsCode.GDrob_9595enemy_9595leftObjects4.length = 0;
gdjs.fonsCode.GDheroObjects1.length = 0;
gdjs.fonsCode.GDheroObjects2.length = 0;
gdjs.fonsCode.GDheroObjects3.length = 0;
gdjs.fonsCode.GDheroObjects4.length = 0;
gdjs.fonsCode.GDsawObjects1.length = 0;
gdjs.fonsCode.GDsawObjects2.length = 0;
gdjs.fonsCode.GDsawObjects3.length = 0;
gdjs.fonsCode.GDsawObjects4.length = 0;
gdjs.fonsCode.GDcoin_9595markerObjects1.length = 0;
gdjs.fonsCode.GDcoin_9595markerObjects2.length = 0;
gdjs.fonsCode.GDcoin_9595markerObjects3.length = 0;
gdjs.fonsCode.GDcoin_9595markerObjects4.length = 0;
gdjs.fonsCode.GDcoin_9595marker2Objects1.length = 0;
gdjs.fonsCode.GDcoin_9595marker2Objects2.length = 0;
gdjs.fonsCode.GDcoin_9595marker2Objects3.length = 0;
gdjs.fonsCode.GDcoin_9595marker2Objects4.length = 0;
gdjs.fonsCode.GDcoinsObjects1.length = 0;
gdjs.fonsCode.GDcoinsObjects2.length = 0;
gdjs.fonsCode.GDcoinsObjects3.length = 0;
gdjs.fonsCode.GDcoinsObjects4.length = 0;
gdjs.fonsCode.GDcoins2Objects1.length = 0;
gdjs.fonsCode.GDcoins2Objects2.length = 0;
gdjs.fonsCode.GDcoins2Objects3.length = 0;
gdjs.fonsCode.GDcoins2Objects4.length = 0;
gdjs.fonsCode.GDkey_9595lockerObjects1.length = 0;
gdjs.fonsCode.GDkey_9595lockerObjects2.length = 0;
gdjs.fonsCode.GDkey_9595lockerObjects3.length = 0;
gdjs.fonsCode.GDkey_9595lockerObjects4.length = 0;
gdjs.fonsCode.GDr_9595buttonObjects1.length = 0;
gdjs.fonsCode.GDr_9595buttonObjects2.length = 0;
gdjs.fonsCode.GDr_9595buttonObjects3.length = 0;
gdjs.fonsCode.GDr_9595buttonObjects4.length = 0;
gdjs.fonsCode.GDl_9595buttonObjects1.length = 0;
gdjs.fonsCode.GDl_9595buttonObjects2.length = 0;
gdjs.fonsCode.GDl_9595buttonObjects3.length = 0;
gdjs.fonsCode.GDl_9595buttonObjects4.length = 0;
gdjs.fonsCode.GDbackObjects1.length = 0;
gdjs.fonsCode.GDbackObjects2.length = 0;
gdjs.fonsCode.GDbackObjects3.length = 0;
gdjs.fonsCode.GDbackObjects4.length = 0;
gdjs.fonsCode.GDlockObjects1.length = 0;
gdjs.fonsCode.GDlockObjects2.length = 0;
gdjs.fonsCode.GDlockObjects3.length = 0;
gdjs.fonsCode.GDlockObjects4.length = 0;
gdjs.fonsCode.GDcamObjects1.length = 0;
gdjs.fonsCode.GDcamObjects2.length = 0;
gdjs.fonsCode.GDcamObjects3.length = 0;
gdjs.fonsCode.GDcamObjects4.length = 0;
gdjs.fonsCode.GDfonikObjects1.length = 0;
gdjs.fonsCode.GDfonikObjects2.length = 0;
gdjs.fonsCode.GDfonikObjects3.length = 0;
gdjs.fonsCode.GDfonikObjects4.length = 0;

gdjs.fonsCode.eventsList32(runtimeScene);

return;

}

gdjs['fonsCode'] = gdjs.fonsCode;
