gdjs.test2Code = {};
gdjs.test2Code.GDblockObjects3_1final = [];

gdjs.test2Code.GDblockObjects4_1final = [];

gdjs.test2Code.GDbrocken_9595blockObjects3_1final = [];

gdjs.test2Code.GDbrocken_9595blockObjects4_1final = [];

gdjs.test2Code.GDbuletObjects3_1final = [];

gdjs.test2Code.GDheroObjects3_1final = [];

gdjs.test2Code.GDheroObjects4_1final = [];

gdjs.test2Code.GDrobot_9595enemyObjects3_1final = [];

gdjs.test2Code.GDsawObjects3_1final = [];

gdjs.test2Code.GDslime_9595buletObjects3_1final = [];

gdjs.test2Code.GDslime_9595buletObjects4_1final = [];

gdjs.test2Code.GDspikeObjects3_1final = [];

gdjs.test2Code.GDtap_9595blockObjects3_1final = [];

gdjs.test2Code.GDtap_9595blockObjects4_1final = [];

gdjs.test2Code.GDtext_9595scoreObjects1= [];
gdjs.test2Code.GDtext_9595scoreObjects2= [];
gdjs.test2Code.GDtext_9595scoreObjects3= [];
gdjs.test2Code.GDtext_9595scoreObjects4= [];
gdjs.test2Code.GDtext_9595scoreObjects5= [];
gdjs.test2Code.GDtext_9595scoreObjects6= [];
gdjs.test2Code.GDtext_9595scoreObjects7= [];
gdjs.test2Code.GDtext_9595recordObjects1= [];
gdjs.test2Code.GDtext_9595recordObjects2= [];
gdjs.test2Code.GDtext_9595recordObjects3= [];
gdjs.test2Code.GDtext_9595recordObjects4= [];
gdjs.test2Code.GDtext_9595recordObjects5= [];
gdjs.test2Code.GDtext_9595recordObjects6= [];
gdjs.test2Code.GDtext_9595recordObjects7= [];
gdjs.test2Code.GDscoreObjects1= [];
gdjs.test2Code.GDscoreObjects2= [];
gdjs.test2Code.GDscoreObjects3= [];
gdjs.test2Code.GDscoreObjects4= [];
gdjs.test2Code.GDscoreObjects5= [];
gdjs.test2Code.GDscoreObjects6= [];
gdjs.test2Code.GDscoreObjects7= [];
gdjs.test2Code.GDscore2Objects1= [];
gdjs.test2Code.GDscore2Objects2= [];
gdjs.test2Code.GDscore2Objects3= [];
gdjs.test2Code.GDscore2Objects4= [];
gdjs.test2Code.GDscore2Objects5= [];
gdjs.test2Code.GDscore2Objects6= [];
gdjs.test2Code.GDscore2Objects7= [];
gdjs.test2Code.GDrecordObjects1= [];
gdjs.test2Code.GDrecordObjects2= [];
gdjs.test2Code.GDrecordObjects3= [];
gdjs.test2Code.GDrecordObjects4= [];
gdjs.test2Code.GDrecordObjects5= [];
gdjs.test2Code.GDrecordObjects6= [];
gdjs.test2Code.GDrecordObjects7= [];
gdjs.test2Code.GDdoorObjects1= [];
gdjs.test2Code.GDdoorObjects2= [];
gdjs.test2Code.GDdoorObjects3= [];
gdjs.test2Code.GDdoorObjects4= [];
gdjs.test2Code.GDdoorObjects5= [];
gdjs.test2Code.GDdoorObjects6= [];
gdjs.test2Code.GDdoorObjects7= [];
gdjs.test2Code.GDhatObjects1= [];
gdjs.test2Code.GDhatObjects2= [];
gdjs.test2Code.GDhatObjects3= [];
gdjs.test2Code.GDhatObjects4= [];
gdjs.test2Code.GDhatObjects5= [];
gdjs.test2Code.GDhatObjects6= [];
gdjs.test2Code.GDhatObjects7= [];
gdjs.test2Code.GDcoinObjects1= [];
gdjs.test2Code.GDcoinObjects2= [];
gdjs.test2Code.GDcoinObjects3= [];
gdjs.test2Code.GDcoinObjects4= [];
gdjs.test2Code.GDcoinObjects5= [];
gdjs.test2Code.GDcoinObjects6= [];
gdjs.test2Code.GDcoinObjects7= [];
gdjs.test2Code.GDtrava1Objects1= [];
gdjs.test2Code.GDtrava1Objects2= [];
gdjs.test2Code.GDtrava1Objects3= [];
gdjs.test2Code.GDtrava1Objects4= [];
gdjs.test2Code.GDtrava1Objects5= [];
gdjs.test2Code.GDtrava1Objects6= [];
gdjs.test2Code.GDtrava1Objects7= [];
gdjs.test2Code.GDtrava2Objects1= [];
gdjs.test2Code.GDtrava2Objects2= [];
gdjs.test2Code.GDtrava2Objects3= [];
gdjs.test2Code.GDtrava2Objects4= [];
gdjs.test2Code.GDtrava2Objects5= [];
gdjs.test2Code.GDtrava2Objects6= [];
gdjs.test2Code.GDtrava2Objects7= [];
gdjs.test2Code.GDtrava3Objects1= [];
gdjs.test2Code.GDtrava3Objects2= [];
gdjs.test2Code.GDtrava3Objects3= [];
gdjs.test2Code.GDtrava3Objects4= [];
gdjs.test2Code.GDtrava3Objects5= [];
gdjs.test2Code.GDtrava3Objects6= [];
gdjs.test2Code.GDtrava3Objects7= [];
gdjs.test2Code.GDtrava4Objects1= [];
gdjs.test2Code.GDtrava4Objects2= [];
gdjs.test2Code.GDtrava4Objects3= [];
gdjs.test2Code.GDtrava4Objects4= [];
gdjs.test2Code.GDtrava4Objects5= [];
gdjs.test2Code.GDtrava4Objects6= [];
gdjs.test2Code.GDtrava4Objects7= [];
gdjs.test2Code.GDfly1Objects1= [];
gdjs.test2Code.GDfly1Objects2= [];
gdjs.test2Code.GDfly1Objects3= [];
gdjs.test2Code.GDfly1Objects4= [];
gdjs.test2Code.GDfly1Objects5= [];
gdjs.test2Code.GDfly1Objects6= [];
gdjs.test2Code.GDfly1Objects7= [];
gdjs.test2Code.GDfly2Objects1= [];
gdjs.test2Code.GDfly2Objects2= [];
gdjs.test2Code.GDfly2Objects3= [];
gdjs.test2Code.GDfly2Objects4= [];
gdjs.test2Code.GDfly2Objects5= [];
gdjs.test2Code.GDfly2Objects6= [];
gdjs.test2Code.GDfly2Objects7= [];
gdjs.test2Code.GDcamera_9595stoperObjects1= [];
gdjs.test2Code.GDcamera_9595stoperObjects2= [];
gdjs.test2Code.GDcamera_9595stoperObjects3= [];
gdjs.test2Code.GDcamera_9595stoperObjects4= [];
gdjs.test2Code.GDcamera_9595stoperObjects5= [];
gdjs.test2Code.GDcamera_9595stoperObjects6= [];
gdjs.test2Code.GDcamera_9595stoperObjects7= [];
gdjs.test2Code.GDgunObjects1= [];
gdjs.test2Code.GDgunObjects2= [];
gdjs.test2Code.GDgunObjects3= [];
gdjs.test2Code.GDgunObjects4= [];
gdjs.test2Code.GDgunObjects5= [];
gdjs.test2Code.GDgunObjects6= [];
gdjs.test2Code.GDgunObjects7= [];
gdjs.test2Code.GDbuletObjects1= [];
gdjs.test2Code.GDbuletObjects2= [];
gdjs.test2Code.GDbuletObjects3= [];
gdjs.test2Code.GDbuletObjects4= [];
gdjs.test2Code.GDbuletObjects5= [];
gdjs.test2Code.GDbuletObjects6= [];
gdjs.test2Code.GDbuletObjects7= [];
gdjs.test2Code.GDforegroundObjects1= [];
gdjs.test2Code.GDforegroundObjects2= [];
gdjs.test2Code.GDforegroundObjects3= [];
gdjs.test2Code.GDforegroundObjects4= [];
gdjs.test2Code.GDforegroundObjects5= [];
gdjs.test2Code.GDforegroundObjects6= [];
gdjs.test2Code.GDforegroundObjects7= [];
gdjs.test2Code.GDmidlegroundObjects1= [];
gdjs.test2Code.GDmidlegroundObjects2= [];
gdjs.test2Code.GDmidlegroundObjects3= [];
gdjs.test2Code.GDmidlegroundObjects4= [];
gdjs.test2Code.GDmidlegroundObjects5= [];
gdjs.test2Code.GDmidlegroundObjects6= [];
gdjs.test2Code.GDmidlegroundObjects7= [];
gdjs.test2Code.GDbackgroundObjects1= [];
gdjs.test2Code.GDbackgroundObjects2= [];
gdjs.test2Code.GDbackgroundObjects3= [];
gdjs.test2Code.GDbackgroundObjects4= [];
gdjs.test2Code.GDbackgroundObjects5= [];
gdjs.test2Code.GDbackgroundObjects6= [];
gdjs.test2Code.GDbackgroundObjects7= [];
gdjs.test2Code.GDwebObjects1= [];
gdjs.test2Code.GDwebObjects2= [];
gdjs.test2Code.GDwebObjects3= [];
gdjs.test2Code.GDwebObjects4= [];
gdjs.test2Code.GDwebObjects5= [];
gdjs.test2Code.GDwebObjects6= [];
gdjs.test2Code.GDwebObjects7= [];
gdjs.test2Code.GDangry_9595flyObjects1= [];
gdjs.test2Code.GDangry_9595flyObjects2= [];
gdjs.test2Code.GDangry_9595flyObjects3= [];
gdjs.test2Code.GDangry_9595flyObjects4= [];
gdjs.test2Code.GDangry_9595flyObjects5= [];
gdjs.test2Code.GDangry_9595flyObjects6= [];
gdjs.test2Code.GDangry_9595flyObjects7= [];
gdjs.test2Code.GDslime_9595buletObjects1= [];
gdjs.test2Code.GDslime_9595buletObjects2= [];
gdjs.test2Code.GDslime_9595buletObjects3= [];
gdjs.test2Code.GDslime_9595buletObjects4= [];
gdjs.test2Code.GDslime_9595buletObjects5= [];
gdjs.test2Code.GDslime_9595buletObjects6= [];
gdjs.test2Code.GDslime_9595buletObjects7= [];
gdjs.test2Code.GDplatformObjects1= [];
gdjs.test2Code.GDplatformObjects2= [];
gdjs.test2Code.GDplatformObjects3= [];
gdjs.test2Code.GDplatformObjects4= [];
gdjs.test2Code.GDplatformObjects5= [];
gdjs.test2Code.GDplatformObjects6= [];
gdjs.test2Code.GDplatformObjects7= [];
gdjs.test2Code.GDplatform2Objects1= [];
gdjs.test2Code.GDplatform2Objects2= [];
gdjs.test2Code.GDplatform2Objects3= [];
gdjs.test2Code.GDplatform2Objects4= [];
gdjs.test2Code.GDplatform2Objects5= [];
gdjs.test2Code.GDplatform2Objects6= [];
gdjs.test2Code.GDplatform2Objects7= [];
gdjs.test2Code.GDplatform3Objects1= [];
gdjs.test2Code.GDplatform3Objects2= [];
gdjs.test2Code.GDplatform3Objects3= [];
gdjs.test2Code.GDplatform3Objects4= [];
gdjs.test2Code.GDplatform3Objects5= [];
gdjs.test2Code.GDplatform3Objects6= [];
gdjs.test2Code.GDplatform3Objects7= [];
gdjs.test2Code.GDsaw_9595centerObjects1= [];
gdjs.test2Code.GDsaw_9595centerObjects2= [];
gdjs.test2Code.GDsaw_9595centerObjects3= [];
gdjs.test2Code.GDsaw_9595centerObjects4= [];
gdjs.test2Code.GDsaw_9595centerObjects5= [];
gdjs.test2Code.GDsaw_9595centerObjects6= [];
gdjs.test2Code.GDsaw_9595centerObjects7= [];
gdjs.test2Code.GDsaw_9595center2Objects1= [];
gdjs.test2Code.GDsaw_9595center2Objects2= [];
gdjs.test2Code.GDsaw_9595center2Objects3= [];
gdjs.test2Code.GDsaw_9595center2Objects4= [];
gdjs.test2Code.GDsaw_9595center2Objects5= [];
gdjs.test2Code.GDsaw_9595center2Objects6= [];
gdjs.test2Code.GDsaw_9595center2Objects7= [];
gdjs.test2Code.GDback_9595blockObjects1= [];
gdjs.test2Code.GDback_9595blockObjects2= [];
gdjs.test2Code.GDback_9595blockObjects3= [];
gdjs.test2Code.GDback_9595blockObjects4= [];
gdjs.test2Code.GDback_9595blockObjects5= [];
gdjs.test2Code.GDback_9595blockObjects6= [];
gdjs.test2Code.GDback_9595blockObjects7= [];
gdjs.test2Code.GDbrocken_9595blockObjects1= [];
gdjs.test2Code.GDbrocken_9595blockObjects2= [];
gdjs.test2Code.GDbrocken_9595blockObjects3= [];
gdjs.test2Code.GDbrocken_9595blockObjects4= [];
gdjs.test2Code.GDbrocken_9595blockObjects5= [];
gdjs.test2Code.GDbrocken_9595blockObjects6= [];
gdjs.test2Code.GDbrocken_9595blockObjects7= [];
gdjs.test2Code.GDcageObjects1= [];
gdjs.test2Code.GDcageObjects2= [];
gdjs.test2Code.GDcageObjects3= [];
gdjs.test2Code.GDcageObjects4= [];
gdjs.test2Code.GDcageObjects5= [];
gdjs.test2Code.GDcageObjects6= [];
gdjs.test2Code.GDcageObjects7= [];
gdjs.test2Code.GDactive_9595stickObjects1= [];
gdjs.test2Code.GDactive_9595stickObjects2= [];
gdjs.test2Code.GDactive_9595stickObjects3= [];
gdjs.test2Code.GDactive_9595stickObjects4= [];
gdjs.test2Code.GDactive_9595stickObjects5= [];
gdjs.test2Code.GDactive_9595stickObjects6= [];
gdjs.test2Code.GDactive_9595stickObjects7= [];
gdjs.test2Code.GDtap_9595blockObjects1= [];
gdjs.test2Code.GDtap_9595blockObjects2= [];
gdjs.test2Code.GDtap_9595blockObjects3= [];
gdjs.test2Code.GDtap_9595blockObjects4= [];
gdjs.test2Code.GDtap_9595blockObjects5= [];
gdjs.test2Code.GDtap_9595blockObjects6= [];
gdjs.test2Code.GDtap_9595blockObjects7= [];
gdjs.test2Code.GDtech_9595spikeObjects1= [];
gdjs.test2Code.GDtech_9595spikeObjects2= [];
gdjs.test2Code.GDtech_9595spikeObjects3= [];
gdjs.test2Code.GDtech_9595spikeObjects4= [];
gdjs.test2Code.GDtech_9595spikeObjects5= [];
gdjs.test2Code.GDtech_9595spikeObjects6= [];
gdjs.test2Code.GDtech_9595spikeObjects7= [];
gdjs.test2Code.GDcapcanObjects1= [];
gdjs.test2Code.GDcapcanObjects2= [];
gdjs.test2Code.GDcapcanObjects3= [];
gdjs.test2Code.GDcapcanObjects4= [];
gdjs.test2Code.GDcapcanObjects5= [];
gdjs.test2Code.GDcapcanObjects6= [];
gdjs.test2Code.GDcapcanObjects7= [];
gdjs.test2Code.GDznakObjects1= [];
gdjs.test2Code.GDznakObjects2= [];
gdjs.test2Code.GDznakObjects3= [];
gdjs.test2Code.GDznakObjects4= [];
gdjs.test2Code.GDznakObjects5= [];
gdjs.test2Code.GDznakObjects6= [];
gdjs.test2Code.GDznakObjects7= [];
gdjs.test2Code.GDfake_9595wallObjects1= [];
gdjs.test2Code.GDfake_9595wallObjects2= [];
gdjs.test2Code.GDfake_9595wallObjects3= [];
gdjs.test2Code.GDfake_9595wallObjects4= [];
gdjs.test2Code.GDfake_9595wallObjects5= [];
gdjs.test2Code.GDfake_9595wallObjects6= [];
gdjs.test2Code.GDfake_9595wallObjects7= [];
gdjs.test2Code.GDdtObjects1= [];
gdjs.test2Code.GDdtObjects2= [];
gdjs.test2Code.GDdtObjects3= [];
gdjs.test2Code.GDdtObjects4= [];
gdjs.test2Code.GDdtObjects5= [];
gdjs.test2Code.GDdtObjects6= [];
gdjs.test2Code.GDdtObjects7= [];
gdjs.test2Code.GDNewBBTextObjects1= [];
gdjs.test2Code.GDNewBBTextObjects2= [];
gdjs.test2Code.GDNewBBTextObjects3= [];
gdjs.test2Code.GDNewBBTextObjects4= [];
gdjs.test2Code.GDNewBBTextObjects5= [];
gdjs.test2Code.GDNewBBTextObjects6= [];
gdjs.test2Code.GDNewBBTextObjects7= [];
gdjs.test2Code.GDgrass_9595blockObjects1= [];
gdjs.test2Code.GDgrass_9595blockObjects2= [];
gdjs.test2Code.GDgrass_9595blockObjects3= [];
gdjs.test2Code.GDgrass_9595blockObjects4= [];
gdjs.test2Code.GDgrass_9595blockObjects5= [];
gdjs.test2Code.GDgrass_9595blockObjects6= [];
gdjs.test2Code.GDgrass_9595blockObjects7= [];
gdjs.test2Code.GDblockObjects1= [];
gdjs.test2Code.GDblockObjects2= [];
gdjs.test2Code.GDblockObjects3= [];
gdjs.test2Code.GDblockObjects4= [];
gdjs.test2Code.GDblockObjects5= [];
gdjs.test2Code.GDblockObjects6= [];
gdjs.test2Code.GDblockObjects7= [];
gdjs.test2Code.GDmenuObjects1= [];
gdjs.test2Code.GDmenuObjects2= [];
gdjs.test2Code.GDmenuObjects3= [];
gdjs.test2Code.GDmenuObjects4= [];
gdjs.test2Code.GDmenuObjects5= [];
gdjs.test2Code.GDmenuObjects6= [];
gdjs.test2Code.GDmenuObjects7= [];
gdjs.test2Code.GDhomeObjects1= [];
gdjs.test2Code.GDhomeObjects2= [];
gdjs.test2Code.GDhomeObjects3= [];
gdjs.test2Code.GDhomeObjects4= [];
gdjs.test2Code.GDhomeObjects5= [];
gdjs.test2Code.GDhomeObjects6= [];
gdjs.test2Code.GDhomeObjects7= [];
gdjs.test2Code.GDresetObjects1= [];
gdjs.test2Code.GDresetObjects2= [];
gdjs.test2Code.GDresetObjects3= [];
gdjs.test2Code.GDresetObjects4= [];
gdjs.test2Code.GDresetObjects5= [];
gdjs.test2Code.GDresetObjects6= [];
gdjs.test2Code.GDresetObjects7= [];
gdjs.test2Code.GDspikeObjects1= [];
gdjs.test2Code.GDspikeObjects2= [];
gdjs.test2Code.GDspikeObjects3= [];
gdjs.test2Code.GDspikeObjects4= [];
gdjs.test2Code.GDspikeObjects5= [];
gdjs.test2Code.GDspikeObjects6= [];
gdjs.test2Code.GDspikeObjects7= [];
gdjs.test2Code.GDend_9595homeObjects1= [];
gdjs.test2Code.GDend_9595homeObjects2= [];
gdjs.test2Code.GDend_9595homeObjects3= [];
gdjs.test2Code.GDend_9595homeObjects4= [];
gdjs.test2Code.GDend_9595homeObjects5= [];
gdjs.test2Code.GDend_9595homeObjects6= [];
gdjs.test2Code.GDend_9595homeObjects7= [];
gdjs.test2Code.GDend_9595resetObjects1= [];
gdjs.test2Code.GDend_9595resetObjects2= [];
gdjs.test2Code.GDend_9595resetObjects3= [];
gdjs.test2Code.GDend_9595resetObjects4= [];
gdjs.test2Code.GDend_9595resetObjects5= [];
gdjs.test2Code.GDend_9595resetObjects6= [];
gdjs.test2Code.GDend_9595resetObjects7= [];
gdjs.test2Code.GDrobot_9595enemyObjects1= [];
gdjs.test2Code.GDrobot_9595enemyObjects2= [];
gdjs.test2Code.GDrobot_9595enemyObjects3= [];
gdjs.test2Code.GDrobot_9595enemyObjects4= [];
gdjs.test2Code.GDrobot_9595enemyObjects5= [];
gdjs.test2Code.GDrobot_9595enemyObjects6= [];
gdjs.test2Code.GDrobot_9595enemyObjects7= [];
gdjs.test2Code.GDslime_9595enemyObjects1= [];
gdjs.test2Code.GDslime_9595enemyObjects2= [];
gdjs.test2Code.GDslime_9595enemyObjects3= [];
gdjs.test2Code.GDslime_9595enemyObjects4= [];
gdjs.test2Code.GDslime_9595enemyObjects5= [];
gdjs.test2Code.GDslime_9595enemyObjects6= [];
gdjs.test2Code.GDslime_9595enemyObjects7= [];
gdjs.test2Code.GDrob_9595enemy_9595rightObjects1= [];
gdjs.test2Code.GDrob_9595enemy_9595rightObjects2= [];
gdjs.test2Code.GDrob_9595enemy_9595rightObjects3= [];
gdjs.test2Code.GDrob_9595enemy_9595rightObjects4= [];
gdjs.test2Code.GDrob_9595enemy_9595rightObjects5= [];
gdjs.test2Code.GDrob_9595enemy_9595rightObjects6= [];
gdjs.test2Code.GDrob_9595enemy_9595rightObjects7= [];
gdjs.test2Code.GDrob_9595enemy_9595leftObjects1= [];
gdjs.test2Code.GDrob_9595enemy_9595leftObjects2= [];
gdjs.test2Code.GDrob_9595enemy_9595leftObjects3= [];
gdjs.test2Code.GDrob_9595enemy_9595leftObjects4= [];
gdjs.test2Code.GDrob_9595enemy_9595leftObjects5= [];
gdjs.test2Code.GDrob_9595enemy_9595leftObjects6= [];
gdjs.test2Code.GDrob_9595enemy_9595leftObjects7= [];
gdjs.test2Code.GDheroObjects1= [];
gdjs.test2Code.GDheroObjects2= [];
gdjs.test2Code.GDheroObjects3= [];
gdjs.test2Code.GDheroObjects4= [];
gdjs.test2Code.GDheroObjects5= [];
gdjs.test2Code.GDheroObjects6= [];
gdjs.test2Code.GDheroObjects7= [];
gdjs.test2Code.GDsawObjects1= [];
gdjs.test2Code.GDsawObjects2= [];
gdjs.test2Code.GDsawObjects3= [];
gdjs.test2Code.GDsawObjects4= [];
gdjs.test2Code.GDsawObjects5= [];
gdjs.test2Code.GDsawObjects6= [];
gdjs.test2Code.GDsawObjects7= [];
gdjs.test2Code.GDcoin_9595markerObjects1= [];
gdjs.test2Code.GDcoin_9595markerObjects2= [];
gdjs.test2Code.GDcoin_9595markerObjects3= [];
gdjs.test2Code.GDcoin_9595markerObjects4= [];
gdjs.test2Code.GDcoin_9595markerObjects5= [];
gdjs.test2Code.GDcoin_9595markerObjects6= [];
gdjs.test2Code.GDcoin_9595markerObjects7= [];
gdjs.test2Code.GDcoin_9595marker2Objects1= [];
gdjs.test2Code.GDcoin_9595marker2Objects2= [];
gdjs.test2Code.GDcoin_9595marker2Objects3= [];
gdjs.test2Code.GDcoin_9595marker2Objects4= [];
gdjs.test2Code.GDcoin_9595marker2Objects5= [];
gdjs.test2Code.GDcoin_9595marker2Objects6= [];
gdjs.test2Code.GDcoin_9595marker2Objects7= [];
gdjs.test2Code.GDcoinsObjects1= [];
gdjs.test2Code.GDcoinsObjects2= [];
gdjs.test2Code.GDcoinsObjects3= [];
gdjs.test2Code.GDcoinsObjects4= [];
gdjs.test2Code.GDcoinsObjects5= [];
gdjs.test2Code.GDcoinsObjects6= [];
gdjs.test2Code.GDcoinsObjects7= [];
gdjs.test2Code.GDcoins2Objects1= [];
gdjs.test2Code.GDcoins2Objects2= [];
gdjs.test2Code.GDcoins2Objects3= [];
gdjs.test2Code.GDcoins2Objects4= [];
gdjs.test2Code.GDcoins2Objects5= [];
gdjs.test2Code.GDcoins2Objects6= [];
gdjs.test2Code.GDcoins2Objects7= [];
gdjs.test2Code.GDkey_9595lockerObjects1= [];
gdjs.test2Code.GDkey_9595lockerObjects2= [];
gdjs.test2Code.GDkey_9595lockerObjects3= [];
gdjs.test2Code.GDkey_9595lockerObjects4= [];
gdjs.test2Code.GDkey_9595lockerObjects5= [];
gdjs.test2Code.GDkey_9595lockerObjects6= [];
gdjs.test2Code.GDkey_9595lockerObjects7= [];
gdjs.test2Code.GDr_9595buttonObjects1= [];
gdjs.test2Code.GDr_9595buttonObjects2= [];
gdjs.test2Code.GDr_9595buttonObjects3= [];
gdjs.test2Code.GDr_9595buttonObjects4= [];
gdjs.test2Code.GDr_9595buttonObjects5= [];
gdjs.test2Code.GDr_9595buttonObjects6= [];
gdjs.test2Code.GDr_9595buttonObjects7= [];
gdjs.test2Code.GDl_9595buttonObjects1= [];
gdjs.test2Code.GDl_9595buttonObjects2= [];
gdjs.test2Code.GDl_9595buttonObjects3= [];
gdjs.test2Code.GDl_9595buttonObjects4= [];
gdjs.test2Code.GDl_9595buttonObjects5= [];
gdjs.test2Code.GDl_9595buttonObjects6= [];
gdjs.test2Code.GDl_9595buttonObjects7= [];
gdjs.test2Code.GDbackObjects1= [];
gdjs.test2Code.GDbackObjects2= [];
gdjs.test2Code.GDbackObjects3= [];
gdjs.test2Code.GDbackObjects4= [];
gdjs.test2Code.GDbackObjects5= [];
gdjs.test2Code.GDbackObjects6= [];
gdjs.test2Code.GDbackObjects7= [];
gdjs.test2Code.GDlockObjects1= [];
gdjs.test2Code.GDlockObjects2= [];
gdjs.test2Code.GDlockObjects3= [];
gdjs.test2Code.GDlockObjects4= [];
gdjs.test2Code.GDlockObjects5= [];
gdjs.test2Code.GDlockObjects6= [];
gdjs.test2Code.GDlockObjects7= [];
gdjs.test2Code.GDcamObjects1= [];
gdjs.test2Code.GDcamObjects2= [];
gdjs.test2Code.GDcamObjects3= [];
gdjs.test2Code.GDcamObjects4= [];
gdjs.test2Code.GDcamObjects5= [];
gdjs.test2Code.GDcamObjects6= [];
gdjs.test2Code.GDcamObjects7= [];
gdjs.test2Code.GDfonikObjects1= [];
gdjs.test2Code.GDfonikObjects2= [];
gdjs.test2Code.GDfonikObjects3= [];
gdjs.test2Code.GDfonikObjects4= [];
gdjs.test2Code.GDfonikObjects5= [];
gdjs.test2Code.GDfonikObjects6= [];
gdjs.test2Code.GDfonikObjects7= [];


gdjs.test2Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("hat"), gdjs.test2Code.GDhatObjects4);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);
{for(var i = 0, len = gdjs.test2Code.GDhatObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDhatObjects4[i].setPosition((( gdjs.test2Code.GDheroObjects4.length === 0 ) ? 0 :gdjs.test2Code.GDheroObjects4[0].getPointX("hat")),(( gdjs.test2Code.GDheroObjects4.length === 0 ) ? 0 :gdjs.test2Code.GDheroObjects4[0].getPointY("hat")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects4[i].getVariableNumber(gdjs.test2Code.GDheroObjects4[i].getVariables().getFromIndex(0)) == -(1) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects4[k] = gdjs.test2Code.GDheroObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66465316);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat"), gdjs.test2Code.GDhatObjects4);
{for(var i = 0, len = gdjs.test2Code.GDhatObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDhatObjects4[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects3[i].getVariableNumber(gdjs.test2Code.GDheroObjects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects3[k] = gdjs.test2Code.GDheroObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66466164);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat"), gdjs.test2Code.GDhatObjects3);
{for(var i = 0, len = gdjs.test2Code.GDhatObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDhatObjects3[i].flipX(false);
}
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcoinObjects3Objects = Hashtable.newFrom({"coin": gdjs.test2Code.GDcoinObjects3});
gdjs.test2Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("coin"), gdjs.test2Code.GDcoinObjects3);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcoinObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66467452);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDcoinObjects3 */
gdjs.copyArray(runtimeScene.getObjects("coins"), gdjs.test2Code.GDcoinsObjects3);
{for(var i = 0, len = gdjs.test2Code.GDcoinObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDcoinObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.test2Code.GDcoinsObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDcoinsObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.wav", false, 50, 1);
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDmenuObjects4Objects = Hashtable.newFrom({"menu": gdjs.test2Code.GDmenuObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDresetObjects4Objects = Hashtable.newFrom({"reset": gdjs.test2Code.GDresetObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDhomeObjects4Objects = Hashtable.newFrom({"home": gdjs.test2Code.GDhomeObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDend_95959595resetObjects4Objects = Hashtable.newFrom({"end_reset": gdjs.test2Code.GDend_9595resetObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDend_95959595homeObjects4Objects = Hashtable.newFrom({"end_home": gdjs.test2Code.GDend_9595homeObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDtext_95959595recordObjects4Objects = Hashtable.newFrom({"text_record": gdjs.test2Code.GDtext_9595recordObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDtext_95959595scoreObjects4Objects = Hashtable.newFrom({"text_score": gdjs.test2Code.GDtext_9595scoreObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDscoreObjects4Objects = Hashtable.newFrom({"score": gdjs.test2Code.GDscoreObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrecordObjects4Objects = Hashtable.newFrom({"record": gdjs.test2Code.GDrecordObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcoin_95959595markerObjects4Objects = Hashtable.newFrom({"coin_marker": gdjs.test2Code.GDcoin_9595markerObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcoinsObjects4Objects = Hashtable.newFrom({"coins": gdjs.test2Code.GDcoinsObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDscore2Objects6Objects = Hashtable.newFrom({"score2": gdjs.test2Code.GDscore2Objects6});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDscore2Objects5Objects = Hashtable.newFrom({"score2": gdjs.test2Code.GDscore2Objects5});
gdjs.test2Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 99;
if (isConditionTrue_0) {
gdjs.test2Code.GDscore2Objects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDscore2Objects6Objects, 610, 16, "hud");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 99;
if (isConditionTrue_0) {
gdjs.test2Code.GDscore2Objects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDscore2Objects5Objects, 560, 16, "hud");
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDscore2Objects6Objects = Hashtable.newFrom({"score2": gdjs.test2Code.GDscore2Objects6});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDscore2Objects5Objects = Hashtable.newFrom({"score2": gdjs.test2Code.GDscore2Objects5});
gdjs.test2Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) <= 99;
if (isConditionTrue_0) {
gdjs.test2Code.GDscore2Objects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDscore2Objects6Objects, 610, 16, "hud");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) > 99;
if (isConditionTrue_0) {
gdjs.test2Code.GDscore2Objects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDscore2Objects5Objects, 560, 16, "hud");
}}

}


};gdjs.test2Code.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "random";
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "next";
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.test2Code.GDcoinsObjects4 */
{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "coin", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(2));
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)));
}{for(var i = 0, len = gdjs.test2Code.GDcoinsObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDcoinsObjects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.test2Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.test2Code.GDcoin_9595markerObjects4.length = 0;

gdjs.test2Code.GDcoinsObjects4.length = 0;

gdjs.test2Code.GDend_9595homeObjects4.length = 0;

gdjs.test2Code.GDend_9595resetObjects4.length = 0;

gdjs.test2Code.GDhomeObjects4.length = 0;

gdjs.test2Code.GDmenuObjects4.length = 0;

gdjs.test2Code.GDrecordObjects4.length = 0;

gdjs.test2Code.GDresetObjects4.length = 0;

gdjs.test2Code.GDscoreObjects4.length = 0;

gdjs.test2Code.GDtext_9595recordObjects4.length = 0;

gdjs.test2Code.GDtext_9595scoreObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDmenuObjects4Objects, 16, 16, "hud");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDresetObjects4Objects, 150, 16, "hud");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDhomeObjects4Objects, 290, 16, "hud");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDend_95959595resetObjects4Objects, 50, 560, "hud");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDend_95959595homeObjects4Objects, 370, 560, "hud");
}{for(var i = 0, len = gdjs.test2Code.GDmenuObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDmenuObjects4[i].setSize(128, 128);
}
}{for(var i = 0, len = gdjs.test2Code.GDhomeObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDhomeObjects4[i].setSize(128, 128);
}
}{for(var i = 0, len = gdjs.test2Code.GDresetObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDresetObjects4[i].setSize(128, 128);
}
}{for(var i = 0, len = gdjs.test2Code.GDend_9595resetObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDend_9595resetObjects4[i].setSize(250, 250);
}
}{for(var i = 0, len = gdjs.test2Code.GDend_9595homeObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDend_9595homeObjects4[i].setSize(250, 250);
}
}{for(var i = 0, len = gdjs.test2Code.GDresetObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDresetObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.test2Code.GDhomeObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDhomeObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.test2Code.GDend_9595resetObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDend_9595resetObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.test2Code.GDend_9595homeObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDend_9595homeObjects4[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDtext_95959595recordObjects4Objects, 34, 81, "hud");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDtext_95959595scoreObjects4Objects, 34, 208, "hud");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDscoreObjects4Objects, (( gdjs.test2Code.GDtext_9595scoreObjects4.length === 0 ) ? 0 :gdjs.test2Code.GDtext_9595scoreObjects4[0].getCenterXInScene()) + 200, 208, "hud");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrecordObjects4Objects, (( gdjs.test2Code.GDtext_9595recordObjects4.length === 0 ) ? 0 :gdjs.test2Code.GDtext_9595recordObjects4[0].getCenterXInScene()) + 250, 81, "hud");
}{for(var i = 0, len = gdjs.test2Code.GDrecordObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDrecordObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.test2Code.GDscoreObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDscoreObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.test2Code.GDtext_9595recordObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDtext_9595recordObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.test2Code.GDtext_9595scoreObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDtext_9595scoreObjects4[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcoin_95959595markerObjects4Objects, 0, 1320, "hud");
}{for(var i = 0, len = gdjs.test2Code.GDcoin_9595markerObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDcoin_9595markerObjects4[i].setSize(96, 96);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcoinsObjects4Objects, 91, 1320, "hud");
}
{ //Subevents
gdjs.test2Code.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.asyncCallback66473172 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("home"), gdjs.test2Code.GDhomeObjects6);

{for(var i = 0, len = gdjs.test2Code.GDhomeObjects6.length ;i < len;++i) {
    gdjs.test2Code.GDhomeObjects6[i].setAnimationName("home");
}
}}
gdjs.test2Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.test2Code.GDhomeObjects5) asyncObjectsList.addObject("home", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.test2Code.asyncCallback66473172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.asyncCallback66474332 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("reset"), gdjs.test2Code.GDresetObjects5);

{for(var i = 0, len = gdjs.test2Code.GDresetObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDresetObjects5[i].setAnimationName("reset");
}
}}
gdjs.test2Code.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.test2Code.GDresetObjects4) asyncObjectsList.addObject("reset", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.test2Code.asyncCallback66474332(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.test2Code.GDhomeObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDhomeObjects5.length;i<l;++i) {
    if ( gdjs.test2Code.GDhomeObjects5[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDhomeObjects5[k] = gdjs.test2Code.GDhomeObjects5[i];
        ++k;
    }
}
gdjs.test2Code.GDhomeObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDhomeObjects5.length;i<l;++i) {
    if ( gdjs.test2Code.GDhomeObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDhomeObjects5[k] = gdjs.test2Code.GDhomeObjects5[i];
        ++k;
    }
}
gdjs.test2Code.GDhomeObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66473100);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDhomeObjects5 */
{for(var i = 0, len = gdjs.test2Code.GDhomeObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDhomeObjects5[i].setAnimationName("1");
}
}
{ //Subevents
gdjs.test2Code.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.test2Code.GDhomeObjects4);
gdjs.copyArray(runtimeScene.getObjects("reset"), gdjs.test2Code.GDresetObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDresetObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDresetObjects4[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDresetObjects4[k] = gdjs.test2Code.GDresetObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDresetObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDhomeObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDhomeObjects4[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDhomeObjects4[k] = gdjs.test2Code.GDhomeObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDhomeObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66474260);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDresetObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDresetObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDresetObjects4[i].setAnimationName("1");
}
}
{ //Subevents
gdjs.test2Code.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDmenuObjects5Objects = Hashtable.newFrom({"menu": gdjs.test2Code.GDmenuObjects5});
gdjs.test2Code.asyncCallback66476492 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.test2Code.GDhomeObjects7);
gdjs.copyArray(asyncObjectsList.getObjects("menu"), gdjs.test2Code.GDmenuObjects7);

gdjs.copyArray(runtimeScene.getObjects("reset"), gdjs.test2Code.GDresetObjects7);
{for(var i = 0, len = gdjs.test2Code.GDmenuObjects7.length ;i < len;++i) {
    gdjs.test2Code.GDmenuObjects7[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.test2Code.GDhomeObjects7.length ;i < len;++i) {
    gdjs.test2Code.GDhomeObjects7[i].hide(false);
}
}{for(var i = 0, len = gdjs.test2Code.GDresetObjects7.length ;i < len;++i) {
    gdjs.test2Code.GDresetObjects7[i].hide(false);
}
}}
gdjs.test2Code.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.test2Code.GDmenuObjects6) asyncObjectsList.addObject("menu", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.test2Code.asyncCallback66476492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.asyncCallback66477452 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.test2Code.GDhomeObjects6);
gdjs.copyArray(asyncObjectsList.getObjects("menu"), gdjs.test2Code.GDmenuObjects6);

gdjs.copyArray(runtimeScene.getObjects("reset"), gdjs.test2Code.GDresetObjects6);
{for(var i = 0, len = gdjs.test2Code.GDmenuObjects6.length ;i < len;++i) {
    gdjs.test2Code.GDmenuObjects6[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.test2Code.GDresetObjects6.length ;i < len;++i) {
    gdjs.test2Code.GDresetObjects6[i].hide();
}
}{for(var i = 0, len = gdjs.test2Code.GDhomeObjects6.length ;i < len;++i) {
    gdjs.test2Code.GDhomeObjects6[i].hide();
}
}}
gdjs.test2Code.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.test2Code.GDmenuObjects5) asyncObjectsList.addObject("menu", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.test2Code.asyncCallback66477452(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.test2Code.GDmenuObjects5, gdjs.test2Code.GDmenuObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDmenuObjects6.length;i<l;++i) {
    if ( gdjs.test2Code.GDmenuObjects6[i].getAnimation() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDmenuObjects6[k] = gdjs.test2Code.GDmenuObjects6[i];
        ++k;
    }
}
gdjs.test2Code.GDmenuObjects6.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList9(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.test2Code.GDmenuObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDmenuObjects5.length;i<l;++i) {
    if ( gdjs.test2Code.GDmenuObjects5[i].getAnimation() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDmenuObjects5[k] = gdjs.test2Code.GDmenuObjects5[i];
        ++k;
    }
}
gdjs.test2Code.GDmenuObjects5.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDhomeObjects5Objects = Hashtable.newFrom({"home": gdjs.test2Code.GDhomeObjects5});
gdjs.test2Code.asyncCallback66478612 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}}
gdjs.test2Code.eventsList12 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.test2Code.asyncCallback66478612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDend_95959595resetObjects5Objects = Hashtable.newFrom({"end_reset": gdjs.test2Code.GDend_9595resetObjects5});
gdjs.test2Code.asyncCallback66479668 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)), false);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}}
gdjs.test2Code.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.test2Code.asyncCallback66479668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDend_95959595homeObjects5Objects = Hashtable.newFrom({"end_home": gdjs.test2Code.GDend_9595homeObjects5});
gdjs.test2Code.asyncCallback66480780 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}}
gdjs.test2Code.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.test2Code.asyncCallback66480780(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDresetObjects4Objects = Hashtable.newFrom({"reset": gdjs.test2Code.GDresetObjects4});
gdjs.test2Code.asyncCallback66481812 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)), false);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}}
gdjs.test2Code.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.test2Code.asyncCallback66481812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.test2Code.GDmenuObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDmenuObjects5Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.test2Code.GDhomeObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDhomeObjects5Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDhomeObjects5.length;i<l;++i) {
    if ( gdjs.test2Code.GDhomeObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDhomeObjects5[k] = gdjs.test2Code.GDhomeObjects5[i];
        ++k;
    }
}
gdjs.test2Code.GDhomeObjects5.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("end_reset"), gdjs.test2Code.GDend_9595resetObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDend_95959595resetObjects5Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDend_9595resetObjects5.length;i<l;++i) {
    if ( gdjs.test2Code.GDend_9595resetObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDend_9595resetObjects5[k] = gdjs.test2Code.GDend_9595resetObjects5[i];
        ++k;
    }
}
gdjs.test2Code.GDend_9595resetObjects5.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("end_home"), gdjs.test2Code.GDend_9595homeObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDend_95959595homeObjects5Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDend_9595homeObjects5.length;i<l;++i) {
    if ( gdjs.test2Code.GDend_9595homeObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDend_9595homeObjects5[k] = gdjs.test2Code.GDend_9595homeObjects5[i];
        ++k;
    }
}
gdjs.test2Code.GDend_9595homeObjects5.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.test2Code.GDhomeObjects4);
gdjs.copyArray(runtimeScene.getObjects("reset"), gdjs.test2Code.GDresetObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDresetObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDhomeObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDhomeObjects4[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDhomeObjects4[k] = gdjs.test2Code.GDhomeObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDhomeObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66475300);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDmenuObjects4Objects = Hashtable.newFrom({"menu": gdjs.test2Code.GDmenuObjects4});
gdjs.test2Code.eventsList18 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects4[i].getVariableNumber(gdjs.test2Code.GDheroObjects4[i].getVariables().getFromIndex(0)) == -(1) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects4[k] = gdjs.test2Code.GDheroObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDheroObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects4[i].getVariableNumber(gdjs.test2Code.GDheroObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects4[k] = gdjs.test2Code.GDheroObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDheroObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.test2Code.GDmenuObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDmenuObjects4Objects, runtimeScene, true, true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);
{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects3[i].getBehavior("WallJump").HasJustWallJumped((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects3[k] = gdjs.test2Code.GDheroObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDheroObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].returnVariable(gdjs.test2Code.GDheroObjects3[i].getVariables().getFromIndex(0)).mul(-(1));
}
}}

}


};gdjs.test2Code.eventsList19 = function(runtimeScene) {

{


gdjs.test2Code.eventsList5(runtimeScene);
}


{


gdjs.test2Code.eventsList8(runtimeScene);
}


{


gdjs.test2Code.eventsList17(runtimeScene);
}


{


gdjs.test2Code.eventsList18(runtimeScene);
}


};gdjs.test2Code.eventsList20 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.test2Code.GDrecordObjects5, gdjs.test2Code.GDrecordObjects6);

{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "record", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}{for(var i = 0, len = gdjs.test2Code.GDrecordObjects6.length ;i < len;++i) {
    gdjs.test2Code.GDrecordObjects6[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))));
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.test2Code.GDscoreObjects5 */
{for(var i = 0, len = gdjs.test2Code.GDscoreObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDscoreObjects5[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))));
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}}

}


};gdjs.test2Code.eventsList21 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) != 10;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("end_home"), gdjs.test2Code.GDend_9595homeObjects6);
gdjs.copyArray(runtimeScene.getObjects("end_reset"), gdjs.test2Code.GDend_9595resetObjects6);
{for(var i = 0, len = gdjs.test2Code.GDend_9595homeObjects6.length ;i < len;++i) {
    gdjs.test2Code.GDend_9595homeObjects6[i].hide(false);
}
}{for(var i = 0, len = gdjs.test2Code.GDend_9595resetObjects6.length ;i < len;++i) {
    gdjs.test2Code.GDend_9595resetObjects6[i].hide(false);
}
}}

}


{


gdjs.test2Code.eventsList20(runtimeScene, asyncObjectsList);
}


};gdjs.test2Code.asyncCallback66488444 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("record"), gdjs.test2Code.GDrecordObjects5);
gdjs.copyArray(runtimeScene.getObjects("score"), gdjs.test2Code.GDscoreObjects5);
gdjs.copyArray(runtimeScene.getObjects("text_record"), gdjs.test2Code.GDtext_9595recordObjects5);
gdjs.copyArray(runtimeScene.getObjects("text_score"), gdjs.test2Code.GDtext_9595scoreObjects5);
{for(var i = 0, len = gdjs.test2Code.GDtext_9595scoreObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDtext_9595scoreObjects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.test2Code.GDtext_9595recordObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDtext_9595recordObjects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.test2Code.GDscoreObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDscoreObjects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.test2Code.GDrecordObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDrecordObjects5[i].hide(false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(11).add(1);
}
{ //Subevents
gdjs.test2Code.eventsList21(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.test2Code.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.test2Code.asyncCallback66488444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.asyncCallback66494060 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("end_home"), gdjs.test2Code.GDend_9595homeObjects7);
gdjs.copyArray(runtimeScene.getObjects("end_reset"), gdjs.test2Code.GDend_9595resetObjects7);
{for(var i = 0, len = gdjs.test2Code.GDend_9595homeObjects7.length ;i < len;++i) {
    gdjs.test2Code.GDend_9595homeObjects7[i].hide(false);
}
}{for(var i = 0, len = gdjs.test2Code.GDend_9595resetObjects7.length ;i < len;++i) {
    gdjs.test2Code.GDend_9595resetObjects7[i].hide(false);
}
}}
gdjs.test2Code.eventsList23 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.test2Code.asyncCallback66494060(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.test2Code.eventsList23(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.test2Code.asyncCallback66493348 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtsExt__YandexGamesSDK__ShowInterstitialAd.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.test2Code.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.test2Code.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.test2Code.asyncCallback66493348(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.eventsList26 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(0);
}
{ //Subevents
gdjs.test2Code.eventsList25(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins"), gdjs.test2Code.GDcoinsObjects4);
{runtimeScene.getGame().getVariables().getFromIndex(4).add(5);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.test2Code.GDcoinsObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDcoinsObjects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.test2Code.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects4[i].getVariableBoolean(gdjs.test2Code.GDheroObjects4[i].getVariables().getFromIndex(1), false) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects4[k] = gdjs.test2Code.GDheroObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66485980);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat"), gdjs.test2Code.GDhatObjects4);
/* Reuse gdjs.test2Code.GDheroObjects4 */
gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.test2Code.GDhomeObjects4);
gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.test2Code.GDmenuObjects4);
gdjs.copyArray(runtimeScene.getObjects("reset"), gdjs.test2Code.GDresetObjects4);
gdjs.copyArray(runtimeScene.getObjects("score2"), gdjs.test2Code.GDscore2Objects4);
{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").setCurrentSpeed(0);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].returnVariable(gdjs.test2Code.GDheroObjects4[i].getVariables().getFromIndex(0)).setNumber(2);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerCharacterAnimator").SetIdleAnimationName("Dead", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerCharacterAnimator").SetClimbAnimationName("Dead", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").setJumpSpeed(0);
}
}{for(var i = 0, len = gdjs.test2Code.GDmenuObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDmenuObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.test2Code.GDhatObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDhatObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.test2Code.GDhomeObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDhomeObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.test2Code.GDresetObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDresetObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.test2Code.GDscore2Objects4.length ;i < len;++i) {
    gdjs.test2Code.GDscore2Objects4[i].hide();
}
}
{ //Subevents
gdjs.test2Code.eventsList22(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) == 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66492436);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.fadeSoundVolume(runtimeScene, 1, 0, 1);
}
{ //Subevents
gdjs.test2Code.eventsList26(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects3[i].getVariableBoolean(gdjs.test2Code.GDheroObjects3[i].getVariables().getFromIndex(1), false) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects3[k] = gdjs.test2Code.GDheroObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.test2Code.eventsList28 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects2.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects2[i].getBehavior("WallJump").IsAgaintWall((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects2[k] = gdjs.test2Code.GDheroObjects2[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDheroObjects2 */
{for(var i = 0, len = gdjs.test2Code.GDheroObjects2.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects2[i].setAnimationName("Climb");
}
}}

}


};gdjs.test2Code.eventsList29 = function(runtimeScene) {

{


gdjs.test2Code.eventsList0(runtimeScene);
}


{


gdjs.test2Code.eventsList1(runtimeScene);
}


{


gdjs.test2Code.eventsList19(runtimeScene);
}


{


gdjs.test2Code.eventsList27(runtimeScene);
}


{


gdjs.test2Code.eventsList28(runtimeScene);
}


};gdjs.test2Code.eventsList30 = function(runtimeScene) {

{



}


};gdjs.test2Code.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.test2Code.GDheroObjects2.length === 0 ) ? 0 :gdjs.test2Code.GDheroObjects2[0].getCenterXInScene()) * 0.2, "background", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.test2Code.GDheroObjects2.length === 0 ) ? 0 :gdjs.test2Code.GDheroObjects2[0].getCenterXInScene()) * 0.4, "midleground", 0);
}
{ //Subevents
gdjs.test2Code.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.eventsList32 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("camera_stoper"), gdjs.test2Code.GDcamera_9595stoperObjects2);
{gdjs.evtTools.camera.clampCamera(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs.test2Code.GDcamera_9595stoperObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.test2Code.GDcamera_9595stoperObjects2[0].getVariables()).getFromIndex(3))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.test2Code.GDcamera_9595stoperObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.test2Code.GDcamera_9595stoperObjects2[0].getVariables()).getFromIndex(0))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.test2Code.GDcamera_9595stoperObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.test2Code.GDcamera_9595stoperObjects2[0].getVariables()).getFromIndex(2))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.test2Code.GDcamera_9595stoperObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.test2Code.GDcamera_9595stoperObjects2[0].getVariables()).getFromIndex(1))), "", 0);
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcoinObjects3Objects = Hashtable.newFrom({"coin": gdjs.test2Code.GDcoinObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects2Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects2});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDactive_95959595stickObjects2Objects = Hashtable.newFrom({"active_stick": gdjs.test2Code.GDactive_9595stickObjects2});
gdjs.test2Code.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects3[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects3[k] = gdjs.test2Code.GDheroObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66501564);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jumpNew.wav", false, 15, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects3[i].getVariableBoolean(gdjs.test2Code.GDheroObjects3[i].getVariables().getFromIndex(1), false) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects3[k] = gdjs.test2Code.GDheroObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66502388);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "death3.wav", false, 20, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("coin"), gdjs.test2Code.GDcoinObjects3);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcoinObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66503268);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "coin.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("active_stick"), gdjs.test2Code.GDactive_9595stickObjects2);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects2Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDactive_95959595stickObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDactive_9595stickObjects2.length;i<l;++i) {
    if ( gdjs.test2Code.GDactive_9595stickObjects2[i].getAnimation() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDactive_9595stickObjects2[k] = gdjs.test2Code.GDactive_9595stickObjects2[i];
        ++k;
    }
}
gdjs.test2Code.GDactive_9595stickObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66504204);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "stick2.wav", false, 50, 1);
}}

}


};gdjs.test2Code.eventsList34 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("record"), gdjs.test2Code.GDrecordObjects4);
gdjs.copyArray(runtimeScene.getObjects("score"), gdjs.test2Code.GDscoreObjects4);
gdjs.copyArray(gdjs.test2Code.GDscore2Objects2, gdjs.test2Code.GDscore2Objects4);

gdjs.copyArray(runtimeScene.getObjects("text_record"), gdjs.test2Code.GDtext_9595recordObjects4);
gdjs.copyArray(runtimeScene.getObjects("text_score"), gdjs.test2Code.GDtext_9595scoreObjects4);
{for(var i = 0, len = gdjs.test2Code.GDtext_9595scoreObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDtext_9595scoreObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.test2Code.GDtext_9595recordObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDtext_9595recordObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.test2Code.GDscoreObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDscoreObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.test2Code.GDrecordObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDrecordObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.test2Code.GDscore2Objects4.length ;i < len;++i) {
    gdjs.test2Code.GDscore2Objects4[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) - 2));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) == 141;
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "level", 3);
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDhatObjects3Objects = Hashtable.newFrom({"hat": gdjs.test2Code.GDhatObjects3});
gdjs.test2Code.eventsList35 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.test2Code.GDbackgroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("block"), gdjs.test2Code.GDblockObjects3);
gdjs.copyArray(runtimeScene.getObjects("brocken_block"), gdjs.test2Code.GDbrocken_9595blockObjects3);
gdjs.copyArray(runtimeScene.getObjects("fake_wall"), gdjs.test2Code.GDfake_9595wallObjects3);
gdjs.copyArray(runtimeScene.getObjects("fly1"), gdjs.test2Code.GDfly1Objects3);
gdjs.copyArray(runtimeScene.getObjects("fly2"), gdjs.test2Code.GDfly2Objects3);
gdjs.copyArray(runtimeScene.getObjects("foreground"), gdjs.test2Code.GDforegroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("grass_block"), gdjs.test2Code.GDgrass_9595blockObjects3);
gdjs.copyArray(runtimeScene.getObjects("midleground"), gdjs.test2Code.GDmidlegroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("trava1"), gdjs.test2Code.GDtrava1Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava2"), gdjs.test2Code.GDtrava2Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava3"), gdjs.test2Code.GDtrava3Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava4"), gdjs.test2Code.GDtrava4Objects3);
{for(var i = 0, len = gdjs.test2Code.GDgrass_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDgrass_9595blockObjects3[i].setColor("175;255;193");
}
}{for(var i = 0, len = gdjs.test2Code.GDblockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDblockObjects3[i].setColor("175;255;193");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava1Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava1Objects3[i].setColor("175;255;193");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava2Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava2Objects3[i].setColor("175;255;193");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava3Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava3Objects3[i].setColor("175;255;193");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava4Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava4Objects3[i].setColor("175;255;193");
}
}{for(var i = 0, len = gdjs.test2Code.GDfly2Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDfly2Objects3[i].setColor("175;255;193");
}
}{for(var i = 0, len = gdjs.test2Code.GDfly1Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDfly1Objects3[i].setColor("175;255;193");
}
}{for(var i = 0, len = gdjs.test2Code.GDbrocken_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDbrocken_9595blockObjects3[i].setColor("175;255;193");
}
}{for(var i = 0, len = gdjs.test2Code.GDforegroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDforegroundObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.test2Code.GDmidlegroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDmidlegroundObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.test2Code.GDbackgroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDbackgroundObjects3[i].setAnimation(1);
}
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "61;110;112");
}{for(var i = 0, len = gdjs.test2Code.GDfake_9595wallObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDfake_9595wallObjects3[i].setColor("175;255;193");
}
}}

}


};gdjs.test2Code.eventsList36 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.test2Code.GDbackgroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("block"), gdjs.test2Code.GDblockObjects3);
gdjs.copyArray(runtimeScene.getObjects("brocken_block"), gdjs.test2Code.GDbrocken_9595blockObjects3);
gdjs.copyArray(runtimeScene.getObjects("fake_wall"), gdjs.test2Code.GDfake_9595wallObjects3);
gdjs.copyArray(runtimeScene.getObjects("fly1"), gdjs.test2Code.GDfly1Objects3);
gdjs.copyArray(runtimeScene.getObjects("fly2"), gdjs.test2Code.GDfly2Objects3);
gdjs.copyArray(runtimeScene.getObjects("foreground"), gdjs.test2Code.GDforegroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("grass_block"), gdjs.test2Code.GDgrass_9595blockObjects3);
gdjs.copyArray(runtimeScene.getObjects("midleground"), gdjs.test2Code.GDmidlegroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("trava1"), gdjs.test2Code.GDtrava1Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava2"), gdjs.test2Code.GDtrava2Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava3"), gdjs.test2Code.GDtrava3Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava4"), gdjs.test2Code.GDtrava4Objects3);
{for(var i = 0, len = gdjs.test2Code.GDgrass_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDgrass_9595blockObjects3[i].setColor("255;149;149");
}
}{for(var i = 0, len = gdjs.test2Code.GDblockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDblockObjects3[i].setColor("255;149;149");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava1Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava1Objects3[i].setColor("255;185;135");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava2Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava2Objects3[i].setColor("255;185;135");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava3Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava3Objects3[i].setColor("255;185;135");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava4Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava4Objects3[i].setColor("255;185;135");
}
}{for(var i = 0, len = gdjs.test2Code.GDfly2Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDfly2Objects3[i].setColor("255;149;149");
}
}{for(var i = 0, len = gdjs.test2Code.GDfly1Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDfly1Objects3[i].setColor("255;149;149");
}
}{for(var i = 0, len = gdjs.test2Code.GDbrocken_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDbrocken_9595blockObjects3[i].setColor("255;149;149");
}
}{for(var i = 0, len = gdjs.test2Code.GDforegroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDforegroundObjects3[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.test2Code.GDmidlegroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDmidlegroundObjects3[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.test2Code.GDbackgroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDbackgroundObjects3[i].setAnimation(2);
}
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "137;67;62");
}{for(var i = 0, len = gdjs.test2Code.GDfake_9595wallObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDfake_9595wallObjects3[i].setColor("255;149;149");
}
}}

}


};gdjs.test2Code.eventsList37 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.test2Code.GDbackgroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("block"), gdjs.test2Code.GDblockObjects3);
gdjs.copyArray(runtimeScene.getObjects("brocken_block"), gdjs.test2Code.GDbrocken_9595blockObjects3);
gdjs.copyArray(runtimeScene.getObjects("fake_wall"), gdjs.test2Code.GDfake_9595wallObjects3);
gdjs.copyArray(runtimeScene.getObjects("fly1"), gdjs.test2Code.GDfly1Objects3);
gdjs.copyArray(runtimeScene.getObjects("fly2"), gdjs.test2Code.GDfly2Objects3);
gdjs.copyArray(runtimeScene.getObjects("foreground"), gdjs.test2Code.GDforegroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("grass_block"), gdjs.test2Code.GDgrass_9595blockObjects3);
gdjs.copyArray(runtimeScene.getObjects("midleground"), gdjs.test2Code.GDmidlegroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("trava1"), gdjs.test2Code.GDtrava1Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava2"), gdjs.test2Code.GDtrava2Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava3"), gdjs.test2Code.GDtrava3Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava4"), gdjs.test2Code.GDtrava4Objects3);
{for(var i = 0, len = gdjs.test2Code.GDgrass_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDgrass_9595blockObjects3[i].setColor("160;180;212");
}
}{for(var i = 0, len = gdjs.test2Code.GDblockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDblockObjects3[i].setColor("160;180;212");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava1Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava1Objects3[i].setColor("131;207;100");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava2Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava2Objects3[i].setColor("131;207;100");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava3Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava3Objects3[i].setColor("131;207;100");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava4Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava4Objects3[i].setColor("131;207;100");
}
}{for(var i = 0, len = gdjs.test2Code.GDfly2Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDfly2Objects3[i].setColor("160;180;212");
}
}{for(var i = 0, len = gdjs.test2Code.GDfly1Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDfly1Objects3[i].setColor("160;180;212");
}
}{for(var i = 0, len = gdjs.test2Code.GDbrocken_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDbrocken_9595blockObjects3[i].setColor("160;180;212");
}
}{for(var i = 0, len = gdjs.test2Code.GDforegroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDforegroundObjects3[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.test2Code.GDmidlegroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDmidlegroundObjects3[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.test2Code.GDbackgroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDbackgroundObjects3[i].setAnimation(3);
}
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "62;113;137");
}{for(var i = 0, len = gdjs.test2Code.GDfake_9595wallObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDfake_9595wallObjects3[i].setColor("160;180;212");
}
}}

}


};gdjs.test2Code.eventsList38 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.test2Code.GDbackgroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("block"), gdjs.test2Code.GDblockObjects3);
gdjs.copyArray(runtimeScene.getObjects("brocken_block"), gdjs.test2Code.GDbrocken_9595blockObjects3);
gdjs.copyArray(runtimeScene.getObjects("fake_wall"), gdjs.test2Code.GDfake_9595wallObjects3);
gdjs.copyArray(runtimeScene.getObjects("fly1"), gdjs.test2Code.GDfly1Objects3);
gdjs.copyArray(runtimeScene.getObjects("fly2"), gdjs.test2Code.GDfly2Objects3);
gdjs.copyArray(runtimeScene.getObjects("foreground"), gdjs.test2Code.GDforegroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("grass_block"), gdjs.test2Code.GDgrass_9595blockObjects3);
gdjs.copyArray(runtimeScene.getObjects("midleground"), gdjs.test2Code.GDmidlegroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("trava1"), gdjs.test2Code.GDtrava1Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava2"), gdjs.test2Code.GDtrava2Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava3"), gdjs.test2Code.GDtrava3Objects3);
gdjs.copyArray(runtimeScene.getObjects("trava4"), gdjs.test2Code.GDtrava4Objects3);
{for(var i = 0, len = gdjs.test2Code.GDgrass_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDgrass_9595blockObjects3[i].setColor("248;248;248");
}
}{for(var i = 0, len = gdjs.test2Code.GDblockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDblockObjects3[i].setColor("248;248;248");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava1Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava1Objects3[i].setColor("248;248;248");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava2Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava2Objects3[i].setColor("248;248;248");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava3Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava3Objects3[i].setColor("248;248;248");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava4Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDtrava4Objects3[i].setColor("248;248;248");
}
}{for(var i = 0, len = gdjs.test2Code.GDfly2Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDfly2Objects3[i].setColor("248;248;248");
}
}{for(var i = 0, len = gdjs.test2Code.GDfly1Objects3.length ;i < len;++i) {
    gdjs.test2Code.GDfly1Objects3[i].setColor("248;248;248");
}
}{for(var i = 0, len = gdjs.test2Code.GDbrocken_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDbrocken_9595blockObjects3[i].setColor("248;248;248");
}
}{for(var i = 0, len = gdjs.test2Code.GDforegroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDforegroundObjects3[i].setAnimation(4);
}
}{for(var i = 0, len = gdjs.test2Code.GDmidlegroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDmidlegroundObjects3[i].setAnimation(4);
}
}{for(var i = 0, len = gdjs.test2Code.GDbackgroundObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDbackgroundObjects3[i].setAnimation(4);
}
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "104;127;158");
}{for(var i = 0, len = gdjs.test2Code.GDfake_9595wallObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDfake_9595wallObjects3[i].setColor("248;248;248");
}
}}

}


};gdjs.test2Code.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.test2Code.GDbackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("block"), gdjs.test2Code.GDblockObjects2);
gdjs.copyArray(runtimeScene.getObjects("brocken_block"), gdjs.test2Code.GDbrocken_9595blockObjects2);
gdjs.copyArray(runtimeScene.getObjects("fake_wall"), gdjs.test2Code.GDfake_9595wallObjects2);
gdjs.copyArray(runtimeScene.getObjects("fly1"), gdjs.test2Code.GDfly1Objects2);
gdjs.copyArray(runtimeScene.getObjects("fly2"), gdjs.test2Code.GDfly2Objects2);
gdjs.copyArray(runtimeScene.getObjects("foreground"), gdjs.test2Code.GDforegroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("grass_block"), gdjs.test2Code.GDgrass_9595blockObjects2);
gdjs.copyArray(runtimeScene.getObjects("midleground"), gdjs.test2Code.GDmidlegroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("trava1"), gdjs.test2Code.GDtrava1Objects2);
gdjs.copyArray(runtimeScene.getObjects("trava2"), gdjs.test2Code.GDtrava2Objects2);
gdjs.copyArray(runtimeScene.getObjects("trava3"), gdjs.test2Code.GDtrava3Objects2);
gdjs.copyArray(runtimeScene.getObjects("trava4"), gdjs.test2Code.GDtrava4Objects2);
{for(var i = 0, len = gdjs.test2Code.GDgrass_9595blockObjects2.length ;i < len;++i) {
    gdjs.test2Code.GDgrass_9595blockObjects2[i].setColor("243;232;181");
}
}{for(var i = 0, len = gdjs.test2Code.GDblockObjects2.length ;i < len;++i) {
    gdjs.test2Code.GDblockObjects2[i].setColor("243;232;181");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava1Objects2.length ;i < len;++i) {
    gdjs.test2Code.GDtrava1Objects2[i].setColor("243;232;181");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava2Objects2.length ;i < len;++i) {
    gdjs.test2Code.GDtrava2Objects2[i].setColor("243;232;181");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava3Objects2.length ;i < len;++i) {
    gdjs.test2Code.GDtrava3Objects2[i].setColor("243;232;181");
}
}{for(var i = 0, len = gdjs.test2Code.GDtrava4Objects2.length ;i < len;++i) {
    gdjs.test2Code.GDtrava4Objects2[i].setColor("243;232;181");
}
}{for(var i = 0, len = gdjs.test2Code.GDfly2Objects2.length ;i < len;++i) {
    gdjs.test2Code.GDfly2Objects2[i].setColor("243;232;181");
}
}{for(var i = 0, len = gdjs.test2Code.GDfly1Objects2.length ;i < len;++i) {
    gdjs.test2Code.GDfly1Objects2[i].setColor("243;232;181");
}
}{for(var i = 0, len = gdjs.test2Code.GDbrocken_9595blockObjects2.length ;i < len;++i) {
    gdjs.test2Code.GDbrocken_9595blockObjects2[i].setColor("243;232;181");
}
}{for(var i = 0, len = gdjs.test2Code.GDforegroundObjects2.length ;i < len;++i) {
    gdjs.test2Code.GDforegroundObjects2[i].setAnimation(5);
}
}{for(var i = 0, len = gdjs.test2Code.GDmidlegroundObjects2.length ;i < len;++i) {
    gdjs.test2Code.GDmidlegroundObjects2[i].setAnimation(5);
}
}{for(var i = 0, len = gdjs.test2Code.GDbackgroundObjects2.length ;i < len;++i) {
    gdjs.test2Code.GDbackgroundObjects2[i].setAnimation(5);
}
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "224;197;125");
}{for(var i = 0, len = gdjs.test2Code.GDfake_9595wallObjects2.length ;i < len;++i) {
    gdjs.test2Code.GDfake_9595wallObjects2[i].setColor("243;232;181");
}
}}

}


};gdjs.test2Code.eventsList40 = function(runtimeScene) {

{


gdjs.test2Code.eventsList35(runtimeScene);
}


{


gdjs.test2Code.eventsList36(runtimeScene);
}


{


gdjs.test2Code.eventsList37(runtimeScene);
}


{


gdjs.test2Code.eventsList38(runtimeScene);
}


{


gdjs.test2Code.eventsList39(runtimeScene);
}


};gdjs.test2Code.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.getSoundOnChannelVolume(runtimeScene, 1) == 0;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 1, 20);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) > 140;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "random";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, gdjs.evtTools.common.toString(gdjs.randomInRange(3, 140)), 0, 0, 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "next";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) < 141;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9))), 0, 0, 0);
}
{ //Subevents
gdjs.test2Code.eventsList34(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);
{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].returnVariable(gdjs.test2Code.GDheroObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("record"), gdjs.test2Code.GDrecordObjects3);
{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "record", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1));
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}{for(var i = 0, len = gdjs.test2Code.GDrecordObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDrecordObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))));
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "hat", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(3));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)));
}{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "fon", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(4));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);
gdjs.test2Code.GDhatObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDhatObjects3Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.test2Code.GDhatObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDhatObjects3[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.test2Code.GDhatObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDhatObjects3[i].setZOrder(999);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].setZOrder(998);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("rob_enemy_left"), gdjs.test2Code.GDrob_9595enemy_9595leftObjects3);
gdjs.copyArray(runtimeScene.getObjects("rob_enemy_right"), gdjs.test2Code.GDrob_9595enemy_9595rightObjects3);
{for(var i = 0, len = gdjs.test2Code.GDrob_9595enemy_9595leftObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDrob_9595enemy_9595leftObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.test2Code.GDrob_9595enemy_9595rightObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDrob_9595enemy_9595rightObjects3[i].hide();
}
}}

}


{


gdjs.test2Code.eventsList40(runtimeScene);
}


};gdjs.test2Code.eventsList42 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects3[i].getVariableNumber(gdjs.test2Code.GDheroObjects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects3[k] = gdjs.test2Code.GDheroObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDheroObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].returnVariable(gdjs.test2Code.GDheroObjects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("score2"), gdjs.test2Code.GDscore2Objects2);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 4.3, "", 0);
}{for(var i = 0, len = gdjs.test2Code.GDscore2Objects2.length ;i < len;++i) {
    gdjs.test2Code.GDscore2Objects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))));
}
}{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}
{ //Subevents
gdjs.test2Code.eventsList41(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDfake_95959595wallObjects4Objects = Hashtable.newFrom({"fake_wall": gdjs.test2Code.GDfake_9595wallObjects4});
gdjs.test2Code.asyncCallback66536492 = function (runtimeScene, asyncObjectsList) {
}
gdjs.test2Code.eventsList43 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.test2Code.asyncCallback66536492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDfake_95959595wallObjects3Objects = Hashtable.newFrom({"fake_wall": gdjs.test2Code.GDfake_9595wallObjects3});
gdjs.test2Code.asyncCallback66537396 = function (runtimeScene, asyncObjectsList) {
}
gdjs.test2Code.eventsList44 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.test2Code.asyncCallback66537396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.eventsList45 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("fake_wall"), gdjs.test2Code.GDfake_9595wallObjects4);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDfake_95959595wallObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDfake_9595wallObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDfake_9595wallObjects4[i].getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDfake_9595wallObjects4[k] = gdjs.test2Code.GDfake_9595wallObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDfake_9595wallObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDfake_9595wallObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDfake_9595wallObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDfake_9595wallObjects4[i].setOpacity(gdjs.test2Code.GDfake_9595wallObjects4[i].getOpacity() - (10));
}
}
{ //Subevents
gdjs.test2Code.eventsList43(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("fake_wall"), gdjs.test2Code.GDfake_9595wallObjects3);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDfake_95959595wallObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDfake_9595wallObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDfake_9595wallObjects3[i].getOpacity() != 200 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDfake_9595wallObjects3[k] = gdjs.test2Code.GDfake_9595wallObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDfake_9595wallObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDfake_9595wallObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDfake_9595wallObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDfake_9595wallObjects3[i].setOpacity(gdjs.test2Code.GDfake_9595wallObjects3[i].getOpacity() + (10));
}
}
{ //Subevents
gdjs.test2Code.eventsList44(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.eventsList46 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66538068);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("tap_block"), gdjs.test2Code.GDtap_9595blockObjects4);
{for(var i = 0, len = gdjs.test2Code.GDtap_9595blockObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDtap_9595blockObjects4[i].returnVariable(gdjs.test2Code.GDtap_9595blockObjects4[i].getVariables().getFromIndex(0)).mul(-(1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("tap_block"), gdjs.test2Code.GDtap_9595blockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDtap_9595blockObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDtap_9595blockObjects4[i].getVariableNumber(gdjs.test2Code.GDtap_9595blockObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDtap_9595blockObjects4[k] = gdjs.test2Code.GDtap_9595blockObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDtap_9595blockObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66538900);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDtap_9595blockObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDtap_9595blockObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDtap_9595blockObjects4[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.test2Code.GDtap_9595blockObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDtap_9595blockObjects4[i].getBehavior("Platform").changePlatformType("Platform");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("tap_block"), gdjs.test2Code.GDtap_9595blockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDtap_9595blockObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDtap_9595blockObjects3[i].getVariableNumber(gdjs.test2Code.GDtap_9595blockObjects3[i].getVariables().getFromIndex(0)) == -(1) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDtap_9595blockObjects3[k] = gdjs.test2Code.GDtap_9595blockObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDtap_9595blockObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66539892);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDtap_9595blockObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDtap_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDtap_9595blockObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.test2Code.GDtap_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDtap_9595blockObjects3[i].getBehavior("Platform").changePlatformType("Ladder");
}
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects5Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbrocken_95959595blockObjects5Objects = Hashtable.newFrom({"brocken_block": gdjs.test2Code.GDbrocken_9595blockObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects5Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbrocken_95959595blockObjects5Objects = Hashtable.newFrom({"brocken_block": gdjs.test2Code.GDbrocken_9595blockObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects5Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbrocken_95959595blockObjects5Objects = Hashtable.newFrom({"brocken_block": gdjs.test2Code.GDbrocken_9595blockObjects5});
gdjs.test2Code.eventsList47 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("brocken_block"), gdjs.test2Code.GDbrocken_9595blockObjects4);
gdjs.test2Code.GDheroObjects4.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDbrocken_9595blockObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDbrocken_9595blockObjects4[i].getVariableBoolean(gdjs.test2Code.GDbrocken_9595blockObjects4[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDbrocken_9595blockObjects4[k] = gdjs.test2Code.GDbrocken_9595blockObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDbrocken_9595blockObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.test2Code.GDbrocken_9595blockObjects4_1final.length = 0;
gdjs.test2Code.GDheroObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.test2Code.GDbrocken_9595blockObjects4, gdjs.test2Code.GDbrocken_9595blockObjects5);

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects5);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects5Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbrocken_95959595blockObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDbrocken_9595blockObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDbrocken_9595blockObjects4_1final.indexOf(gdjs.test2Code.GDbrocken_9595blockObjects5[j]) === -1 )
            gdjs.test2Code.GDbrocken_9595blockObjects4_1final.push(gdjs.test2Code.GDbrocken_9595blockObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDheroObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDheroObjects4_1final.indexOf(gdjs.test2Code.GDheroObjects5[j]) === -1 )
            gdjs.test2Code.GDheroObjects4_1final.push(gdjs.test2Code.GDheroObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.test2Code.GDbrocken_9595blockObjects4, gdjs.test2Code.GDbrocken_9595blockObjects5);

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects5);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects5Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbrocken_95959595blockObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects5.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects5[i].getBehavior("WallJump").HasJustWallJumped((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.test2Code.GDheroObjects5[k] = gdjs.test2Code.GDheroObjects5[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects5.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDbrocken_9595blockObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDbrocken_9595blockObjects4_1final.indexOf(gdjs.test2Code.GDbrocken_9595blockObjects5[j]) === -1 )
            gdjs.test2Code.GDbrocken_9595blockObjects4_1final.push(gdjs.test2Code.GDbrocken_9595blockObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDheroObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDheroObjects4_1final.indexOf(gdjs.test2Code.GDheroObjects5[j]) === -1 )
            gdjs.test2Code.GDheroObjects4_1final.push(gdjs.test2Code.GDheroObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.test2Code.GDbrocken_9595blockObjects4, gdjs.test2Code.GDbrocken_9595blockObjects5);

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects5);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects5Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbrocken_95959595blockObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects5.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects5[i].getBehavior("WallJump").IsAgaintWall((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.test2Code.GDheroObjects5[k] = gdjs.test2Code.GDheroObjects5[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects5.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDbrocken_9595blockObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDbrocken_9595blockObjects4_1final.indexOf(gdjs.test2Code.GDbrocken_9595blockObjects5[j]) === -1 )
            gdjs.test2Code.GDbrocken_9595blockObjects4_1final.push(gdjs.test2Code.GDbrocken_9595blockObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDheroObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDheroObjects4_1final.indexOf(gdjs.test2Code.GDheroObjects5[j]) === -1 )
            gdjs.test2Code.GDheroObjects4_1final.push(gdjs.test2Code.GDheroObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.test2Code.GDbrocken_9595blockObjects4_1final, gdjs.test2Code.GDbrocken_9595blockObjects4);
gdjs.copyArray(gdjs.test2Code.GDheroObjects4_1final, gdjs.test2Code.GDheroObjects4);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66543388);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDbrocken_9595blockObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDbrocken_9595blockObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDbrocken_9595blockObjects4[i].setVariableBoolean(gdjs.test2Code.GDbrocken_9595blockObjects4[i].getVariables().getFromIndex(0), true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("brocken_block"), gdjs.test2Code.GDbrocken_9595blockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDbrocken_9595blockObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDbrocken_9595blockObjects4[i].getVariableBoolean(gdjs.test2Code.GDbrocken_9595blockObjects4[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDbrocken_9595blockObjects4[k] = gdjs.test2Code.GDbrocken_9595blockObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDbrocken_9595blockObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDbrocken_9595blockObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDbrocken_9595blockObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDbrocken_9595blockObjects4[i].setAnimationName("1");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("brocken_block"), gdjs.test2Code.GDbrocken_9595blockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDbrocken_9595blockObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDbrocken_9595blockObjects3[i].getAnimationFrame() == 5 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDbrocken_9595blockObjects3[k] = gdjs.test2Code.GDbrocken_9595blockObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDbrocken_9595blockObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDbrocken_9595blockObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDbrocken_9595blockObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDbrocken_9595blockObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDwebObjects4Objects = Hashtable.newFrom({"web": gdjs.test2Code.GDwebObjects4});
gdjs.test2Code.asyncCallback66545740 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("hero"), gdjs.test2Code.GDheroObjects5);

{for(var i = 0, len = gdjs.test2Code.GDheroObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects5[i].getBehavior("PlatformerObject").abortJump();
}
}}
gdjs.test2Code.eventsList48 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.test2Code.GDheroObjects4) asyncObjectsList.addObject("hero", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.05), (runtimeScene) => (gdjs.test2Code.asyncCallback66545740(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDwebObjects3Objects = Hashtable.newFrom({"web": gdjs.test2Code.GDwebObjects3});
gdjs.test2Code.eventsList49 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);
gdjs.copyArray(runtimeScene.getObjects("web"), gdjs.test2Code.GDwebObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDwebObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDheroObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").setMaxFallingSpeed(30, false);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").setMaxSpeed(20);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").setJumpSpeed(0);
}
}
{ //Subevents
gdjs.test2Code.eventsList48(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);
gdjs.copyArray(runtimeScene.getObjects("web"), gdjs.test2Code.GDwebObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDwebObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66547444);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDheroObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].getBehavior("PlatformerObject").setMaxFallingSpeed(300, false);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].getBehavior("PlatformerObject").setMaxSpeed(90);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].getBehavior("PlatformerObject").setJumpSpeed(350);
}
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbuletObjects4Objects = Hashtable.newFrom({"bulet": gdjs.test2Code.GDbuletObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbuletObjects4Objects = Hashtable.newFrom({"bulet": gdjs.test2Code.GDbuletObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDblockObjects4Objects = Hashtable.newFrom({"block": gdjs.test2Code.GDblockObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbuletObjects4Objects = Hashtable.newFrom({"bulet": gdjs.test2Code.GDbuletObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbrocken_95959595blockObjects4Objects = Hashtable.newFrom({"brocken_block": gdjs.test2Code.GDbrocken_9595blockObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbuletObjects4Objects = Hashtable.newFrom({"bulet": gdjs.test2Code.GDbuletObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDtap_95959595blockObjects4Objects = Hashtable.newFrom({"tap_block": gdjs.test2Code.GDtap_9595blockObjects4});
gdjs.test2Code.eventsList50 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("gun"), gdjs.test2Code.GDgunObjects4);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDgunObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDgunObjects4[i].getBehavior("FireBullet").IsReadyToShoot((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDgunObjects4[k] = gdjs.test2Code.GDgunObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDgunObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects4[i].getVariableBoolean(gdjs.test2Code.GDheroObjects4[i].getVariables().getFromIndex(1), true) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects4[k] = gdjs.test2Code.GDheroObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66548980);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDgunObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDgunObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDgunObjects4[i].setAnimationFrame(1);
}
}{for(var i = 0, len = gdjs.test2Code.GDgunObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDgunObjects4[i].playAnimation();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "poof.wav", false, 30, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gun"), gdjs.test2Code.GDgunObjects4);
gdjs.test2Code.GDbuletObjects4.length = 0;

{for(var i = 0, len = gdjs.test2Code.GDgunObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDgunObjects4[i].getBehavior("FireBullet").Fire((gdjs.test2Code.GDgunObjects4[i].getCenterXInScene()), (gdjs.test2Code.GDgunObjects4[i].getCenterYInScene()), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbuletObjects4Objects, (gdjs.test2Code.GDgunObjects4[i].getAngle()), 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.test2Code.GDblockObjects3.length = 0;

gdjs.test2Code.GDbrocken_9595blockObjects3.length = 0;

gdjs.test2Code.GDbuletObjects3.length = 0;

gdjs.test2Code.GDtap_9595blockObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.test2Code.GDblockObjects3_1final.length = 0;
gdjs.test2Code.GDbrocken_9595blockObjects3_1final.length = 0;
gdjs.test2Code.GDbuletObjects3_1final.length = 0;
gdjs.test2Code.GDtap_9595blockObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("block"), gdjs.test2Code.GDblockObjects4);
gdjs.copyArray(runtimeScene.getObjects("bulet"), gdjs.test2Code.GDbuletObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbuletObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDblockObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDblockObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDblockObjects3_1final.indexOf(gdjs.test2Code.GDblockObjects4[j]) === -1 )
            gdjs.test2Code.GDblockObjects3_1final.push(gdjs.test2Code.GDblockObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDbuletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDbuletObjects3_1final.indexOf(gdjs.test2Code.GDbuletObjects4[j]) === -1 )
            gdjs.test2Code.GDbuletObjects3_1final.push(gdjs.test2Code.GDbuletObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("brocken_block"), gdjs.test2Code.GDbrocken_9595blockObjects4);
gdjs.copyArray(runtimeScene.getObjects("bulet"), gdjs.test2Code.GDbuletObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbuletObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbrocken_95959595blockObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDbrocken_9595blockObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDbrocken_9595blockObjects3_1final.indexOf(gdjs.test2Code.GDbrocken_9595blockObjects4[j]) === -1 )
            gdjs.test2Code.GDbrocken_9595blockObjects3_1final.push(gdjs.test2Code.GDbrocken_9595blockObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDbuletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDbuletObjects3_1final.indexOf(gdjs.test2Code.GDbuletObjects4[j]) === -1 )
            gdjs.test2Code.GDbuletObjects3_1final.push(gdjs.test2Code.GDbuletObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("bulet"), gdjs.test2Code.GDbuletObjects4);
gdjs.copyArray(runtimeScene.getObjects("tap_block"), gdjs.test2Code.GDtap_9595blockObjects4);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbuletObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDtap_95959595blockObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDtap_9595blockObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDtap_9595blockObjects4[i].getAnimation() == 0 ) {
        isConditionTrue_2 = true;
        gdjs.test2Code.GDtap_9595blockObjects4[k] = gdjs.test2Code.GDtap_9595blockObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDtap_9595blockObjects4.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDbuletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDbuletObjects3_1final.indexOf(gdjs.test2Code.GDbuletObjects4[j]) === -1 )
            gdjs.test2Code.GDbuletObjects3_1final.push(gdjs.test2Code.GDbuletObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDtap_9595blockObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDtap_9595blockObjects3_1final.indexOf(gdjs.test2Code.GDtap_9595blockObjects4[j]) === -1 )
            gdjs.test2Code.GDtap_9595blockObjects3_1final.push(gdjs.test2Code.GDtap_9595blockObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.test2Code.GDblockObjects3_1final, gdjs.test2Code.GDblockObjects3);
gdjs.copyArray(gdjs.test2Code.GDbrocken_9595blockObjects3_1final, gdjs.test2Code.GDbrocken_9595blockObjects3);
gdjs.copyArray(gdjs.test2Code.GDbuletObjects3_1final, gdjs.test2Code.GDbuletObjects3);
gdjs.copyArray(gdjs.test2Code.GDtap_9595blockObjects3_1final, gdjs.test2Code.GDtap_9595blockObjects3);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDbuletObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDbuletObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDbuletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDspikeObjects4Objects = Hashtable.newFrom({"spike": gdjs.test2Code.GDspikeObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDsawObjects4Objects = Hashtable.newFrom({"saw": gdjs.test2Code.GDsawObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrobot_95959595enemyObjects4Objects = Hashtable.newFrom({"robot_enemy": gdjs.test2Code.GDrobot_9595enemyObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbuletObjects4Objects = Hashtable.newFrom({"bulet": gdjs.test2Code.GDbuletObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595buletObjects4Objects = Hashtable.newFrom({"slime_bulet": gdjs.test2Code.GDslime_9595buletObjects4});
gdjs.test2Code.eventsList51 = function(runtimeScene) {

{

gdjs.test2Code.GDbuletObjects3.length = 0;

gdjs.test2Code.GDheroObjects3.length = 0;

gdjs.test2Code.GDrobot_9595enemyObjects3.length = 0;

gdjs.test2Code.GDsawObjects3.length = 0;

gdjs.test2Code.GDslime_9595buletObjects3.length = 0;

gdjs.test2Code.GDspikeObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.test2Code.GDbuletObjects3_1final.length = 0;
gdjs.test2Code.GDheroObjects3_1final.length = 0;
gdjs.test2Code.GDrobot_9595enemyObjects3_1final.length = 0;
gdjs.test2Code.GDsawObjects3_1final.length = 0;
gdjs.test2Code.GDslime_9595buletObjects3_1final.length = 0;
gdjs.test2Code.GDspikeObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.test2Code.GDspikeObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDspikeObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDheroObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDheroObjects3_1final.indexOf(gdjs.test2Code.GDheroObjects4[j]) === -1 )
            gdjs.test2Code.GDheroObjects3_1final.push(gdjs.test2Code.GDheroObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDspikeObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDspikeObjects3_1final.indexOf(gdjs.test2Code.GDspikeObjects4[j]) === -1 )
            gdjs.test2Code.GDspikeObjects3_1final.push(gdjs.test2Code.GDspikeObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);
gdjs.copyArray(runtimeScene.getObjects("saw"), gdjs.test2Code.GDsawObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDsawObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDheroObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDheroObjects3_1final.indexOf(gdjs.test2Code.GDheroObjects4[j]) === -1 )
            gdjs.test2Code.GDheroObjects3_1final.push(gdjs.test2Code.GDheroObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDsawObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDsawObjects3_1final.indexOf(gdjs.test2Code.GDsawObjects4[j]) === -1 )
            gdjs.test2Code.GDsawObjects3_1final.push(gdjs.test2Code.GDsawObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);
gdjs.copyArray(runtimeScene.getObjects("robot_enemy"), gdjs.test2Code.GDrobot_9595enemyObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrobot_95959595enemyObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDheroObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDheroObjects3_1final.indexOf(gdjs.test2Code.GDheroObjects4[j]) === -1 )
            gdjs.test2Code.GDheroObjects3_1final.push(gdjs.test2Code.GDheroObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDrobot_9595enemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDrobot_9595enemyObjects3_1final.indexOf(gdjs.test2Code.GDrobot_9595enemyObjects4[j]) === -1 )
            gdjs.test2Code.GDrobot_9595enemyObjects3_1final.push(gdjs.test2Code.GDrobot_9595enemyObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("bulet"), gdjs.test2Code.GDbuletObjects4);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbuletObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDbuletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDbuletObjects3_1final.indexOf(gdjs.test2Code.GDbuletObjects4[j]) === -1 )
            gdjs.test2Code.GDbuletObjects3_1final.push(gdjs.test2Code.GDbuletObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDheroObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDheroObjects3_1final.indexOf(gdjs.test2Code.GDheroObjects4[j]) === -1 )
            gdjs.test2Code.GDheroObjects3_1final.push(gdjs.test2Code.GDheroObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);
gdjs.copyArray(runtimeScene.getObjects("slime_bulet"), gdjs.test2Code.GDslime_9595buletObjects4);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595buletObjects4Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDheroObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDheroObjects3_1final.indexOf(gdjs.test2Code.GDheroObjects4[j]) === -1 )
            gdjs.test2Code.GDheroObjects3_1final.push(gdjs.test2Code.GDheroObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDslime_9595buletObjects4.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDslime_9595buletObjects3_1final.indexOf(gdjs.test2Code.GDslime_9595buletObjects4[j]) === -1 )
            gdjs.test2Code.GDslime_9595buletObjects3_1final.push(gdjs.test2Code.GDslime_9595buletObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.test2Code.GDbuletObjects3_1final, gdjs.test2Code.GDbuletObjects3);
gdjs.copyArray(gdjs.test2Code.GDheroObjects3_1final, gdjs.test2Code.GDheroObjects3);
gdjs.copyArray(gdjs.test2Code.GDrobot_9595enemyObjects3_1final, gdjs.test2Code.GDrobot_9595enemyObjects3);
gdjs.copyArray(gdjs.test2Code.GDsawObjects3_1final, gdjs.test2Code.GDsawObjects3);
gdjs.copyArray(gdjs.test2Code.GDslime_9595buletObjects3_1final, gdjs.test2Code.GDslime_9595buletObjects3);
gdjs.copyArray(gdjs.test2Code.GDspikeObjects3_1final, gdjs.test2Code.GDspikeObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66553740);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDheroObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].setVariableBoolean(gdjs.test2Code.GDheroObjects3[i].getVariables().getFromIndex(1), false);
}
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDdoorObjects3Objects = Hashtable.newFrom({"door": gdjs.test2Code.GDdoorObjects3});
gdjs.test2Code.eventsList52 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "random";
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "test2", true);
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "next";
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(9).add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "level", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "test2", true);
}}

}


};gdjs.test2Code.eventsList53 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.test2Code.GDdoorObjects3);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDdoorObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66555780);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList52(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDsaw_95959595centerObjects4Objects = Hashtable.newFrom({"saw_center": gdjs.test2Code.GDsaw_9595centerObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDsawObjects4Objects = Hashtable.newFrom({"saw": gdjs.test2Code.GDsawObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDsaw_95959595center2Objects3Objects = Hashtable.newFrom({"saw_center2": gdjs.test2Code.GDsaw_9595center2Objects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDsawObjects3Objects = Hashtable.newFrom({"saw": gdjs.test2Code.GDsawObjects3});
gdjs.test2Code.eventsList54 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("saw"), gdjs.test2Code.GDsawObjects4);
{for(var i = 0, len = gdjs.test2Code.GDsawObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDsawObjects4[i].rotate(-(400), runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("saw"), gdjs.test2Code.GDsawObjects4);
gdjs.copyArray(runtimeScene.getObjects("saw_center"), gdjs.test2Code.GDsaw_9595centerObjects4);
{gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.func(runtimeScene, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDsaw_95959595centerObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDsawObjects4Objects, 1, -(200), 50, 50, "", 400, 180, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("saw"), gdjs.test2Code.GDsawObjects3);
gdjs.copyArray(runtimeScene.getObjects("saw_center2"), gdjs.test2Code.GDsaw_9595center2Objects3);
{gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.func(runtimeScene, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDsaw_95959595center2Objects3Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDsawObjects3Objects, 1, 200, 50, 50, "", 400, 90, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595buletObjects5Objects = Hashtable.newFrom({"slime_bulet": gdjs.test2Code.GDslime_9595buletObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbrocken_95959595blockObjects5Objects = Hashtable.newFrom({"brocken_block": gdjs.test2Code.GDbrocken_9595blockObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595buletObjects5Objects = Hashtable.newFrom({"slime_bulet": gdjs.test2Code.GDslime_9595buletObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDblockObjects5Objects = Hashtable.newFrom({"block": gdjs.test2Code.GDblockObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595buletObjects5Objects = Hashtable.newFrom({"slime_bulet": gdjs.test2Code.GDslime_9595buletObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDtap_95959595blockObjects5Objects = Hashtable.newFrom({"tap_block": gdjs.test2Code.GDtap_9595blockObjects5});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595buletObjects3Objects = Hashtable.newFrom({"slime_bulet": gdjs.test2Code.GDslime_9595buletObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects3});
gdjs.test2Code.eventsList55 = function(runtimeScene) {

{

gdjs.test2Code.GDblockObjects4.length = 0;

gdjs.test2Code.GDbrocken_9595blockObjects4.length = 0;

gdjs.test2Code.GDslime_9595buletObjects4.length = 0;

gdjs.test2Code.GDtap_9595blockObjects4.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.test2Code.GDblockObjects4_1final.length = 0;
gdjs.test2Code.GDbrocken_9595blockObjects4_1final.length = 0;
gdjs.test2Code.GDslime_9595buletObjects4_1final.length = 0;
gdjs.test2Code.GDtap_9595blockObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("brocken_block"), gdjs.test2Code.GDbrocken_9595blockObjects5);
gdjs.copyArray(runtimeScene.getObjects("slime_bulet"), gdjs.test2Code.GDslime_9595buletObjects5);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595buletObjects5Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDbrocken_95959595blockObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDbrocken_9595blockObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDbrocken_9595blockObjects4_1final.indexOf(gdjs.test2Code.GDbrocken_9595blockObjects5[j]) === -1 )
            gdjs.test2Code.GDbrocken_9595blockObjects4_1final.push(gdjs.test2Code.GDbrocken_9595blockObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDslime_9595buletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDslime_9595buletObjects4_1final.indexOf(gdjs.test2Code.GDslime_9595buletObjects5[j]) === -1 )
            gdjs.test2Code.GDslime_9595buletObjects4_1final.push(gdjs.test2Code.GDslime_9595buletObjects5[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("block"), gdjs.test2Code.GDblockObjects5);
gdjs.copyArray(runtimeScene.getObjects("slime_bulet"), gdjs.test2Code.GDslime_9595buletObjects5);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595buletObjects5Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDblockObjects5Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDblockObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDblockObjects4_1final.indexOf(gdjs.test2Code.GDblockObjects5[j]) === -1 )
            gdjs.test2Code.GDblockObjects4_1final.push(gdjs.test2Code.GDblockObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDslime_9595buletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDslime_9595buletObjects4_1final.indexOf(gdjs.test2Code.GDslime_9595buletObjects5[j]) === -1 )
            gdjs.test2Code.GDslime_9595buletObjects4_1final.push(gdjs.test2Code.GDslime_9595buletObjects5[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("slime_bulet"), gdjs.test2Code.GDslime_9595buletObjects5);
gdjs.copyArray(runtimeScene.getObjects("tap_block"), gdjs.test2Code.GDtap_9595blockObjects5);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595buletObjects5Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDtap_95959595blockObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDtap_9595blockObjects5.length;i<l;++i) {
    if ( gdjs.test2Code.GDtap_9595blockObjects5[i].getAnimation() == 0 ) {
        isConditionTrue_2 = true;
        gdjs.test2Code.GDtap_9595blockObjects5[k] = gdjs.test2Code.GDtap_9595blockObjects5[i];
        ++k;
    }
}
gdjs.test2Code.GDtap_9595blockObjects5.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.test2Code.GDslime_9595buletObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDslime_9595buletObjects4_1final.indexOf(gdjs.test2Code.GDslime_9595buletObjects5[j]) === -1 )
            gdjs.test2Code.GDslime_9595buletObjects4_1final.push(gdjs.test2Code.GDslime_9595buletObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.test2Code.GDtap_9595blockObjects5.length; j < jLen ; ++j) {
        if ( gdjs.test2Code.GDtap_9595blockObjects4_1final.indexOf(gdjs.test2Code.GDtap_9595blockObjects5[j]) === -1 )
            gdjs.test2Code.GDtap_9595blockObjects4_1final.push(gdjs.test2Code.GDtap_9595blockObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.test2Code.GDblockObjects4_1final, gdjs.test2Code.GDblockObjects4);
gdjs.copyArray(gdjs.test2Code.GDbrocken_9595blockObjects4_1final, gdjs.test2Code.GDbrocken_9595blockObjects4);
gdjs.copyArray(gdjs.test2Code.GDslime_9595buletObjects4_1final, gdjs.test2Code.GDslime_9595buletObjects4);
gdjs.copyArray(gdjs.test2Code.GDtap_9595blockObjects4_1final, gdjs.test2Code.GDtap_9595blockObjects4);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDslime_9595buletObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDslime_9595buletObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDslime_9595buletObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("angry_fly"), gdjs.test2Code.GDangry_9595flyObjects4);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDangry_9595flyObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDangry_9595flyObjects4[i].getBehavior("FireBullet").IsReadyToShoot((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDangry_9595flyObjects4[k] = gdjs.test2Code.GDangry_9595flyObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDangry_9595flyObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDheroObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDheroObjects4[i].getVariableBoolean(gdjs.test2Code.GDheroObjects4[i].getVariables().getFromIndex(1), true) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDheroObjects4[k] = gdjs.test2Code.GDheroObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDheroObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66561060);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "fly.wav", false, 20, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("angry_fly"), gdjs.test2Code.GDangry_9595flyObjects3);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);
gdjs.test2Code.GDslime_9595buletObjects3.length = 0;

{for(var i = 0, len = gdjs.test2Code.GDangry_9595flyObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDangry_9595flyObjects3[i].getBehavior("FireBullet").FireTowardObject((gdjs.test2Code.GDangry_9595flyObjects3[i].getCenterXInScene()), (gdjs.test2Code.GDangry_9595flyObjects3[i].getCenterYInScene()), gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595buletObjects3Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects, 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDactive_95959595stickObjects4Objects = Hashtable.newFrom({"active_stick": gdjs.test2Code.GDactive_9595stickObjects4});
gdjs.test2Code.eventsList56 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("active_stick"), gdjs.test2Code.GDactive_9595stickObjects4);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDactive_95959595stickObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66564460);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDactive_9595stickObjects4 */
gdjs.copyArray(runtimeScene.getObjects("cage"), gdjs.test2Code.GDcageObjects4);
{for(var i = 0, len = gdjs.test2Code.GDcageObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDcageObjects4[i].setAnimationName("1");
}
}{for(var i = 0, len = gdjs.test2Code.GDactive_9595stickObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDactive_9595stickObjects4[i].setAnimationName("on");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("cage"), gdjs.test2Code.GDcageObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDcageObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDcageObjects3[i].isCurrentAnimationName("1") ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDcageObjects3[k] = gdjs.test2Code.GDcageObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDcageObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDcageObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDcageObjects3[i].hasAnimationEnded2() ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDcageObjects3[k] = gdjs.test2Code.GDcageObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDcageObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66565652);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDcageObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDcageObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDcageObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDtech_95959595spikeObjects3Objects = Hashtable.newFrom({"tech_spike": gdjs.test2Code.GDtech_9595spikeObjects3});
gdjs.test2Code.asyncCallback66567052 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("tech_spike"), gdjs.test2Code.GDtech_9595spikeObjects5);

{for(var i = 0, len = gdjs.test2Code.GDtech_9595spikeObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDtech_9595spikeObjects5[i].setAnimation(1);
}
}}
gdjs.test2Code.eventsList57 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.test2Code.GDtech_9595spikeObjects4) asyncObjectsList.addObject("tech_spike", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.test2Code.asyncCallback66567052(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.eventsList58 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.test2Code.GDtech_9595spikeObjects3, gdjs.test2Code.GDtech_9595spikeObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDtech_9595spikeObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDtech_9595spikeObjects4[i].isCurrentAnimationName("0") ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDtech_9595spikeObjects4[k] = gdjs.test2Code.GDtech_9595spikeObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDtech_9595spikeObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList57(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.test2Code.GDtech_9595spikeObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDtech_9595spikeObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDtech_9595spikeObjects3[i].isCurrentAnimationName("1") ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDtech_9595spikeObjects3[k] = gdjs.test2Code.GDtech_9595spikeObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDtech_9595spikeObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDheroObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].setVariableBoolean(gdjs.test2Code.GDheroObjects3[i].getVariables().getFromIndex(1), false);
}
}}

}


};gdjs.test2Code.eventsList59 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);
gdjs.copyArray(runtimeScene.getObjects("tech_spike"), gdjs.test2Code.GDtech_9595spikeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDtech_95959595spikeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.test2Code.eventsList58(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595enemyObjects4Objects = Hashtable.newFrom({"slime_enemy": gdjs.test2Code.GDslime_9595enemyObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrob_95959595enemy_95959595leftObjects4Objects = Hashtable.newFrom({"rob_enemy_left": gdjs.test2Code.GDrob_9595enemy_9595leftObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595enemyObjects4Objects = Hashtable.newFrom({"slime_enemy": gdjs.test2Code.GDslime_9595enemyObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrob_95959595enemy_95959595rightObjects4Objects = Hashtable.newFrom({"rob_enemy_right": gdjs.test2Code.GDrob_9595enemy_9595rightObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595enemyObjects4Objects = Hashtable.newFrom({"slime_enemy": gdjs.test2Code.GDslime_9595enemyObjects4});
gdjs.test2Code.asyncCallback66572860 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("hero"), gdjs.test2Code.GDheroObjects5);

{for(var i = 0, len = gdjs.test2Code.GDheroObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects5[i].getBehavior("PlatformerObject").setJumpSpeed(350);
}
}}
gdjs.test2Code.eventsList60 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.test2Code.GDheroObjects4) asyncObjectsList.addObject("hero", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.test2Code.asyncCallback66572860(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.eventsList61 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("slime_enemy"), gdjs.test2Code.GDslime_9595enemyObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDslime_9595enemyObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDslime_9595enemyObjects4[i].getVariableBoolean(gdjs.test2Code.GDslime_9595enemyObjects4[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDslime_9595enemyObjects4[k] = gdjs.test2Code.GDslime_9595enemyObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDslime_9595enemyObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDslime_9595enemyObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDslime_9595enemyObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDslime_9595enemyObjects4[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("slime_enemy"), gdjs.test2Code.GDslime_9595enemyObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDslime_9595enemyObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDslime_9595enemyObjects4[i].getVariableBoolean(gdjs.test2Code.GDslime_9595enemyObjects4[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDslime_9595enemyObjects4[k] = gdjs.test2Code.GDslime_9595enemyObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDslime_9595enemyObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDslime_9595enemyObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDslime_9595enemyObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDslime_9595enemyObjects4[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("rob_enemy_left"), gdjs.test2Code.GDrob_9595enemy_9595leftObjects4);
gdjs.copyArray(runtimeScene.getObjects("slime_enemy"), gdjs.test2Code.GDslime_9595enemyObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595enemyObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrob_95959595enemy_95959595leftObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDslime_9595enemyObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDslime_9595enemyObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDslime_9595enemyObjects4[i].setVariableBoolean(gdjs.test2Code.GDslime_9595enemyObjects4[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.test2Code.GDslime_9595enemyObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDslime_9595enemyObjects4[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("rob_enemy_right"), gdjs.test2Code.GDrob_9595enemy_9595rightObjects4);
gdjs.copyArray(runtimeScene.getObjects("slime_enemy"), gdjs.test2Code.GDslime_9595enemyObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595enemyObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrob_95959595enemy_95959595rightObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDslime_9595enemyObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDslime_9595enemyObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDslime_9595enemyObjects4[i].setVariableBoolean(gdjs.test2Code.GDslime_9595enemyObjects4[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.test2Code.GDslime_9595enemyObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDslime_9595enemyObjects4[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);
gdjs.copyArray(runtimeScene.getObjects("slime_enemy"), gdjs.test2Code.GDslime_9595enemyObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDslime_95959595enemyObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDheroObjects4 */
/* Reuse gdjs.test2Code.GDslime_9595enemyObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDslime_9595enemyObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDslime_9595enemyObjects4[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").setJumpSpeed(500);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}
{ //Subevents
gdjs.test2Code.eventsList60(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("slime_enemy"), gdjs.test2Code.GDslime_9595enemyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDslime_9595enemyObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDslime_9595enemyObjects3[i].getAnimation() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDslime_9595enemyObjects3[k] = gdjs.test2Code.GDslime_9595enemyObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDslime_9595enemyObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDslime_9595enemyObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDslime_9595enemyObjects3[i].getAnimationFrame() == 3 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDslime_9595enemyObjects3[k] = gdjs.test2Code.GDslime_9595enemyObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDslime_9595enemyObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDslime_9595enemyObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDslime_9595enemyObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDslime_9595enemyObjects3[i].setAnimation(0);
}
}}

}


};gdjs.test2Code.asyncCallback66575796 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("hero"), gdjs.test2Code.GDheroObjects4);

{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").setJumpSpeed(800);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").setJumpSustainTime(0.5);
}
}}
gdjs.test2Code.eventsList62 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.test2Code.GDheroObjects3) asyncObjectsList.addObject("hero", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.test2Code.asyncCallback66575796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.eventsList63 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].getBehavior("PlatformerObject").setJumpSpeed(2300);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].getBehavior("PlatformerObject").setJumpSustainTime(0);
}
}
{ //Subevents
gdjs.test2Code.eventsList62(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects4});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcapcanObjects4Objects = Hashtable.newFrom({"capcan": gdjs.test2Code.GDcapcanObjects4});
gdjs.test2Code.asyncCallback66578964 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("capcan"), gdjs.test2Code.GDcapcanObjects5);

{for(var i = 0, len = gdjs.test2Code.GDcapcanObjects5.length ;i < len;++i) {
    gdjs.test2Code.GDcapcanObjects5[i].returnVariable(gdjs.test2Code.GDcapcanObjects5[i].getVariables().getFromIndex(0)).setNumber(5);
}
}}
gdjs.test2Code.eventsList64 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.test2Code.GDcapcanObjects4) asyncObjectsList.addObject("capcan", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.test2Code.asyncCallback66578964(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects = Hashtable.newFrom({"hero": gdjs.test2Code.GDheroObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcapcanObjects3Objects = Hashtable.newFrom({"capcan": gdjs.test2Code.GDcapcanObjects3});
gdjs.test2Code.eventsList65 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66581396);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDcapcanObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDcapcanObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDcapcanObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 5, 0, 0, 0, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.test2Code.GDcapcanObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDcapcanObjects3[i].returnVariable(gdjs.test2Code.GDcapcanObjects3[i].getVariables().getFromIndex(0)).sub(1);
}
}}

}


};gdjs.test2Code.eventsList66 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("capcan"), gdjs.test2Code.GDcapcanObjects4);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects4Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcapcanObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDcapcanObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDcapcanObjects4[i].getAnimation() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDcapcanObjects4[k] = gdjs.test2Code.GDcapcanObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDcapcanObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDcapcanObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDcapcanObjects4[i].getVariableNumber(gdjs.test2Code.GDcapcanObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDcapcanObjects4[k] = gdjs.test2Code.GDcapcanObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDcapcanObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66577572);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDcapcanObjects4 */
{for(var i = 0, len = gdjs.test2Code.GDcapcanObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDcapcanObjects4[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("capcan"), gdjs.test2Code.GDcapcanObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDcapcanObjects4.length;i<l;++i) {
    if ( gdjs.test2Code.GDcapcanObjects4[i].getVariableNumber(gdjs.test2Code.GDcapcanObjects4[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDcapcanObjects4[k] = gdjs.test2Code.GDcapcanObjects4[i];
        ++k;
    }
}
gdjs.test2Code.GDcapcanObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66578300);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDcapcanObjects4 */
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects4);
{for(var i = 0, len = gdjs.test2Code.GDcapcanObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDcapcanObjects4[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").setMaxSpeed(90);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects4.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects4[i].getBehavior("PlatformerObject").setJumpSpeed(350);
}
}
{ //Subevents
gdjs.test2Code.eventsList64(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("capcan"), gdjs.test2Code.GDcapcanObjects3);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDheroObjects3Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDcapcanObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDcapcanObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDcapcanObjects3[i].getAnimation() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDcapcanObjects3[k] = gdjs.test2Code.GDcapcanObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDcapcanObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDcapcanObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDcapcanObjects3[i].getVariableNumber(gdjs.test2Code.GDcapcanObjects3[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDcapcanObjects3[k] = gdjs.test2Code.GDcapcanObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDcapcanObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDcapcanObjects3 */
/* Reuse gdjs.test2Code.GDheroObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].getBehavior("PlatformerObject").setMaxSpeed(0);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].getBehavior("PlatformerObject").setJumpSpeed(0);
}
}{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].setPosition((( gdjs.test2Code.GDcapcanObjects3.length === 0 ) ? 0 :gdjs.test2Code.GDcapcanObjects3[0].getCenterXInScene()),(( gdjs.test2Code.GDcapcanObjects3.length === 0 ) ? 0 :gdjs.test2Code.GDcapcanObjects3[0].getCenterYInScene()));
}
}
{ //Subevents
gdjs.test2Code.eventsList65(runtimeScene);} //End of subevents
}

}


};gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrobot_95959595enemyObjects3Objects = Hashtable.newFrom({"robot_enemy": gdjs.test2Code.GDrobot_9595enemyObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrob_95959595enemy_95959595leftObjects3Objects = Hashtable.newFrom({"rob_enemy_left": gdjs.test2Code.GDrob_9595enemy_9595leftObjects3});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrobot_95959595enemyObjects2Objects = Hashtable.newFrom({"robot_enemy": gdjs.test2Code.GDrobot_9595enemyObjects2});
gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrob_95959595enemy_95959595rightObjects2Objects = Hashtable.newFrom({"rob_enemy_right": gdjs.test2Code.GDrob_9595enemy_9595rightObjects2});
gdjs.test2Code.eventsList67 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("robot_enemy"), gdjs.test2Code.GDrobot_9595enemyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDrobot_9595enemyObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDrobot_9595enemyObjects3[i].getVariableBoolean(gdjs.test2Code.GDrobot_9595enemyObjects3[i].getVariables().get("flip"), false) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDrobot_9595enemyObjects3[k] = gdjs.test2Code.GDrobot_9595enemyObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDrobot_9595enemyObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDrobot_9595enemyObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDrobot_9595enemyObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDrobot_9595enemyObjects3[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("robot_enemy"), gdjs.test2Code.GDrobot_9595enemyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.test2Code.GDrobot_9595enemyObjects3.length;i<l;++i) {
    if ( gdjs.test2Code.GDrobot_9595enemyObjects3[i].getVariableBoolean(gdjs.test2Code.GDrobot_9595enemyObjects3[i].getVariables().get("flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.test2Code.GDrobot_9595enemyObjects3[k] = gdjs.test2Code.GDrobot_9595enemyObjects3[i];
        ++k;
    }
}
gdjs.test2Code.GDrobot_9595enemyObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDrobot_9595enemyObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDrobot_9595enemyObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDrobot_9595enemyObjects3[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("rob_enemy_left"), gdjs.test2Code.GDrob_9595enemy_9595leftObjects3);
gdjs.copyArray(runtimeScene.getObjects("robot_enemy"), gdjs.test2Code.GDrobot_9595enemyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrobot_95959595enemyObjects3Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrob_95959595enemy_95959595leftObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66584388);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDrobot_9595enemyObjects3 */
{for(var i = 0, len = gdjs.test2Code.GDrobot_9595enemyObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDrobot_9595enemyObjects3[i].setVariableBoolean(gdjs.test2Code.GDrobot_9595enemyObjects3[i].getVariables().get("flip"), true);
}
}{for(var i = 0, len = gdjs.test2Code.GDrobot_9595enemyObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDrobot_9595enemyObjects3[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("rob_enemy_right"), gdjs.test2Code.GDrob_9595enemy_9595rightObjects2);
gdjs.copyArray(runtimeScene.getObjects("robot_enemy"), gdjs.test2Code.GDrobot_9595enemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrobot_95959595enemyObjects2Objects, gdjs.test2Code.mapOfGDgdjs_9546test2Code_9546GDrob_95959595enemy_95959595rightObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66585340);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.test2Code.GDrobot_9595enemyObjects2 */
{for(var i = 0, len = gdjs.test2Code.GDrobot_9595enemyObjects2.length ;i < len;++i) {
    gdjs.test2Code.GDrobot_9595enemyObjects2[i].setVariableBoolean(gdjs.test2Code.GDrobot_9595enemyObjects2[i].getVariables().get("flip"), false);
}
}{for(var i = 0, len = gdjs.test2Code.GDrobot_9595enemyObjects2.length ;i < len;++i) {
    gdjs.test2Code.GDrobot_9595enemyObjects2[i].flipX(false);
}
}}

}


};gdjs.test2Code.eventsList68 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66535036);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("capcan"), gdjs.test2Code.GDcapcanObjects3);
gdjs.copyArray(runtimeScene.getObjects("hat"), gdjs.test2Code.GDhatObjects3);
gdjs.copyArray(runtimeScene.getObjects("hero"), gdjs.test2Code.GDheroObjects3);
{for(var i = 0, len = gdjs.test2Code.GDheroObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDheroObjects3[i].setZOrder(998);
}
}{for(var i = 0, len = gdjs.test2Code.GDhatObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDhatObjects3[i].setZOrder(999);
}
}{for(var i = 0, len = gdjs.test2Code.GDcapcanObjects3.length ;i < len;++i) {
    gdjs.test2Code.GDcapcanObjects3[i].setZOrder(1000);
}
}}

}


{


gdjs.test2Code.eventsList45(runtimeScene);
}


{


gdjs.test2Code.eventsList46(runtimeScene);
}


{


gdjs.test2Code.eventsList47(runtimeScene);
}


{


gdjs.test2Code.eventsList49(runtimeScene);
}


{


gdjs.test2Code.eventsList50(runtimeScene);
}


{


gdjs.test2Code.eventsList51(runtimeScene);
}


{


gdjs.test2Code.eventsList53(runtimeScene);
}


{


gdjs.test2Code.eventsList54(runtimeScene);
}


{


gdjs.test2Code.eventsList55(runtimeScene);
}


{


gdjs.test2Code.eventsList56(runtimeScene);
}


{


gdjs.test2Code.eventsList59(runtimeScene);
}


{


gdjs.test2Code.eventsList61(runtimeScene);
}


{


gdjs.test2Code.eventsList63(runtimeScene);
}


{


gdjs.test2Code.eventsList66(runtimeScene);
}


{


gdjs.test2Code.eventsList67(runtimeScene);
}


};gdjs.test2Code.eventsList69 = function(runtimeScene) {

{


gdjs.test2Code.eventsList29(runtimeScene);
}


{


gdjs.test2Code.eventsList31(runtimeScene);
}


{


gdjs.test2Code.eventsList32(runtimeScene);
}


{


gdjs.test2Code.eventsList33(runtimeScene);
}


{



}


{


gdjs.test2Code.eventsList42(runtimeScene);
}


{


gdjs.test2Code.eventsList68(runtimeScene);
}


{



}


{



}


};gdjs.test2Code.eventsList70 = function(runtimeScene) {

{


gdjs.test2Code.eventsList69(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.test2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.test2Code.GDtext_9595scoreObjects1.length = 0;
gdjs.test2Code.GDtext_9595scoreObjects2.length = 0;
gdjs.test2Code.GDtext_9595scoreObjects3.length = 0;
gdjs.test2Code.GDtext_9595scoreObjects4.length = 0;
gdjs.test2Code.GDtext_9595scoreObjects5.length = 0;
gdjs.test2Code.GDtext_9595scoreObjects6.length = 0;
gdjs.test2Code.GDtext_9595scoreObjects7.length = 0;
gdjs.test2Code.GDtext_9595recordObjects1.length = 0;
gdjs.test2Code.GDtext_9595recordObjects2.length = 0;
gdjs.test2Code.GDtext_9595recordObjects3.length = 0;
gdjs.test2Code.GDtext_9595recordObjects4.length = 0;
gdjs.test2Code.GDtext_9595recordObjects5.length = 0;
gdjs.test2Code.GDtext_9595recordObjects6.length = 0;
gdjs.test2Code.GDtext_9595recordObjects7.length = 0;
gdjs.test2Code.GDscoreObjects1.length = 0;
gdjs.test2Code.GDscoreObjects2.length = 0;
gdjs.test2Code.GDscoreObjects3.length = 0;
gdjs.test2Code.GDscoreObjects4.length = 0;
gdjs.test2Code.GDscoreObjects5.length = 0;
gdjs.test2Code.GDscoreObjects6.length = 0;
gdjs.test2Code.GDscoreObjects7.length = 0;
gdjs.test2Code.GDscore2Objects1.length = 0;
gdjs.test2Code.GDscore2Objects2.length = 0;
gdjs.test2Code.GDscore2Objects3.length = 0;
gdjs.test2Code.GDscore2Objects4.length = 0;
gdjs.test2Code.GDscore2Objects5.length = 0;
gdjs.test2Code.GDscore2Objects6.length = 0;
gdjs.test2Code.GDscore2Objects7.length = 0;
gdjs.test2Code.GDrecordObjects1.length = 0;
gdjs.test2Code.GDrecordObjects2.length = 0;
gdjs.test2Code.GDrecordObjects3.length = 0;
gdjs.test2Code.GDrecordObjects4.length = 0;
gdjs.test2Code.GDrecordObjects5.length = 0;
gdjs.test2Code.GDrecordObjects6.length = 0;
gdjs.test2Code.GDrecordObjects7.length = 0;
gdjs.test2Code.GDdoorObjects1.length = 0;
gdjs.test2Code.GDdoorObjects2.length = 0;
gdjs.test2Code.GDdoorObjects3.length = 0;
gdjs.test2Code.GDdoorObjects4.length = 0;
gdjs.test2Code.GDdoorObjects5.length = 0;
gdjs.test2Code.GDdoorObjects6.length = 0;
gdjs.test2Code.GDdoorObjects7.length = 0;
gdjs.test2Code.GDhatObjects1.length = 0;
gdjs.test2Code.GDhatObjects2.length = 0;
gdjs.test2Code.GDhatObjects3.length = 0;
gdjs.test2Code.GDhatObjects4.length = 0;
gdjs.test2Code.GDhatObjects5.length = 0;
gdjs.test2Code.GDhatObjects6.length = 0;
gdjs.test2Code.GDhatObjects7.length = 0;
gdjs.test2Code.GDcoinObjects1.length = 0;
gdjs.test2Code.GDcoinObjects2.length = 0;
gdjs.test2Code.GDcoinObjects3.length = 0;
gdjs.test2Code.GDcoinObjects4.length = 0;
gdjs.test2Code.GDcoinObjects5.length = 0;
gdjs.test2Code.GDcoinObjects6.length = 0;
gdjs.test2Code.GDcoinObjects7.length = 0;
gdjs.test2Code.GDtrava1Objects1.length = 0;
gdjs.test2Code.GDtrava1Objects2.length = 0;
gdjs.test2Code.GDtrava1Objects3.length = 0;
gdjs.test2Code.GDtrava1Objects4.length = 0;
gdjs.test2Code.GDtrava1Objects5.length = 0;
gdjs.test2Code.GDtrava1Objects6.length = 0;
gdjs.test2Code.GDtrava1Objects7.length = 0;
gdjs.test2Code.GDtrava2Objects1.length = 0;
gdjs.test2Code.GDtrava2Objects2.length = 0;
gdjs.test2Code.GDtrava2Objects3.length = 0;
gdjs.test2Code.GDtrava2Objects4.length = 0;
gdjs.test2Code.GDtrava2Objects5.length = 0;
gdjs.test2Code.GDtrava2Objects6.length = 0;
gdjs.test2Code.GDtrava2Objects7.length = 0;
gdjs.test2Code.GDtrava3Objects1.length = 0;
gdjs.test2Code.GDtrava3Objects2.length = 0;
gdjs.test2Code.GDtrava3Objects3.length = 0;
gdjs.test2Code.GDtrava3Objects4.length = 0;
gdjs.test2Code.GDtrava3Objects5.length = 0;
gdjs.test2Code.GDtrava3Objects6.length = 0;
gdjs.test2Code.GDtrava3Objects7.length = 0;
gdjs.test2Code.GDtrava4Objects1.length = 0;
gdjs.test2Code.GDtrava4Objects2.length = 0;
gdjs.test2Code.GDtrava4Objects3.length = 0;
gdjs.test2Code.GDtrava4Objects4.length = 0;
gdjs.test2Code.GDtrava4Objects5.length = 0;
gdjs.test2Code.GDtrava4Objects6.length = 0;
gdjs.test2Code.GDtrava4Objects7.length = 0;
gdjs.test2Code.GDfly1Objects1.length = 0;
gdjs.test2Code.GDfly1Objects2.length = 0;
gdjs.test2Code.GDfly1Objects3.length = 0;
gdjs.test2Code.GDfly1Objects4.length = 0;
gdjs.test2Code.GDfly1Objects5.length = 0;
gdjs.test2Code.GDfly1Objects6.length = 0;
gdjs.test2Code.GDfly1Objects7.length = 0;
gdjs.test2Code.GDfly2Objects1.length = 0;
gdjs.test2Code.GDfly2Objects2.length = 0;
gdjs.test2Code.GDfly2Objects3.length = 0;
gdjs.test2Code.GDfly2Objects4.length = 0;
gdjs.test2Code.GDfly2Objects5.length = 0;
gdjs.test2Code.GDfly2Objects6.length = 0;
gdjs.test2Code.GDfly2Objects7.length = 0;
gdjs.test2Code.GDcamera_9595stoperObjects1.length = 0;
gdjs.test2Code.GDcamera_9595stoperObjects2.length = 0;
gdjs.test2Code.GDcamera_9595stoperObjects3.length = 0;
gdjs.test2Code.GDcamera_9595stoperObjects4.length = 0;
gdjs.test2Code.GDcamera_9595stoperObjects5.length = 0;
gdjs.test2Code.GDcamera_9595stoperObjects6.length = 0;
gdjs.test2Code.GDcamera_9595stoperObjects7.length = 0;
gdjs.test2Code.GDgunObjects1.length = 0;
gdjs.test2Code.GDgunObjects2.length = 0;
gdjs.test2Code.GDgunObjects3.length = 0;
gdjs.test2Code.GDgunObjects4.length = 0;
gdjs.test2Code.GDgunObjects5.length = 0;
gdjs.test2Code.GDgunObjects6.length = 0;
gdjs.test2Code.GDgunObjects7.length = 0;
gdjs.test2Code.GDbuletObjects1.length = 0;
gdjs.test2Code.GDbuletObjects2.length = 0;
gdjs.test2Code.GDbuletObjects3.length = 0;
gdjs.test2Code.GDbuletObjects4.length = 0;
gdjs.test2Code.GDbuletObjects5.length = 0;
gdjs.test2Code.GDbuletObjects6.length = 0;
gdjs.test2Code.GDbuletObjects7.length = 0;
gdjs.test2Code.GDforegroundObjects1.length = 0;
gdjs.test2Code.GDforegroundObjects2.length = 0;
gdjs.test2Code.GDforegroundObjects3.length = 0;
gdjs.test2Code.GDforegroundObjects4.length = 0;
gdjs.test2Code.GDforegroundObjects5.length = 0;
gdjs.test2Code.GDforegroundObjects6.length = 0;
gdjs.test2Code.GDforegroundObjects7.length = 0;
gdjs.test2Code.GDmidlegroundObjects1.length = 0;
gdjs.test2Code.GDmidlegroundObjects2.length = 0;
gdjs.test2Code.GDmidlegroundObjects3.length = 0;
gdjs.test2Code.GDmidlegroundObjects4.length = 0;
gdjs.test2Code.GDmidlegroundObjects5.length = 0;
gdjs.test2Code.GDmidlegroundObjects6.length = 0;
gdjs.test2Code.GDmidlegroundObjects7.length = 0;
gdjs.test2Code.GDbackgroundObjects1.length = 0;
gdjs.test2Code.GDbackgroundObjects2.length = 0;
gdjs.test2Code.GDbackgroundObjects3.length = 0;
gdjs.test2Code.GDbackgroundObjects4.length = 0;
gdjs.test2Code.GDbackgroundObjects5.length = 0;
gdjs.test2Code.GDbackgroundObjects6.length = 0;
gdjs.test2Code.GDbackgroundObjects7.length = 0;
gdjs.test2Code.GDwebObjects1.length = 0;
gdjs.test2Code.GDwebObjects2.length = 0;
gdjs.test2Code.GDwebObjects3.length = 0;
gdjs.test2Code.GDwebObjects4.length = 0;
gdjs.test2Code.GDwebObjects5.length = 0;
gdjs.test2Code.GDwebObjects6.length = 0;
gdjs.test2Code.GDwebObjects7.length = 0;
gdjs.test2Code.GDangry_9595flyObjects1.length = 0;
gdjs.test2Code.GDangry_9595flyObjects2.length = 0;
gdjs.test2Code.GDangry_9595flyObjects3.length = 0;
gdjs.test2Code.GDangry_9595flyObjects4.length = 0;
gdjs.test2Code.GDangry_9595flyObjects5.length = 0;
gdjs.test2Code.GDangry_9595flyObjects6.length = 0;
gdjs.test2Code.GDangry_9595flyObjects7.length = 0;
gdjs.test2Code.GDslime_9595buletObjects1.length = 0;
gdjs.test2Code.GDslime_9595buletObjects2.length = 0;
gdjs.test2Code.GDslime_9595buletObjects3.length = 0;
gdjs.test2Code.GDslime_9595buletObjects4.length = 0;
gdjs.test2Code.GDslime_9595buletObjects5.length = 0;
gdjs.test2Code.GDslime_9595buletObjects6.length = 0;
gdjs.test2Code.GDslime_9595buletObjects7.length = 0;
gdjs.test2Code.GDplatformObjects1.length = 0;
gdjs.test2Code.GDplatformObjects2.length = 0;
gdjs.test2Code.GDplatformObjects3.length = 0;
gdjs.test2Code.GDplatformObjects4.length = 0;
gdjs.test2Code.GDplatformObjects5.length = 0;
gdjs.test2Code.GDplatformObjects6.length = 0;
gdjs.test2Code.GDplatformObjects7.length = 0;
gdjs.test2Code.GDplatform2Objects1.length = 0;
gdjs.test2Code.GDplatform2Objects2.length = 0;
gdjs.test2Code.GDplatform2Objects3.length = 0;
gdjs.test2Code.GDplatform2Objects4.length = 0;
gdjs.test2Code.GDplatform2Objects5.length = 0;
gdjs.test2Code.GDplatform2Objects6.length = 0;
gdjs.test2Code.GDplatform2Objects7.length = 0;
gdjs.test2Code.GDplatform3Objects1.length = 0;
gdjs.test2Code.GDplatform3Objects2.length = 0;
gdjs.test2Code.GDplatform3Objects3.length = 0;
gdjs.test2Code.GDplatform3Objects4.length = 0;
gdjs.test2Code.GDplatform3Objects5.length = 0;
gdjs.test2Code.GDplatform3Objects6.length = 0;
gdjs.test2Code.GDplatform3Objects7.length = 0;
gdjs.test2Code.GDsaw_9595centerObjects1.length = 0;
gdjs.test2Code.GDsaw_9595centerObjects2.length = 0;
gdjs.test2Code.GDsaw_9595centerObjects3.length = 0;
gdjs.test2Code.GDsaw_9595centerObjects4.length = 0;
gdjs.test2Code.GDsaw_9595centerObjects5.length = 0;
gdjs.test2Code.GDsaw_9595centerObjects6.length = 0;
gdjs.test2Code.GDsaw_9595centerObjects7.length = 0;
gdjs.test2Code.GDsaw_9595center2Objects1.length = 0;
gdjs.test2Code.GDsaw_9595center2Objects2.length = 0;
gdjs.test2Code.GDsaw_9595center2Objects3.length = 0;
gdjs.test2Code.GDsaw_9595center2Objects4.length = 0;
gdjs.test2Code.GDsaw_9595center2Objects5.length = 0;
gdjs.test2Code.GDsaw_9595center2Objects6.length = 0;
gdjs.test2Code.GDsaw_9595center2Objects7.length = 0;
gdjs.test2Code.GDback_9595blockObjects1.length = 0;
gdjs.test2Code.GDback_9595blockObjects2.length = 0;
gdjs.test2Code.GDback_9595blockObjects3.length = 0;
gdjs.test2Code.GDback_9595blockObjects4.length = 0;
gdjs.test2Code.GDback_9595blockObjects5.length = 0;
gdjs.test2Code.GDback_9595blockObjects6.length = 0;
gdjs.test2Code.GDback_9595blockObjects7.length = 0;
gdjs.test2Code.GDbrocken_9595blockObjects1.length = 0;
gdjs.test2Code.GDbrocken_9595blockObjects2.length = 0;
gdjs.test2Code.GDbrocken_9595blockObjects3.length = 0;
gdjs.test2Code.GDbrocken_9595blockObjects4.length = 0;
gdjs.test2Code.GDbrocken_9595blockObjects5.length = 0;
gdjs.test2Code.GDbrocken_9595blockObjects6.length = 0;
gdjs.test2Code.GDbrocken_9595blockObjects7.length = 0;
gdjs.test2Code.GDcageObjects1.length = 0;
gdjs.test2Code.GDcageObjects2.length = 0;
gdjs.test2Code.GDcageObjects3.length = 0;
gdjs.test2Code.GDcageObjects4.length = 0;
gdjs.test2Code.GDcageObjects5.length = 0;
gdjs.test2Code.GDcageObjects6.length = 0;
gdjs.test2Code.GDcageObjects7.length = 0;
gdjs.test2Code.GDactive_9595stickObjects1.length = 0;
gdjs.test2Code.GDactive_9595stickObjects2.length = 0;
gdjs.test2Code.GDactive_9595stickObjects3.length = 0;
gdjs.test2Code.GDactive_9595stickObjects4.length = 0;
gdjs.test2Code.GDactive_9595stickObjects5.length = 0;
gdjs.test2Code.GDactive_9595stickObjects6.length = 0;
gdjs.test2Code.GDactive_9595stickObjects7.length = 0;
gdjs.test2Code.GDtap_9595blockObjects1.length = 0;
gdjs.test2Code.GDtap_9595blockObjects2.length = 0;
gdjs.test2Code.GDtap_9595blockObjects3.length = 0;
gdjs.test2Code.GDtap_9595blockObjects4.length = 0;
gdjs.test2Code.GDtap_9595blockObjects5.length = 0;
gdjs.test2Code.GDtap_9595blockObjects6.length = 0;
gdjs.test2Code.GDtap_9595blockObjects7.length = 0;
gdjs.test2Code.GDtech_9595spikeObjects1.length = 0;
gdjs.test2Code.GDtech_9595spikeObjects2.length = 0;
gdjs.test2Code.GDtech_9595spikeObjects3.length = 0;
gdjs.test2Code.GDtech_9595spikeObjects4.length = 0;
gdjs.test2Code.GDtech_9595spikeObjects5.length = 0;
gdjs.test2Code.GDtech_9595spikeObjects6.length = 0;
gdjs.test2Code.GDtech_9595spikeObjects7.length = 0;
gdjs.test2Code.GDcapcanObjects1.length = 0;
gdjs.test2Code.GDcapcanObjects2.length = 0;
gdjs.test2Code.GDcapcanObjects3.length = 0;
gdjs.test2Code.GDcapcanObjects4.length = 0;
gdjs.test2Code.GDcapcanObjects5.length = 0;
gdjs.test2Code.GDcapcanObjects6.length = 0;
gdjs.test2Code.GDcapcanObjects7.length = 0;
gdjs.test2Code.GDznakObjects1.length = 0;
gdjs.test2Code.GDznakObjects2.length = 0;
gdjs.test2Code.GDznakObjects3.length = 0;
gdjs.test2Code.GDznakObjects4.length = 0;
gdjs.test2Code.GDznakObjects5.length = 0;
gdjs.test2Code.GDznakObjects6.length = 0;
gdjs.test2Code.GDznakObjects7.length = 0;
gdjs.test2Code.GDfake_9595wallObjects1.length = 0;
gdjs.test2Code.GDfake_9595wallObjects2.length = 0;
gdjs.test2Code.GDfake_9595wallObjects3.length = 0;
gdjs.test2Code.GDfake_9595wallObjects4.length = 0;
gdjs.test2Code.GDfake_9595wallObjects5.length = 0;
gdjs.test2Code.GDfake_9595wallObjects6.length = 0;
gdjs.test2Code.GDfake_9595wallObjects7.length = 0;
gdjs.test2Code.GDdtObjects1.length = 0;
gdjs.test2Code.GDdtObjects2.length = 0;
gdjs.test2Code.GDdtObjects3.length = 0;
gdjs.test2Code.GDdtObjects4.length = 0;
gdjs.test2Code.GDdtObjects5.length = 0;
gdjs.test2Code.GDdtObjects6.length = 0;
gdjs.test2Code.GDdtObjects7.length = 0;
gdjs.test2Code.GDNewBBTextObjects1.length = 0;
gdjs.test2Code.GDNewBBTextObjects2.length = 0;
gdjs.test2Code.GDNewBBTextObjects3.length = 0;
gdjs.test2Code.GDNewBBTextObjects4.length = 0;
gdjs.test2Code.GDNewBBTextObjects5.length = 0;
gdjs.test2Code.GDNewBBTextObjects6.length = 0;
gdjs.test2Code.GDNewBBTextObjects7.length = 0;
gdjs.test2Code.GDgrass_9595blockObjects1.length = 0;
gdjs.test2Code.GDgrass_9595blockObjects2.length = 0;
gdjs.test2Code.GDgrass_9595blockObjects3.length = 0;
gdjs.test2Code.GDgrass_9595blockObjects4.length = 0;
gdjs.test2Code.GDgrass_9595blockObjects5.length = 0;
gdjs.test2Code.GDgrass_9595blockObjects6.length = 0;
gdjs.test2Code.GDgrass_9595blockObjects7.length = 0;
gdjs.test2Code.GDblockObjects1.length = 0;
gdjs.test2Code.GDblockObjects2.length = 0;
gdjs.test2Code.GDblockObjects3.length = 0;
gdjs.test2Code.GDblockObjects4.length = 0;
gdjs.test2Code.GDblockObjects5.length = 0;
gdjs.test2Code.GDblockObjects6.length = 0;
gdjs.test2Code.GDblockObjects7.length = 0;
gdjs.test2Code.GDmenuObjects1.length = 0;
gdjs.test2Code.GDmenuObjects2.length = 0;
gdjs.test2Code.GDmenuObjects3.length = 0;
gdjs.test2Code.GDmenuObjects4.length = 0;
gdjs.test2Code.GDmenuObjects5.length = 0;
gdjs.test2Code.GDmenuObjects6.length = 0;
gdjs.test2Code.GDmenuObjects7.length = 0;
gdjs.test2Code.GDhomeObjects1.length = 0;
gdjs.test2Code.GDhomeObjects2.length = 0;
gdjs.test2Code.GDhomeObjects3.length = 0;
gdjs.test2Code.GDhomeObjects4.length = 0;
gdjs.test2Code.GDhomeObjects5.length = 0;
gdjs.test2Code.GDhomeObjects6.length = 0;
gdjs.test2Code.GDhomeObjects7.length = 0;
gdjs.test2Code.GDresetObjects1.length = 0;
gdjs.test2Code.GDresetObjects2.length = 0;
gdjs.test2Code.GDresetObjects3.length = 0;
gdjs.test2Code.GDresetObjects4.length = 0;
gdjs.test2Code.GDresetObjects5.length = 0;
gdjs.test2Code.GDresetObjects6.length = 0;
gdjs.test2Code.GDresetObjects7.length = 0;
gdjs.test2Code.GDspikeObjects1.length = 0;
gdjs.test2Code.GDspikeObjects2.length = 0;
gdjs.test2Code.GDspikeObjects3.length = 0;
gdjs.test2Code.GDspikeObjects4.length = 0;
gdjs.test2Code.GDspikeObjects5.length = 0;
gdjs.test2Code.GDspikeObjects6.length = 0;
gdjs.test2Code.GDspikeObjects7.length = 0;
gdjs.test2Code.GDend_9595homeObjects1.length = 0;
gdjs.test2Code.GDend_9595homeObjects2.length = 0;
gdjs.test2Code.GDend_9595homeObjects3.length = 0;
gdjs.test2Code.GDend_9595homeObjects4.length = 0;
gdjs.test2Code.GDend_9595homeObjects5.length = 0;
gdjs.test2Code.GDend_9595homeObjects6.length = 0;
gdjs.test2Code.GDend_9595homeObjects7.length = 0;
gdjs.test2Code.GDend_9595resetObjects1.length = 0;
gdjs.test2Code.GDend_9595resetObjects2.length = 0;
gdjs.test2Code.GDend_9595resetObjects3.length = 0;
gdjs.test2Code.GDend_9595resetObjects4.length = 0;
gdjs.test2Code.GDend_9595resetObjects5.length = 0;
gdjs.test2Code.GDend_9595resetObjects6.length = 0;
gdjs.test2Code.GDend_9595resetObjects7.length = 0;
gdjs.test2Code.GDrobot_9595enemyObjects1.length = 0;
gdjs.test2Code.GDrobot_9595enemyObjects2.length = 0;
gdjs.test2Code.GDrobot_9595enemyObjects3.length = 0;
gdjs.test2Code.GDrobot_9595enemyObjects4.length = 0;
gdjs.test2Code.GDrobot_9595enemyObjects5.length = 0;
gdjs.test2Code.GDrobot_9595enemyObjects6.length = 0;
gdjs.test2Code.GDrobot_9595enemyObjects7.length = 0;
gdjs.test2Code.GDslime_9595enemyObjects1.length = 0;
gdjs.test2Code.GDslime_9595enemyObjects2.length = 0;
gdjs.test2Code.GDslime_9595enemyObjects3.length = 0;
gdjs.test2Code.GDslime_9595enemyObjects4.length = 0;
gdjs.test2Code.GDslime_9595enemyObjects5.length = 0;
gdjs.test2Code.GDslime_9595enemyObjects6.length = 0;
gdjs.test2Code.GDslime_9595enemyObjects7.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595rightObjects1.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595rightObjects2.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595rightObjects3.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595rightObjects4.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595rightObjects5.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595rightObjects6.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595rightObjects7.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595leftObjects1.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595leftObjects2.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595leftObjects3.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595leftObjects4.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595leftObjects5.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595leftObjects6.length = 0;
gdjs.test2Code.GDrob_9595enemy_9595leftObjects7.length = 0;
gdjs.test2Code.GDheroObjects1.length = 0;
gdjs.test2Code.GDheroObjects2.length = 0;
gdjs.test2Code.GDheroObjects3.length = 0;
gdjs.test2Code.GDheroObjects4.length = 0;
gdjs.test2Code.GDheroObjects5.length = 0;
gdjs.test2Code.GDheroObjects6.length = 0;
gdjs.test2Code.GDheroObjects7.length = 0;
gdjs.test2Code.GDsawObjects1.length = 0;
gdjs.test2Code.GDsawObjects2.length = 0;
gdjs.test2Code.GDsawObjects3.length = 0;
gdjs.test2Code.GDsawObjects4.length = 0;
gdjs.test2Code.GDsawObjects5.length = 0;
gdjs.test2Code.GDsawObjects6.length = 0;
gdjs.test2Code.GDsawObjects7.length = 0;
gdjs.test2Code.GDcoin_9595markerObjects1.length = 0;
gdjs.test2Code.GDcoin_9595markerObjects2.length = 0;
gdjs.test2Code.GDcoin_9595markerObjects3.length = 0;
gdjs.test2Code.GDcoin_9595markerObjects4.length = 0;
gdjs.test2Code.GDcoin_9595markerObjects5.length = 0;
gdjs.test2Code.GDcoin_9595markerObjects6.length = 0;
gdjs.test2Code.GDcoin_9595markerObjects7.length = 0;
gdjs.test2Code.GDcoin_9595marker2Objects1.length = 0;
gdjs.test2Code.GDcoin_9595marker2Objects2.length = 0;
gdjs.test2Code.GDcoin_9595marker2Objects3.length = 0;
gdjs.test2Code.GDcoin_9595marker2Objects4.length = 0;
gdjs.test2Code.GDcoin_9595marker2Objects5.length = 0;
gdjs.test2Code.GDcoin_9595marker2Objects6.length = 0;
gdjs.test2Code.GDcoin_9595marker2Objects7.length = 0;
gdjs.test2Code.GDcoinsObjects1.length = 0;
gdjs.test2Code.GDcoinsObjects2.length = 0;
gdjs.test2Code.GDcoinsObjects3.length = 0;
gdjs.test2Code.GDcoinsObjects4.length = 0;
gdjs.test2Code.GDcoinsObjects5.length = 0;
gdjs.test2Code.GDcoinsObjects6.length = 0;
gdjs.test2Code.GDcoinsObjects7.length = 0;
gdjs.test2Code.GDcoins2Objects1.length = 0;
gdjs.test2Code.GDcoins2Objects2.length = 0;
gdjs.test2Code.GDcoins2Objects3.length = 0;
gdjs.test2Code.GDcoins2Objects4.length = 0;
gdjs.test2Code.GDcoins2Objects5.length = 0;
gdjs.test2Code.GDcoins2Objects6.length = 0;
gdjs.test2Code.GDcoins2Objects7.length = 0;
gdjs.test2Code.GDkey_9595lockerObjects1.length = 0;
gdjs.test2Code.GDkey_9595lockerObjects2.length = 0;
gdjs.test2Code.GDkey_9595lockerObjects3.length = 0;
gdjs.test2Code.GDkey_9595lockerObjects4.length = 0;
gdjs.test2Code.GDkey_9595lockerObjects5.length = 0;
gdjs.test2Code.GDkey_9595lockerObjects6.length = 0;
gdjs.test2Code.GDkey_9595lockerObjects7.length = 0;
gdjs.test2Code.GDr_9595buttonObjects1.length = 0;
gdjs.test2Code.GDr_9595buttonObjects2.length = 0;
gdjs.test2Code.GDr_9595buttonObjects3.length = 0;
gdjs.test2Code.GDr_9595buttonObjects4.length = 0;
gdjs.test2Code.GDr_9595buttonObjects5.length = 0;
gdjs.test2Code.GDr_9595buttonObjects6.length = 0;
gdjs.test2Code.GDr_9595buttonObjects7.length = 0;
gdjs.test2Code.GDl_9595buttonObjects1.length = 0;
gdjs.test2Code.GDl_9595buttonObjects2.length = 0;
gdjs.test2Code.GDl_9595buttonObjects3.length = 0;
gdjs.test2Code.GDl_9595buttonObjects4.length = 0;
gdjs.test2Code.GDl_9595buttonObjects5.length = 0;
gdjs.test2Code.GDl_9595buttonObjects6.length = 0;
gdjs.test2Code.GDl_9595buttonObjects7.length = 0;
gdjs.test2Code.GDbackObjects1.length = 0;
gdjs.test2Code.GDbackObjects2.length = 0;
gdjs.test2Code.GDbackObjects3.length = 0;
gdjs.test2Code.GDbackObjects4.length = 0;
gdjs.test2Code.GDbackObjects5.length = 0;
gdjs.test2Code.GDbackObjects6.length = 0;
gdjs.test2Code.GDbackObjects7.length = 0;
gdjs.test2Code.GDlockObjects1.length = 0;
gdjs.test2Code.GDlockObjects2.length = 0;
gdjs.test2Code.GDlockObjects3.length = 0;
gdjs.test2Code.GDlockObjects4.length = 0;
gdjs.test2Code.GDlockObjects5.length = 0;
gdjs.test2Code.GDlockObjects6.length = 0;
gdjs.test2Code.GDlockObjects7.length = 0;
gdjs.test2Code.GDcamObjects1.length = 0;
gdjs.test2Code.GDcamObjects2.length = 0;
gdjs.test2Code.GDcamObjects3.length = 0;
gdjs.test2Code.GDcamObjects4.length = 0;
gdjs.test2Code.GDcamObjects5.length = 0;
gdjs.test2Code.GDcamObjects6.length = 0;
gdjs.test2Code.GDcamObjects7.length = 0;
gdjs.test2Code.GDfonikObjects1.length = 0;
gdjs.test2Code.GDfonikObjects2.length = 0;
gdjs.test2Code.GDfonikObjects3.length = 0;
gdjs.test2Code.GDfonikObjects4.length = 0;
gdjs.test2Code.GDfonikObjects5.length = 0;
gdjs.test2Code.GDfonikObjects6.length = 0;
gdjs.test2Code.GDfonikObjects7.length = 0;

gdjs.test2Code.eventsList70(runtimeScene);

return;

}

gdjs['test2Code'] = gdjs.test2Code;
