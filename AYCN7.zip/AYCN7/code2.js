gdjs.storeCode = {};
gdjs.storeCode.GDstore_9595coin_9595markerObjects1= [];
gdjs.storeCode.GDstore_9595coin_9595markerObjects2= [];
gdjs.storeCode.GDstore_9595coin_9595markerObjects3= [];
gdjs.storeCode.GDtext_9595valueObjects1= [];
gdjs.storeCode.GDtext_9595valueObjects2= [];
gdjs.storeCode.GDtext_9595valueObjects3= [];
gdjs.storeCode.GDnot_9595work_9595textObjects1= [];
gdjs.storeCode.GDnot_9595work_9595textObjects2= [];
gdjs.storeCode.GDnot_9595work_9595textObjects3= [];
gdjs.storeCode.GDfree_9595textObjects1= [];
gdjs.storeCode.GDfree_9595textObjects2= [];
gdjs.storeCode.GDfree_9595textObjects3= [];
gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects1= [];
gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects2= [];
gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects3= [];
gdjs.storeCode.GDtext_9595cost_9595on_9595button2Objects1= [];
gdjs.storeCode.GDtext_9595cost_9595on_9595button2Objects2= [];
gdjs.storeCode.GDtext_9595cost_9595on_9595button2Objects3= [];
gdjs.storeCode.GDtext_9595cost_9595on_9595button3Objects1= [];
gdjs.storeCode.GDtext_9595cost_9595on_9595button3Objects2= [];
gdjs.storeCode.GDtext_9595cost_9595on_9595button3Objects3= [];
gdjs.storeCode.GDstore_9595buttonObjects1= [];
gdjs.storeCode.GDstore_9595buttonObjects2= [];
gdjs.storeCode.GDstore_9595buttonObjects3= [];
gdjs.storeCode.GDstore_9595button2Objects1= [];
gdjs.storeCode.GDstore_9595button2Objects2= [];
gdjs.storeCode.GDstore_9595button2Objects3= [];
gdjs.storeCode.GDstore_9595button3Objects1= [];
gdjs.storeCode.GDstore_9595button3Objects2= [];
gdjs.storeCode.GDstore_9595button3Objects3= [];
gdjs.storeCode.GDStore_9595textObjects1= [];
gdjs.storeCode.GDStore_9595textObjects2= [];
gdjs.storeCode.GDStore_9595textObjects3= [];
gdjs.storeCode.GDroundObjects1= [];
gdjs.storeCode.GDroundObjects2= [];
gdjs.storeCode.GDroundObjects3= [];
gdjs.storeCode.GDmaket_9595heroObjects1= [];
gdjs.storeCode.GDmaket_9595heroObjects2= [];
gdjs.storeCode.GDmaket_9595heroObjects3= [];
gdjs.storeCode.GDmaket_9595slimeObjects1= [];
gdjs.storeCode.GDmaket_9595slimeObjects2= [];
gdjs.storeCode.GDmaket_9595slimeObjects3= [];
gdjs.storeCode.GDgrass_9595blockObjects1= [];
gdjs.storeCode.GDgrass_9595blockObjects2= [];
gdjs.storeCode.GDgrass_9595blockObjects3= [];
gdjs.storeCode.GDblockObjects1= [];
gdjs.storeCode.GDblockObjects2= [];
gdjs.storeCode.GDblockObjects3= [];
gdjs.storeCode.GDmenuObjects1= [];
gdjs.storeCode.GDmenuObjects2= [];
gdjs.storeCode.GDmenuObjects3= [];
gdjs.storeCode.GDhomeObjects1= [];
gdjs.storeCode.GDhomeObjects2= [];
gdjs.storeCode.GDhomeObjects3= [];
gdjs.storeCode.GDresetObjects1= [];
gdjs.storeCode.GDresetObjects2= [];
gdjs.storeCode.GDresetObjects3= [];
gdjs.storeCode.GDspikeObjects1= [];
gdjs.storeCode.GDspikeObjects2= [];
gdjs.storeCode.GDspikeObjects3= [];
gdjs.storeCode.GDend_9595homeObjects1= [];
gdjs.storeCode.GDend_9595homeObjects2= [];
gdjs.storeCode.GDend_9595homeObjects3= [];
gdjs.storeCode.GDend_9595resetObjects1= [];
gdjs.storeCode.GDend_9595resetObjects2= [];
gdjs.storeCode.GDend_9595resetObjects3= [];
gdjs.storeCode.GDrobot_9595enemyObjects1= [];
gdjs.storeCode.GDrobot_9595enemyObjects2= [];
gdjs.storeCode.GDrobot_9595enemyObjects3= [];
gdjs.storeCode.GDslime_9595enemyObjects1= [];
gdjs.storeCode.GDslime_9595enemyObjects2= [];
gdjs.storeCode.GDslime_9595enemyObjects3= [];
gdjs.storeCode.GDrob_9595enemy_9595rightObjects1= [];
gdjs.storeCode.GDrob_9595enemy_9595rightObjects2= [];
gdjs.storeCode.GDrob_9595enemy_9595rightObjects3= [];
gdjs.storeCode.GDrob_9595enemy_9595leftObjects1= [];
gdjs.storeCode.GDrob_9595enemy_9595leftObjects2= [];
gdjs.storeCode.GDrob_9595enemy_9595leftObjects3= [];
gdjs.storeCode.GDheroObjects1= [];
gdjs.storeCode.GDheroObjects2= [];
gdjs.storeCode.GDheroObjects3= [];
gdjs.storeCode.GDsawObjects1= [];
gdjs.storeCode.GDsawObjects2= [];
gdjs.storeCode.GDsawObjects3= [];
gdjs.storeCode.GDcoin_9595markerObjects1= [];
gdjs.storeCode.GDcoin_9595markerObjects2= [];
gdjs.storeCode.GDcoin_9595markerObjects3= [];
gdjs.storeCode.GDcoin_9595marker2Objects1= [];
gdjs.storeCode.GDcoin_9595marker2Objects2= [];
gdjs.storeCode.GDcoin_9595marker2Objects3= [];
gdjs.storeCode.GDcoinsObjects1= [];
gdjs.storeCode.GDcoinsObjects2= [];
gdjs.storeCode.GDcoinsObjects3= [];
gdjs.storeCode.GDcoins2Objects1= [];
gdjs.storeCode.GDcoins2Objects2= [];
gdjs.storeCode.GDcoins2Objects3= [];
gdjs.storeCode.GDkey_9595lockerObjects1= [];
gdjs.storeCode.GDkey_9595lockerObjects2= [];
gdjs.storeCode.GDkey_9595lockerObjects3= [];
gdjs.storeCode.GDr_9595buttonObjects1= [];
gdjs.storeCode.GDr_9595buttonObjects2= [];
gdjs.storeCode.GDr_9595buttonObjects3= [];
gdjs.storeCode.GDl_9595buttonObjects1= [];
gdjs.storeCode.GDl_9595buttonObjects2= [];
gdjs.storeCode.GDl_9595buttonObjects3= [];
gdjs.storeCode.GDbackObjects1= [];
gdjs.storeCode.GDbackObjects2= [];
gdjs.storeCode.GDbackObjects3= [];
gdjs.storeCode.GDlockObjects1= [];
gdjs.storeCode.GDlockObjects2= [];
gdjs.storeCode.GDlockObjects3= [];
gdjs.storeCode.GDcamObjects1= [];
gdjs.storeCode.GDcamObjects2= [];
gdjs.storeCode.GDcamObjects3= [];
gdjs.storeCode.GDfonikObjects1= [];
gdjs.storeCode.GDfonikObjects2= [];
gdjs.storeCode.GDfonikObjects3= [];


gdjs.storeCode.asyncCallback66929580 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("store_button"), gdjs.storeCode.GDstore_9595buttonObjects3);

{for(var i = 0, len = gdjs.storeCode.GDstore_9595buttonObjects3.length ;i < len;++i) {
    gdjs.storeCode.GDstore_9595buttonObjects3[i].setAnimationName("NewSprite2");
}
}}
gdjs.storeCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.storeCode.GDstore_9595buttonObjects2) asyncObjectsList.addObject("store_button", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.storeCode.asyncCallback66929580(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.storeCode.asyncCallback66931708 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("store_button2"), gdjs.storeCode.GDstore_9595button2Objects3);

{for(var i = 0, len = gdjs.storeCode.GDstore_9595button2Objects3.length ;i < len;++i) {
    gdjs.storeCode.GDstore_9595button2Objects3[i].setAnimationName("NewSprite2");
}
}}
gdjs.storeCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.storeCode.GDstore_9595button2Objects2) asyncObjectsList.addObject("store_button2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.storeCode.asyncCallback66931708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.storeCode.asyncCallback66933860 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("store_button3"), gdjs.storeCode.GDstore_9595button3Objects2);

{for(var i = 0, len = gdjs.storeCode.GDstore_9595button3Objects2.length ;i < len;++i) {
    gdjs.storeCode.GDstore_9595button3Objects2[i].setAnimationName("NewSprite2");
}
}}
gdjs.storeCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.storeCode.GDstore_9595button3Objects1) asyncObjectsList.addObject("store_button3", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.storeCode.asyncCallback66933860(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.storeCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("store_button"), gdjs.storeCode.GDstore_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.storeCode.GDstore_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.storeCode.GDstore_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.storeCode.GDstore_9595buttonObjects2[k] = gdjs.storeCode.GDstore_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.storeCode.GDstore_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66929020);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.storeCode.GDstore_9595buttonObjects2 */
{for(var i = 0, len = gdjs.storeCode.GDstore_9595buttonObjects2.length ;i < len;++i) {
    gdjs.storeCode.GDstore_9595buttonObjects2[i].setAnimationName("store_button");
}
}
{ //Subevents
gdjs.storeCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("store_button2"), gdjs.storeCode.GDstore_9595button2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.storeCode.GDstore_9595button2Objects2.length;i<l;++i) {
    if ( gdjs.storeCode.GDstore_9595button2Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.storeCode.GDstore_9595button2Objects2[k] = gdjs.storeCode.GDstore_9595button2Objects2[i];
        ++k;
    }
}
gdjs.storeCode.GDstore_9595button2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66931028);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.storeCode.GDstore_9595button2Objects2 */
{for(var i = 0, len = gdjs.storeCode.GDstore_9595button2Objects2.length ;i < len;++i) {
    gdjs.storeCode.GDstore_9595button2Objects2[i].setAnimationName("store_button");
}
}
{ //Subevents
gdjs.storeCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("store_button3"), gdjs.storeCode.GDstore_9595button3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.storeCode.GDstore_9595button3Objects1.length;i<l;++i) {
    if ( gdjs.storeCode.GDstore_9595button3Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.storeCode.GDstore_9595button3Objects1[k] = gdjs.storeCode.GDstore_9595button3Objects1[i];
        ++k;
    }
}
gdjs.storeCode.GDstore_9595button3Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66933180);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.storeCode.GDstore_9595button3Objects1 */
{for(var i = 0, len = gdjs.storeCode.GDstore_9595button3Objects1.length ;i < len;++i) {
    gdjs.storeCode.GDstore_9595button3Objects1[i].setAnimationName("store_button");
}
}
{ //Subevents
gdjs.storeCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.storeCode.asyncCallback66929300 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}}
gdjs.storeCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.storeCode.asyncCallback66929300(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.storeCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.storeCode.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.storeCode.GDbackObjects1.length;i<l;++i) {
    if ( gdjs.storeCode.GDbackObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.storeCode.GDbackObjects1[k] = gdjs.storeCode.GDbackObjects1[i];
        ++k;
    }
}
gdjs.storeCode.GDbackObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66933620);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.storeCode.GDbackObjects1 */
{for(var i = 0, len = gdjs.storeCode.GDbackObjects1.length ;i < len;++i) {
    gdjs.storeCode.GDbackObjects1[i].setAnimationName("back");
}
}{/* Unknown object - skipped. */}
{ //Subevents
gdjs.storeCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.storeCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__InAppPurchase__FinalizeRegistration.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.storeCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.storeCode.GDcoins2Objects2);
{runtimeScene.getGame().getVariables().getFromIndex(4).add(300);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.storeCode.GDcoins2Objects2.length ;i < len;++i) {
    gdjs.storeCode.GDcoins2Objects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.storeCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.storeCode.GDcoins2Objects2);
{runtimeScene.getGame().getVariables().getFromIndex(4).add(700);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.storeCode.GDcoins2Objects2.length ;i < len;++i) {
    gdjs.storeCode.GDcoins2Objects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.storeCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.storeCode.GDcoins2Objects1);
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1500);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.storeCode.GDcoins2Objects1.length ;i < len;++i) {
    gdjs.storeCode.GDcoins2Objects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.storeCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("text_cost_on_button"), gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_cost_on_button2"), gdjs.storeCode.GDtext_9595cost_9595on_9595button2Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_cost_on_button3"), gdjs.storeCode.GDtext_9595cost_9595on_9595button3Objects2);
{for(var i = 0, len = gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects2.length ;i < len;++i) {
    gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("price")));
}
}{for(var i = 0, len = gdjs.storeCode.GDtext_9595cost_9595on_9595button2Objects2.length ;i < len;++i) {
    gdjs.storeCode.GDtext_9595cost_9595on_9595button2Objects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("price")));
}
}{for(var i = 0, len = gdjs.storeCode.GDtext_9595cost_9595on_9595button3Objects2.length ;i < len;++i) {
    gdjs.storeCode.GDtext_9595cost_9595on_9595button3Objects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("price")));
}
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__InAppPurchase__WatchItemEvent.func(runtimeScene, "300_coins", "paid_300_coins", "approved", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InAppPurchase__WatchItemEvent.func(runtimeScene, "700_coins", "paid_700_coins", "approved", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InAppPurchase__WatchItemEvent.func(runtimeScene, "1500_coins", "paid_1500_coins", "approved", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("store_button"), gdjs.storeCode.GDstore_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.storeCode.GDstore_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.storeCode.GDstore_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.storeCode.GDstore_9595buttonObjects2[k] = gdjs.storeCode.GDstore_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.storeCode.GDstore_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66917740);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InAppPurchase__OrderItem.func(runtimeScene, "300_coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("store_button2"), gdjs.storeCode.GDstore_9595button2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.storeCode.GDstore_9595button2Objects2.length;i<l;++i) {
    if ( gdjs.storeCode.GDstore_9595button2Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.storeCode.GDstore_9595button2Objects2[k] = gdjs.storeCode.GDstore_9595button2Objects2[i];
        ++k;
    }
}
gdjs.storeCode.GDstore_9595button2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66922972);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InAppPurchase__OrderItem.func(runtimeScene, "700_coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("store_button3"), gdjs.storeCode.GDstore_9595button3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.storeCode.GDstore_9595button3Objects2.length;i<l;++i) {
    if ( gdjs.storeCode.GDstore_9595button3Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.storeCode.GDstore_9595button3Objects2[k] = gdjs.storeCode.GDstore_9595button3Objects2[i];
        ++k;
    }
}
gdjs.storeCode.GDstore_9595button3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66936868);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InAppPurchase__OrderItem.func(runtimeScene, "1500_coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(3), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66937748);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InAppPurchase__FinalizePurchase.func(runtimeScene, "300_coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.storeCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66939500);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InAppPurchase__FinalizePurchase.func(runtimeScene, "700_coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.storeCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(5), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66941228);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__InAppPurchase__FinalizePurchase.func(runtimeScene, "1500_coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.storeCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.storeCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtsExt__InAppPurchase__RegisterItem.func(runtimeScene, "300_coins", "consumable", "300 coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InAppPurchase__RegisterItem.func(runtimeScene, "700_coins", "consumable", "700 coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InAppPurchase__RegisterItem.func(runtimeScene, "1500_coins", "consumable", "1500 coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.storeCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__InAppPurchase__StoreReady.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{gdjs.evtsExt__InAppPurchase__GetProduct.func(runtimeScene, "300_coins", "ver_300coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InAppPurchase__GetProduct.func(runtimeScene, "700_coins", "ver_700coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InAppPurchase__GetProduct.func(runtimeScene, "1500_coins", "ver_1500coins", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.storeCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDstore_95959595buttonObjects2Objects = Hashtable.newFrom({"store_button": gdjs.storeCode.GDstore_9595buttonObjects2});
gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDtext_95959595cost_95959595on_95959595buttonObjects2Objects = Hashtable.newFrom({"text_cost_on_button": gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects2});
gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDstore_95959595button2Objects2Objects = Hashtable.newFrom({"store_button2": gdjs.storeCode.GDstore_9595button2Objects2});
gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDtext_95959595cost_95959595on_95959595buttonObjects2Objects = Hashtable.newFrom({"text_cost_on_button": gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects2});
gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDstore_95959595button3Objects1Objects = Hashtable.newFrom({"store_button3": gdjs.storeCode.GDstore_9595button3Objects1});
gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDtext_95959595cost_95959595on_95959595buttonObjects1Objects = Hashtable.newFrom({"text_cost_on_button": gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects1});
gdjs.storeCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("store_button"), gdjs.storeCode.GDstore_9595buttonObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_cost_on_button"), gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_value"), gdjs.storeCode.GDtext_9595valueObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.storeCode.GDtext_9595valueObjects2.length;i<l;++i) {
    if ( gdjs.storeCode.GDtext_9595valueObjects2[i].getVariableNumber(gdjs.storeCode.GDtext_9595valueObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.storeCode.GDtext_9595valueObjects2[k] = gdjs.storeCode.GDtext_9595valueObjects2[i];
        ++k;
    }
}
gdjs.storeCode.GDtext_9595valueObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDstore_95959595buttonObjects2Objects, gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDtext_95959595cost_95959595on_95959595buttonObjects2Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.storeCode.GDtext_9595valueObjects2 */
{for(var i = 0, len = gdjs.storeCode.GDtext_9595valueObjects2.length ;i < len;++i) {
    gdjs.storeCode.GDtext_9595valueObjects2[i].setString("300");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("store_button2"), gdjs.storeCode.GDstore_9595button2Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_cost_on_button"), gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_value"), gdjs.storeCode.GDtext_9595valueObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.storeCode.GDtext_9595valueObjects2.length;i<l;++i) {
    if ( gdjs.storeCode.GDtext_9595valueObjects2[i].getVariableNumber(gdjs.storeCode.GDtext_9595valueObjects2[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.storeCode.GDtext_9595valueObjects2[k] = gdjs.storeCode.GDtext_9595valueObjects2[i];
        ++k;
    }
}
gdjs.storeCode.GDtext_9595valueObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDstore_95959595button2Objects2Objects, gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDtext_95959595cost_95959595on_95959595buttonObjects2Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.storeCode.GDtext_9595valueObjects2 */
{for(var i = 0, len = gdjs.storeCode.GDtext_9595valueObjects2.length ;i < len;++i) {
    gdjs.storeCode.GDtext_9595valueObjects2[i].setString("700");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("store_button3"), gdjs.storeCode.GDstore_9595button3Objects1);
gdjs.copyArray(runtimeScene.getObjects("text_cost_on_button"), gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("text_value"), gdjs.storeCode.GDtext_9595valueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.storeCode.GDtext_9595valueObjects1.length;i<l;++i) {
    if ( gdjs.storeCode.GDtext_9595valueObjects1[i].getVariableNumber(gdjs.storeCode.GDtext_9595valueObjects1[i].getVariables().getFromIndex(0)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.storeCode.GDtext_9595valueObjects1[k] = gdjs.storeCode.GDtext_9595valueObjects1[i];
        ++k;
    }
}
gdjs.storeCode.GDtext_9595valueObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDstore_95959595button3Objects1Objects, gdjs.storeCode.mapOfGDgdjs_9546storeCode_9546GDtext_95959595cost_95959595on_95959595buttonObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.storeCode.GDtext_9595valueObjects1 */
{for(var i = 0, len = gdjs.storeCode.GDtext_9595valueObjects1.length ;i < len;++i) {
    gdjs.storeCode.GDtext_9595valueObjects1[i].setString("1500");
}
}}

}


};gdjs.storeCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("maket_slime"), gdjs.storeCode.GDmaket_9595slimeObjects1);
{gdjs.evtTools.sound.playMusic(runtimeScene, "HoliznaCC0 - NPC Theme.mp3", true, 20, 1);
}{for(var i = 0, len = gdjs.storeCode.GDmaket_9595slimeObjects1.length ;i < len;++i) {
    gdjs.storeCode.GDmaket_9595slimeObjects1[i].flipX(true);
}
}
{ //Subevents
gdjs.storeCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.storeCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.storeCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}
{ //Subevents
gdjs.storeCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.storeCode.eventsList16 = function(runtimeScene) {

{


gdjs.storeCode.eventsList3(runtimeScene);
}


{


gdjs.storeCode.eventsList5(runtimeScene);
}


{


gdjs.storeCode.eventsList11(runtimeScene);
}


{


gdjs.storeCode.eventsList13(runtimeScene);
}


{


gdjs.storeCode.eventsList15(runtimeScene);
}


};

gdjs.storeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.storeCode.GDstore_9595coin_9595markerObjects1.length = 0;
gdjs.storeCode.GDstore_9595coin_9595markerObjects2.length = 0;
gdjs.storeCode.GDstore_9595coin_9595markerObjects3.length = 0;
gdjs.storeCode.GDtext_9595valueObjects1.length = 0;
gdjs.storeCode.GDtext_9595valueObjects2.length = 0;
gdjs.storeCode.GDtext_9595valueObjects3.length = 0;
gdjs.storeCode.GDnot_9595work_9595textObjects1.length = 0;
gdjs.storeCode.GDnot_9595work_9595textObjects2.length = 0;
gdjs.storeCode.GDnot_9595work_9595textObjects3.length = 0;
gdjs.storeCode.GDfree_9595textObjects1.length = 0;
gdjs.storeCode.GDfree_9595textObjects2.length = 0;
gdjs.storeCode.GDfree_9595textObjects3.length = 0;
gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects1.length = 0;
gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects2.length = 0;
gdjs.storeCode.GDtext_9595cost_9595on_9595buttonObjects3.length = 0;
gdjs.storeCode.GDtext_9595cost_9595on_9595button2Objects1.length = 0;
gdjs.storeCode.GDtext_9595cost_9595on_9595button2Objects2.length = 0;
gdjs.storeCode.GDtext_9595cost_9595on_9595button2Objects3.length = 0;
gdjs.storeCode.GDtext_9595cost_9595on_9595button3Objects1.length = 0;
gdjs.storeCode.GDtext_9595cost_9595on_9595button3Objects2.length = 0;
gdjs.storeCode.GDtext_9595cost_9595on_9595button3Objects3.length = 0;
gdjs.storeCode.GDstore_9595buttonObjects1.length = 0;
gdjs.storeCode.GDstore_9595buttonObjects2.length = 0;
gdjs.storeCode.GDstore_9595buttonObjects3.length = 0;
gdjs.storeCode.GDstore_9595button2Objects1.length = 0;
gdjs.storeCode.GDstore_9595button2Objects2.length = 0;
gdjs.storeCode.GDstore_9595button2Objects3.length = 0;
gdjs.storeCode.GDstore_9595button3Objects1.length = 0;
gdjs.storeCode.GDstore_9595button3Objects2.length = 0;
gdjs.storeCode.GDstore_9595button3Objects3.length = 0;
gdjs.storeCode.GDStore_9595textObjects1.length = 0;
gdjs.storeCode.GDStore_9595textObjects2.length = 0;
gdjs.storeCode.GDStore_9595textObjects3.length = 0;
gdjs.storeCode.GDroundObjects1.length = 0;
gdjs.storeCode.GDroundObjects2.length = 0;
gdjs.storeCode.GDroundObjects3.length = 0;
gdjs.storeCode.GDmaket_9595heroObjects1.length = 0;
gdjs.storeCode.GDmaket_9595heroObjects2.length = 0;
gdjs.storeCode.GDmaket_9595heroObjects3.length = 0;
gdjs.storeCode.GDmaket_9595slimeObjects1.length = 0;
gdjs.storeCode.GDmaket_9595slimeObjects2.length = 0;
gdjs.storeCode.GDmaket_9595slimeObjects3.length = 0;
gdjs.storeCode.GDgrass_9595blockObjects1.length = 0;
gdjs.storeCode.GDgrass_9595blockObjects2.length = 0;
gdjs.storeCode.GDgrass_9595blockObjects3.length = 0;
gdjs.storeCode.GDblockObjects1.length = 0;
gdjs.storeCode.GDblockObjects2.length = 0;
gdjs.storeCode.GDblockObjects3.length = 0;
gdjs.storeCode.GDmenuObjects1.length = 0;
gdjs.storeCode.GDmenuObjects2.length = 0;
gdjs.storeCode.GDmenuObjects3.length = 0;
gdjs.storeCode.GDhomeObjects1.length = 0;
gdjs.storeCode.GDhomeObjects2.length = 0;
gdjs.storeCode.GDhomeObjects3.length = 0;
gdjs.storeCode.GDresetObjects1.length = 0;
gdjs.storeCode.GDresetObjects2.length = 0;
gdjs.storeCode.GDresetObjects3.length = 0;
gdjs.storeCode.GDspikeObjects1.length = 0;
gdjs.storeCode.GDspikeObjects2.length = 0;
gdjs.storeCode.GDspikeObjects3.length = 0;
gdjs.storeCode.GDend_9595homeObjects1.length = 0;
gdjs.storeCode.GDend_9595homeObjects2.length = 0;
gdjs.storeCode.GDend_9595homeObjects3.length = 0;
gdjs.storeCode.GDend_9595resetObjects1.length = 0;
gdjs.storeCode.GDend_9595resetObjects2.length = 0;
gdjs.storeCode.GDend_9595resetObjects3.length = 0;
gdjs.storeCode.GDrobot_9595enemyObjects1.length = 0;
gdjs.storeCode.GDrobot_9595enemyObjects2.length = 0;
gdjs.storeCode.GDrobot_9595enemyObjects3.length = 0;
gdjs.storeCode.GDslime_9595enemyObjects1.length = 0;
gdjs.storeCode.GDslime_9595enemyObjects2.length = 0;
gdjs.storeCode.GDslime_9595enemyObjects3.length = 0;
gdjs.storeCode.GDrob_9595enemy_9595rightObjects1.length = 0;
gdjs.storeCode.GDrob_9595enemy_9595rightObjects2.length = 0;
gdjs.storeCode.GDrob_9595enemy_9595rightObjects3.length = 0;
gdjs.storeCode.GDrob_9595enemy_9595leftObjects1.length = 0;
gdjs.storeCode.GDrob_9595enemy_9595leftObjects2.length = 0;
gdjs.storeCode.GDrob_9595enemy_9595leftObjects3.length = 0;
gdjs.storeCode.GDheroObjects1.length = 0;
gdjs.storeCode.GDheroObjects2.length = 0;
gdjs.storeCode.GDheroObjects3.length = 0;
gdjs.storeCode.GDsawObjects1.length = 0;
gdjs.storeCode.GDsawObjects2.length = 0;
gdjs.storeCode.GDsawObjects3.length = 0;
gdjs.storeCode.GDcoin_9595markerObjects1.length = 0;
gdjs.storeCode.GDcoin_9595markerObjects2.length = 0;
gdjs.storeCode.GDcoin_9595markerObjects3.length = 0;
gdjs.storeCode.GDcoin_9595marker2Objects1.length = 0;
gdjs.storeCode.GDcoin_9595marker2Objects2.length = 0;
gdjs.storeCode.GDcoin_9595marker2Objects3.length = 0;
gdjs.storeCode.GDcoinsObjects1.length = 0;
gdjs.storeCode.GDcoinsObjects2.length = 0;
gdjs.storeCode.GDcoinsObjects3.length = 0;
gdjs.storeCode.GDcoins2Objects1.length = 0;
gdjs.storeCode.GDcoins2Objects2.length = 0;
gdjs.storeCode.GDcoins2Objects3.length = 0;
gdjs.storeCode.GDkey_9595lockerObjects1.length = 0;
gdjs.storeCode.GDkey_9595lockerObjects2.length = 0;
gdjs.storeCode.GDkey_9595lockerObjects3.length = 0;
gdjs.storeCode.GDr_9595buttonObjects1.length = 0;
gdjs.storeCode.GDr_9595buttonObjects2.length = 0;
gdjs.storeCode.GDr_9595buttonObjects3.length = 0;
gdjs.storeCode.GDl_9595buttonObjects1.length = 0;
gdjs.storeCode.GDl_9595buttonObjects2.length = 0;
gdjs.storeCode.GDl_9595buttonObjects3.length = 0;
gdjs.storeCode.GDbackObjects1.length = 0;
gdjs.storeCode.GDbackObjects2.length = 0;
gdjs.storeCode.GDbackObjects3.length = 0;
gdjs.storeCode.GDlockObjects1.length = 0;
gdjs.storeCode.GDlockObjects2.length = 0;
gdjs.storeCode.GDlockObjects3.length = 0;
gdjs.storeCode.GDcamObjects1.length = 0;
gdjs.storeCode.GDcamObjects2.length = 0;
gdjs.storeCode.GDcamObjects3.length = 0;
gdjs.storeCode.GDfonikObjects1.length = 0;
gdjs.storeCode.GDfonikObjects2.length = 0;
gdjs.storeCode.GDfonikObjects3.length = 0;

gdjs.storeCode.eventsList16(runtimeScene);

return;

}

gdjs['storeCode'] = gdjs.storeCode;
