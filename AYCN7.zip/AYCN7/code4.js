gdjs.hatsCode = {};
gdjs.hatsCode.GDbackObjects1_1final = [];

gdjs.hatsCode.GDl_9595buttonObjects1_1final = [];

gdjs.hatsCode.GDr_9595buttonObjects1_1final = [];

gdjs.hatsCode.GDhat_95950Objects1= [];
gdjs.hatsCode.GDhat_95950Objects2= [];
gdjs.hatsCode.GDhat_95950Objects3= [];
gdjs.hatsCode.GDhat_95950Objects4= [];
gdjs.hatsCode.GDhat_95951Objects1= [];
gdjs.hatsCode.GDhat_95951Objects2= [];
gdjs.hatsCode.GDhat_95951Objects3= [];
gdjs.hatsCode.GDhat_95951Objects4= [];
gdjs.hatsCode.GDhat_95952Objects1= [];
gdjs.hatsCode.GDhat_95952Objects2= [];
gdjs.hatsCode.GDhat_95952Objects3= [];
gdjs.hatsCode.GDhat_95952Objects4= [];
gdjs.hatsCode.GDhat_95953Objects1= [];
gdjs.hatsCode.GDhat_95953Objects2= [];
gdjs.hatsCode.GDhat_95953Objects3= [];
gdjs.hatsCode.GDhat_95953Objects4= [];
gdjs.hatsCode.GDhat_95954Objects1= [];
gdjs.hatsCode.GDhat_95954Objects2= [];
gdjs.hatsCode.GDhat_95954Objects3= [];
gdjs.hatsCode.GDhat_95954Objects4= [];
gdjs.hatsCode.GDhat_95955Objects1= [];
gdjs.hatsCode.GDhat_95955Objects2= [];
gdjs.hatsCode.GDhat_95955Objects3= [];
gdjs.hatsCode.GDhat_95955Objects4= [];
gdjs.hatsCode.GDhat_95956Objects1= [];
gdjs.hatsCode.GDhat_95956Objects2= [];
gdjs.hatsCode.GDhat_95956Objects3= [];
gdjs.hatsCode.GDhat_95956Objects4= [];
gdjs.hatsCode.GDhat_95957Objects1= [];
gdjs.hatsCode.GDhat_95957Objects2= [];
gdjs.hatsCode.GDhat_95957Objects3= [];
gdjs.hatsCode.GDhat_95957Objects4= [];
gdjs.hatsCode.GDhat_95958Objects1= [];
gdjs.hatsCode.GDhat_95958Objects2= [];
gdjs.hatsCode.GDhat_95958Objects3= [];
gdjs.hatsCode.GDhat_95958Objects4= [];
gdjs.hatsCode.GDhat_95959Objects1= [];
gdjs.hatsCode.GDhat_95959Objects2= [];
gdjs.hatsCode.GDhat_95959Objects3= [];
gdjs.hatsCode.GDhat_95959Objects4= [];
gdjs.hatsCode.GDhat_9595randomObjects1= [];
gdjs.hatsCode.GDhat_9595randomObjects2= [];
gdjs.hatsCode.GDhat_9595randomObjects3= [];
gdjs.hatsCode.GDhat_9595randomObjects4= [];
gdjs.hatsCode.GDhat_9595dldoObjects1= [];
gdjs.hatsCode.GDhat_9595dldoObjects2= [];
gdjs.hatsCode.GDhat_9595dldoObjects3= [];
gdjs.hatsCode.GDhat_9595dldoObjects4= [];
gdjs.hatsCode.GDtext_9595pickObjects1= [];
gdjs.hatsCode.GDtext_9595pickObjects2= [];
gdjs.hatsCode.GDtext_9595pickObjects3= [];
gdjs.hatsCode.GDtext_9595pickObjects4= [];
gdjs.hatsCode.GDbuyObjects1= [];
gdjs.hatsCode.GDbuyObjects2= [];
gdjs.hatsCode.GDbuyObjects3= [];
gdjs.hatsCode.GDbuyObjects4= [];
gdjs.hatsCode.GDcostObjects1= [];
gdjs.hatsCode.GDcostObjects2= [];
gdjs.hatsCode.GDcostObjects3= [];
gdjs.hatsCode.GDcostObjects4= [];
gdjs.hatsCode.GDpickerObjects1= [];
gdjs.hatsCode.GDpickerObjects2= [];
gdjs.hatsCode.GDpickerObjects3= [];
gdjs.hatsCode.GDpickerObjects4= [];
gdjs.hatsCode.GDcoin_9595marker_9595hatsObjects1= [];
gdjs.hatsCode.GDcoin_9595marker_9595hatsObjects2= [];
gdjs.hatsCode.GDcoin_9595marker_9595hatsObjects3= [];
gdjs.hatsCode.GDcoin_9595marker_9595hatsObjects4= [];
gdjs.hatsCode.GDgrass_9595blockObjects1= [];
gdjs.hatsCode.GDgrass_9595blockObjects2= [];
gdjs.hatsCode.GDgrass_9595blockObjects3= [];
gdjs.hatsCode.GDgrass_9595blockObjects4= [];
gdjs.hatsCode.GDblockObjects1= [];
gdjs.hatsCode.GDblockObjects2= [];
gdjs.hatsCode.GDblockObjects3= [];
gdjs.hatsCode.GDblockObjects4= [];
gdjs.hatsCode.GDmenuObjects1= [];
gdjs.hatsCode.GDmenuObjects2= [];
gdjs.hatsCode.GDmenuObjects3= [];
gdjs.hatsCode.GDmenuObjects4= [];
gdjs.hatsCode.GDhomeObjects1= [];
gdjs.hatsCode.GDhomeObjects2= [];
gdjs.hatsCode.GDhomeObjects3= [];
gdjs.hatsCode.GDhomeObjects4= [];
gdjs.hatsCode.GDresetObjects1= [];
gdjs.hatsCode.GDresetObjects2= [];
gdjs.hatsCode.GDresetObjects3= [];
gdjs.hatsCode.GDresetObjects4= [];
gdjs.hatsCode.GDspikeObjects1= [];
gdjs.hatsCode.GDspikeObjects2= [];
gdjs.hatsCode.GDspikeObjects3= [];
gdjs.hatsCode.GDspikeObjects4= [];
gdjs.hatsCode.GDend_9595homeObjects1= [];
gdjs.hatsCode.GDend_9595homeObjects2= [];
gdjs.hatsCode.GDend_9595homeObjects3= [];
gdjs.hatsCode.GDend_9595homeObjects4= [];
gdjs.hatsCode.GDend_9595resetObjects1= [];
gdjs.hatsCode.GDend_9595resetObjects2= [];
gdjs.hatsCode.GDend_9595resetObjects3= [];
gdjs.hatsCode.GDend_9595resetObjects4= [];
gdjs.hatsCode.GDrobot_9595enemyObjects1= [];
gdjs.hatsCode.GDrobot_9595enemyObjects2= [];
gdjs.hatsCode.GDrobot_9595enemyObjects3= [];
gdjs.hatsCode.GDrobot_9595enemyObjects4= [];
gdjs.hatsCode.GDslime_9595enemyObjects1= [];
gdjs.hatsCode.GDslime_9595enemyObjects2= [];
gdjs.hatsCode.GDslime_9595enemyObjects3= [];
gdjs.hatsCode.GDslime_9595enemyObjects4= [];
gdjs.hatsCode.GDrob_9595enemy_9595rightObjects1= [];
gdjs.hatsCode.GDrob_9595enemy_9595rightObjects2= [];
gdjs.hatsCode.GDrob_9595enemy_9595rightObjects3= [];
gdjs.hatsCode.GDrob_9595enemy_9595rightObjects4= [];
gdjs.hatsCode.GDrob_9595enemy_9595leftObjects1= [];
gdjs.hatsCode.GDrob_9595enemy_9595leftObjects2= [];
gdjs.hatsCode.GDrob_9595enemy_9595leftObjects3= [];
gdjs.hatsCode.GDrob_9595enemy_9595leftObjects4= [];
gdjs.hatsCode.GDheroObjects1= [];
gdjs.hatsCode.GDheroObjects2= [];
gdjs.hatsCode.GDheroObjects3= [];
gdjs.hatsCode.GDheroObjects4= [];
gdjs.hatsCode.GDsawObjects1= [];
gdjs.hatsCode.GDsawObjects2= [];
gdjs.hatsCode.GDsawObjects3= [];
gdjs.hatsCode.GDsawObjects4= [];
gdjs.hatsCode.GDcoin_9595markerObjects1= [];
gdjs.hatsCode.GDcoin_9595markerObjects2= [];
gdjs.hatsCode.GDcoin_9595markerObjects3= [];
gdjs.hatsCode.GDcoin_9595markerObjects4= [];
gdjs.hatsCode.GDcoin_9595marker2Objects1= [];
gdjs.hatsCode.GDcoin_9595marker2Objects2= [];
gdjs.hatsCode.GDcoin_9595marker2Objects3= [];
gdjs.hatsCode.GDcoin_9595marker2Objects4= [];
gdjs.hatsCode.GDcoinsObjects1= [];
gdjs.hatsCode.GDcoinsObjects2= [];
gdjs.hatsCode.GDcoinsObjects3= [];
gdjs.hatsCode.GDcoinsObjects4= [];
gdjs.hatsCode.GDcoins2Objects1= [];
gdjs.hatsCode.GDcoins2Objects2= [];
gdjs.hatsCode.GDcoins2Objects3= [];
gdjs.hatsCode.GDcoins2Objects4= [];
gdjs.hatsCode.GDkey_9595lockerObjects1= [];
gdjs.hatsCode.GDkey_9595lockerObjects2= [];
gdjs.hatsCode.GDkey_9595lockerObjects3= [];
gdjs.hatsCode.GDkey_9595lockerObjects4= [];
gdjs.hatsCode.GDr_9595buttonObjects1= [];
gdjs.hatsCode.GDr_9595buttonObjects2= [];
gdjs.hatsCode.GDr_9595buttonObjects3= [];
gdjs.hatsCode.GDr_9595buttonObjects4= [];
gdjs.hatsCode.GDl_9595buttonObjects1= [];
gdjs.hatsCode.GDl_9595buttonObjects2= [];
gdjs.hatsCode.GDl_9595buttonObjects3= [];
gdjs.hatsCode.GDl_9595buttonObjects4= [];
gdjs.hatsCode.GDbackObjects1= [];
gdjs.hatsCode.GDbackObjects2= [];
gdjs.hatsCode.GDbackObjects3= [];
gdjs.hatsCode.GDbackObjects4= [];
gdjs.hatsCode.GDlockObjects1= [];
gdjs.hatsCode.GDlockObjects2= [];
gdjs.hatsCode.GDlockObjects3= [];
gdjs.hatsCode.GDlockObjects4= [];
gdjs.hatsCode.GDcamObjects1= [];
gdjs.hatsCode.GDcamObjects2= [];
gdjs.hatsCode.GDcamObjects3= [];
gdjs.hatsCode.GDcamObjects4= [];
gdjs.hatsCode.GDfonikObjects1= [];
gdjs.hatsCode.GDfonikObjects2= [];
gdjs.hatsCode.GDfonikObjects3= [];
gdjs.hatsCode.GDfonikObjects4= [];


gdjs.hatsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cam"), gdjs.hatsCode.GDcamObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.hatsCode.GDcamObjects2.length !== 0 ? gdjs.hatsCode.GDcamObjects2[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.hatsCode.GDcamObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDcamObjects2[i].hide();
}
}}

}


{



}


};gdjs.hatsCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.hatsCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}
{ //Subevents
gdjs.hatsCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595959Objects2Objects = Hashtable.newFrom({"hat_9": gdjs.hatsCode.GDhat_95959Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595957Objects2Objects = Hashtable.newFrom({"hat_7": gdjs.hatsCode.GDhat_95957Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595958Objects2Objects = Hashtable.newFrom({"hat_8": gdjs.hatsCode.GDhat_95958Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595956Objects2Objects = Hashtable.newFrom({"hat_6": gdjs.hatsCode.GDhat_95956Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595955Objects2Objects = Hashtable.newFrom({"hat_5": gdjs.hatsCode.GDhat_95955Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595953Objects2Objects = Hashtable.newFrom({"hat_3": gdjs.hatsCode.GDhat_95953Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595952Objects2Objects = Hashtable.newFrom({"hat_2": gdjs.hatsCode.GDhat_95952Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects1Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects1});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595951Objects1Objects = Hashtable.newFrom({"hat_1": gdjs.hatsCode.GDhat_95951Objects1});
gdjs.hatsCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_9"), gdjs.hatsCode.GDhat_95959Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595959Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_9");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDlockObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDlockObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_7"), gdjs.hatsCode.GDhat_95957Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595957Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_7");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDlockObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDlockObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_8"), gdjs.hatsCode.GDhat_95958Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595958Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_8");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDlockObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDlockObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_6"), gdjs.hatsCode.GDhat_95956Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595956Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_6");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDlockObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDlockObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_5"), gdjs.hatsCode.GDhat_95955Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595955Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_5");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDlockObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDlockObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_3"), gdjs.hatsCode.GDhat_95953Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595953Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_3");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDlockObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDlockObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_2"), gdjs.hatsCode.GDhat_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595952Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_2");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDlockObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDlockObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_1"), gdjs.hatsCode.GDhat_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects1Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595951Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_1");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDlockObjects1 */
{for(var i = 0, len = gdjs.hatsCode.GDlockObjects1.length ;i < len;++i) {
    gdjs.hatsCode.GDlockObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.hatsCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hatsCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDbackObjects2Objects = Hashtable.newFrom({"back": gdjs.hatsCode.GDbackObjects2});
gdjs.hatsCode.asyncCallback67119636 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}
gdjs.hatsCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.hatsCode.asyncCallback67119636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDr_95959595buttonObjects2Objects = Hashtable.newFrom({"r_button": gdjs.hatsCode.GDr_9595buttonObjects2});
gdjs.hatsCode.asyncCallback67120628 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats2", false);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}
gdjs.hatsCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.hatsCode.asyncCallback67120628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDbackObjects2Objects = Hashtable.newFrom({"back": gdjs.hatsCode.GDbackObjects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDr_95959595buttonObjects2Objects = Hashtable.newFrom({"r_button": gdjs.hatsCode.GDr_9595buttonObjects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDl_95959595buttonObjects2Objects = Hashtable.newFrom({"l_button": gdjs.hatsCode.GDl_9595buttonObjects2});
gdjs.hatsCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hatsCode.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDbackObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hatsCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hatsCode.GDr_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDr_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hatsCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.hatsCode.GDbackObjects1.length = 0;

gdjs.hatsCode.GDl_9595buttonObjects1.length = 0;

gdjs.hatsCode.GDr_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.hatsCode.GDbackObjects1_1final.length = 0;
gdjs.hatsCode.GDl_9595buttonObjects1_1final.length = 0;
gdjs.hatsCode.GDr_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hatsCode.GDbackObjects2);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDbackObjects2Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hatsCode.GDbackObjects2.length; j < jLen ; ++j) {
        if ( gdjs.hatsCode.GDbackObjects1_1final.indexOf(gdjs.hatsCode.GDbackObjects2[j]) === -1 )
            gdjs.hatsCode.GDbackObjects1_1final.push(gdjs.hatsCode.GDbackObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hatsCode.GDr_9595buttonObjects2);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDr_95959595buttonObjects2Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hatsCode.GDr_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.hatsCode.GDr_9595buttonObjects1_1final.indexOf(gdjs.hatsCode.GDr_9595buttonObjects2[j]) === -1 )
            gdjs.hatsCode.GDr_9595buttonObjects1_1final.push(gdjs.hatsCode.GDr_9595buttonObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hatsCode.GDl_9595buttonObjects2);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDl_95959595buttonObjects2Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hatsCode.GDl_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.hatsCode.GDl_9595buttonObjects1_1final.indexOf(gdjs.hatsCode.GDl_9595buttonObjects2[j]) === -1 )
            gdjs.hatsCode.GDl_9595buttonObjects1_1final.push(gdjs.hatsCode.GDl_9595buttonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.hatsCode.GDbackObjects1_1final, gdjs.hatsCode.GDbackObjects1);
gdjs.copyArray(gdjs.hatsCode.GDl_9595buttonObjects1_1final, gdjs.hatsCode.GDl_9595buttonObjects1);
gdjs.copyArray(gdjs.hatsCode.GDr_9595buttonObjects1_1final, gdjs.hatsCode.GDr_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.hatsCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67118620);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hatsCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595950Objects2Objects = Hashtable.newFrom({"hat_0": gdjs.hatsCode.GDhat_95950Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDbuyObjects2Objects = Hashtable.newFrom({"buy": gdjs.hatsCode.GDbuyObjects2});
gdjs.hatsCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("key_locker"), gdjs.hatsCode.GDkey_9595lockerObjects3);
/* Reuse gdjs.hatsCode.GDlockObjects3 */
{for(var i = 0, len = gdjs.hatsCode.GDkey_9595lockerObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDkey_9595lockerObjects3[i].setPosition((( gdjs.hatsCode.GDlockObjects3.length === 0 ) ? 0 :gdjs.hatsCode.GDlockObjects3[0].getCenterXInScene()),(( gdjs.hatsCode.GDlockObjects3.length === 0 ) ? 0 :gdjs.hatsCode.GDlockObjects3[0].getCenterYInScene()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("buy"), gdjs.hatsCode.GDbuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDbuyObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects2);
gdjs.copyArray(runtimeScene.getObjects("key_locker"), gdjs.hatsCode.GDkey_9595lockerObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDkey_9595lockerObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDkey_9595lockerObjects2[i].setPosition(999,-(999));
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects2[i].setString("...");
}
}}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDbuyObjects2Objects = Hashtable.newFrom({"buy": gdjs.hatsCode.GDbuyObjects2});
gdjs.hatsCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hatsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hatsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hatsCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hatsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hatsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hatsCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hatsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hatsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hatsCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hatsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hatsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hatsCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hatsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hatsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hatsCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hatsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hatsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hatsCode.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hatsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hatsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hatsCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hatsCode.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hatsCode.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hatsCode.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hatsCode.GDcostObjects2, gdjs.hatsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_1", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hatsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hatsCode.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hatsCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hatsCode.GDcostObjects2, gdjs.hatsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_2", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hatsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hatsCode.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hatsCode.eventsList11(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hatsCode.GDcostObjects2, gdjs.hatsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_3", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hatsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hatsCode.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hatsCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hatsCode.GDcostObjects2, gdjs.hatsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_5", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hatsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hatsCode.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hatsCode.eventsList13(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 6;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hatsCode.GDcostObjects2, gdjs.hatsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_6", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hatsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hatsCode.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hatsCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 7;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hatsCode.GDcostObjects2, gdjs.hatsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_7", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hatsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hatsCode.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hatsCode.eventsList15(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 8;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hatsCode.GDcostObjects2, gdjs.hatsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_8", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hatsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hatsCode.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hatsCode.eventsList16(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 9;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hatsCode.GDcostObjects2, gdjs.hatsCode.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_9", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hatsCode.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hatsCode.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hatsCode.eventsList17(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.hatsCode.GDcostObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDcostObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects2[i].returnVariable(gdjs.hatsCode.GDcostObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects2[i].returnVariable(gdjs.hatsCode.GDcostObjects2[i].getVariables().getFromIndex(0)).setString("купить");
}
}}

}


};gdjs.hatsCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("buy"), gdjs.hatsCode.GDbuyObjects2);
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDbuyObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.hatsCode.GDcostObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hatsCode.GDcostObjects2[0].getVariables()).getFromIndex(0)));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hatsCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595951Objects2Objects = Hashtable.newFrom({"hat_1": gdjs.hatsCode.GDhat_95951Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595951Objects3Objects = Hashtable.newFrom({"hat_1": gdjs.hatsCode.GDhat_95951Objects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595951Objects2Objects = Hashtable.newFrom({"hat_1": gdjs.hatsCode.GDhat_95951Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hatsCode.GDhat_95951Objects2, gdjs.hatsCode.GDhat_95951Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595951Objects3Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].setString("100");
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].returnVariable(gdjs.hatsCode.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(100);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(1);
}}

}


{

/* Reuse gdjs.hatsCode.GDhat_95951Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595951Objects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}}

}


};gdjs.hatsCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_1"), gdjs.hatsCode.GDhat_95951Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595951Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hatsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDtext_9595pickObjects2[i].setString("корона");
}
}
{ //Subevents
gdjs.hatsCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595952Objects2Objects = Hashtable.newFrom({"hat_2": gdjs.hatsCode.GDhat_95952Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595952Objects3Objects = Hashtable.newFrom({"hat_2": gdjs.hatsCode.GDhat_95952Objects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595952Objects2Objects = Hashtable.newFrom({"hat_2": gdjs.hatsCode.GDhat_95952Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hatsCode.GDhat_95952Objects2, gdjs.hatsCode.GDhat_95952Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595952Objects3Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].setString("15");
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].returnVariable(gdjs.hatsCode.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(15);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(2);
}}

}


{

/* Reuse gdjs.hatsCode.GDhat_95952Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595952Objects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(2);
}}

}


};gdjs.hatsCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_2"), gdjs.hatsCode.GDhat_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595952Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hatsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDtext_9595pickObjects2[i].setString("крутые очки");
}
}
{ //Subevents
gdjs.hatsCode.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595953Objects2Objects = Hashtable.newFrom({"hat_3": gdjs.hatsCode.GDhat_95953Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595953Objects3Objects = Hashtable.newFrom({"hat_3": gdjs.hatsCode.GDhat_95953Objects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595953Objects2Objects = Hashtable.newFrom({"hat_3": gdjs.hatsCode.GDhat_95953Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hatsCode.GDhat_95953Objects2, gdjs.hatsCode.GDhat_95953Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595953Objects3Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].setString("30");
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].returnVariable(gdjs.hatsCode.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(30);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(3);
}}

}


{

/* Reuse gdjs.hatsCode.GDhat_95953Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595953Objects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}}

}


};gdjs.hatsCode.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_3"), gdjs.hatsCode.GDhat_95953Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595953Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hatsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDtext_9595pickObjects2[i].setString("фиолетовая шляпка");
}
}
{ //Subevents
gdjs.hatsCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595955Objects2Objects = Hashtable.newFrom({"hat_5": gdjs.hatsCode.GDhat_95955Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595955Objects3Objects = Hashtable.newFrom({"hat_5": gdjs.hatsCode.GDhat_95955Objects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595955Objects2Objects = Hashtable.newFrom({"hat_5": gdjs.hatsCode.GDhat_95955Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hatsCode.GDhat_95955Objects2, gdjs.hatsCode.GDhat_95955Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595955Objects3Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].setString("50");
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].returnVariable(gdjs.hatsCode.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(5);
}}

}


{

/* Reuse gdjs.hatsCode.GDhat_95955Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595955Objects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(5);
}}

}


};gdjs.hatsCode.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_5"), gdjs.hatsCode.GDhat_95955Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595955Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hatsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDtext_9595pickObjects2[i].setString("кепка");
}
}
{ //Subevents
gdjs.hatsCode.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595956Objects2Objects = Hashtable.newFrom({"hat_6": gdjs.hatsCode.GDhat_95956Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595956Objects3Objects = Hashtable.newFrom({"hat_6": gdjs.hatsCode.GDhat_95956Objects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595956Objects2Objects = Hashtable.newFrom({"hat_6": gdjs.hatsCode.GDhat_95956Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hatsCode.GDhat_95956Objects2, gdjs.hatsCode.GDhat_95956Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595956Objects3Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].setString("70");
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].returnVariable(gdjs.hatsCode.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(70);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(6);
}}

}


{

/* Reuse gdjs.hatsCode.GDhat_95956Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595956Objects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(6);
}}

}


};gdjs.hatsCode.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_6"), gdjs.hatsCode.GDhat_95956Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595956Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hatsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDtext_9595pickObjects2[i].setString("пропелер");
}
}
{ //Subevents
gdjs.hatsCode.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595957Objects2Objects = Hashtable.newFrom({"hat_7": gdjs.hatsCode.GDhat_95957Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595957Objects3Objects = Hashtable.newFrom({"hat_7": gdjs.hatsCode.GDhat_95957Objects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595957Objects2Objects = Hashtable.newFrom({"hat_7": gdjs.hatsCode.GDhat_95957Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hatsCode.GDhat_95957Objects2, gdjs.hatsCode.GDhat_95957Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595957Objects3Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].setString("25");
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].returnVariable(gdjs.hatsCode.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(25);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(7);
}}

}


{

/* Reuse gdjs.hatsCode.GDhat_95957Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595957Objects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(7);
}}

}


};gdjs.hatsCode.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_7"), gdjs.hatsCode.GDhat_95957Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595957Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hatsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDtext_9595pickObjects2[i].setString("клоунские очки");
}
}
{ //Subevents
gdjs.hatsCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595958Objects2Objects = Hashtable.newFrom({"hat_8": gdjs.hatsCode.GDhat_95958Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595958Objects3Objects = Hashtable.newFrom({"hat_8": gdjs.hatsCode.GDhat_95958Objects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595958Objects2Objects = Hashtable.newFrom({"hat_8": gdjs.hatsCode.GDhat_95958Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.eventsList32 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hatsCode.GDhat_95958Objects2, gdjs.hatsCode.GDhat_95958Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595958Objects3Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].setString("50");
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].returnVariable(gdjs.hatsCode.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(8);
}}

}


{

/* Reuse gdjs.hatsCode.GDhat_95958Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595958Objects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(8);
}}

}


};gdjs.hatsCode.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_8"), gdjs.hatsCode.GDhat_95958Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595958Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hatsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDtext_9595pickObjects2[i].setString("о повезло повезло");
}
}
{ //Subevents
gdjs.hatsCode.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595959Objects2Objects = Hashtable.newFrom({"hat_9": gdjs.hatsCode.GDhat_95959Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595959Objects3Objects = Hashtable.newFrom({"hat_9": gdjs.hatsCode.GDhat_95959Objects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects3});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595959Objects2Objects = Hashtable.newFrom({"hat_9": gdjs.hatsCode.GDhat_95959Objects2});
gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hatsCode.GDlockObjects2});
gdjs.hatsCode.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hatsCode.GDhat_95959Objects2, gdjs.hatsCode.GDhat_95959Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595959Objects3Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects3);
{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].setString("40");
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects3.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects3[i].returnVariable(gdjs.hatsCode.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(40);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(9);
}}

}


{

/* Reuse gdjs.hatsCode.GDhat_95959Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hatsCode.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595959Objects2Objects, gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(9);
}}

}


};gdjs.hatsCode.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_9"), gdjs.hatsCode.GDhat_95959Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595959Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hatsCode.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDtext_9595pickObjects2[i].setString("фермерская шапка");
}
}
{ //Subevents
gdjs.hatsCode.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_95959595dldoObjects1Objects = Hashtable.newFrom({"hat_dldo": gdjs.hatsCode.GDhat_9595dldoObjects1});
gdjs.hatsCode.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_0"), gdjs.hatsCode.GDhat_95950Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_959595950Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hatsCode.GDtext_9595pickObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{for(var i = 0, len = gdjs.hatsCode.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDtext_9595pickObjects2[i].setString("без шапки");
}
}}

}


{


gdjs.hatsCode.eventsList9(runtimeScene);
}


{


gdjs.hatsCode.eventsList19(runtimeScene);
}


{


gdjs.hatsCode.eventsList21(runtimeScene);
}


{


gdjs.hatsCode.eventsList23(runtimeScene);
}


{


gdjs.hatsCode.eventsList25(runtimeScene);
}


{


gdjs.hatsCode.eventsList27(runtimeScene);
}


{


gdjs.hatsCode.eventsList29(runtimeScene);
}


{


gdjs.hatsCode.eventsList31(runtimeScene);
}


{


gdjs.hatsCode.eventsList33(runtimeScene);
}


{


gdjs.hatsCode.eventsList35(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("hat_dldo"), gdjs.hatsCode.GDhat_9595dldoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hatsCode.mapOfGDgdjs_9546hatsCode_9546GDhat_95959595dldoObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hatsCode.GDtext_9595pickObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(4);
}{for(var i = 0, len = gdjs.hatsCode.GDtext_9595pickObjects1.length ;i < len;++i) {
    gdjs.hatsCode.GDtext_9595pickObjects1[i].setString("секретная шапка!");
}
}}

}


};gdjs.hatsCode.eventsList37 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67123180);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hatsCode.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.eventsList38 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_0"), gdjs.hatsCode.GDhat_95950Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hatsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDpickerObjects2[i].setPosition((( gdjs.hatsCode.GDhat_95950Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95950Objects2[0].getCenterXInScene()),(( gdjs.hatsCode.GDhat_95950Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95950Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_1"), gdjs.hatsCode.GDhat_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hatsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDpickerObjects2[i].setPosition((( gdjs.hatsCode.GDhat_95951Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95951Objects2[0].getCenterXInScene()),(( gdjs.hatsCode.GDhat_95951Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95951Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_2"), gdjs.hatsCode.GDhat_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hatsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDpickerObjects2[i].setPosition((( gdjs.hatsCode.GDhat_95952Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95952Objects2[0].getCenterXInScene()),(( gdjs.hatsCode.GDhat_95952Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95952Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_3"), gdjs.hatsCode.GDhat_95953Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hatsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDpickerObjects2[i].setPosition((( gdjs.hatsCode.GDhat_95953Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95953Objects2[0].getCenterXInScene()),(( gdjs.hatsCode.GDhat_95953Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95953Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_5"), gdjs.hatsCode.GDhat_95955Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hatsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDpickerObjects2[i].setPosition((( gdjs.hatsCode.GDhat_95955Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95955Objects2[0].getCenterXInScene()),(( gdjs.hatsCode.GDhat_95955Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95955Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hatsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDpickerObjects2[i].setPosition(999,999);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 6;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_6"), gdjs.hatsCode.GDhat_95956Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hatsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDpickerObjects2[i].setPosition((( gdjs.hatsCode.GDhat_95956Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95956Objects2[0].getCenterXInScene()),(( gdjs.hatsCode.GDhat_95956Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95956Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 7;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_7"), gdjs.hatsCode.GDhat_95957Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hatsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDpickerObjects2[i].setPosition((( gdjs.hatsCode.GDhat_95957Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95957Objects2[0].getCenterXInScene()),(( gdjs.hatsCode.GDhat_95957Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95957Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 8;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_8"), gdjs.hatsCode.GDhat_95958Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hatsCode.GDpickerObjects2);
{for(var i = 0, len = gdjs.hatsCode.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDpickerObjects2[i].setPosition((( gdjs.hatsCode.GDhat_95958Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95958Objects2[0].getCenterXInScene()),(( gdjs.hatsCode.GDhat_95958Objects2.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95958Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 9;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_9"), gdjs.hatsCode.GDhat_95959Objects1);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hatsCode.GDpickerObjects1);
{for(var i = 0, len = gdjs.hatsCode.GDpickerObjects1.length ;i < len;++i) {
    gdjs.hatsCode.GDpickerObjects1[i].setPosition((( gdjs.hatsCode.GDhat_95959Objects1.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95959Objects1[0].getCenterXInScene()),(( gdjs.hatsCode.GDhat_95959Objects1.length === 0 ) ? 0 :gdjs.hatsCode.GDhat_95959Objects1[0].getCenterYInScene()));
}
}}

}


};gdjs.hatsCode.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67166828);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hatsCode.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.hatsCode.eventsList40 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hatsCode.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hatsCode.GDbackObjects2.length;i<l;++i) {
    if ( gdjs.hatsCode.GDbackObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hatsCode.GDbackObjects2[k] = gdjs.hatsCode.GDbackObjects2[i];
        ++k;
    }
}
gdjs.hatsCode.GDbackObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67173924);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDbackObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDbackObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDbackObjects2[i].setAnimationName("back");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hatsCode.GDr_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hatsCode.GDr_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.hatsCode.GDr_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hatsCode.GDr_9595buttonObjects2[k] = gdjs.hatsCode.GDr_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.hatsCode.GDr_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67174788);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDr_9595buttonObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDr_9595buttonObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDr_9595buttonObjects2[i].setAnimationName("r_button");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hatsCode.GDl_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hatsCode.GDl_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.hatsCode.GDl_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hatsCode.GDl_9595buttonObjects2[k] = gdjs.hatsCode.GDl_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.hatsCode.GDl_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67175492);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hatsCode.GDl_9595buttonObjects2 */
{for(var i = 0, len = gdjs.hatsCode.GDl_9595buttonObjects2.length ;i < len;++i) {
    gdjs.hatsCode.GDl_9595buttonObjects2[i].setAnimationName("l_button");
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.hatsCode.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hatsCode.GDcoins2Objects1);
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hatsCode.GDcostObjects1);
{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "coin", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{for(var i = 0, len = gdjs.hatsCode.GDcoins2Objects1.length ;i < len;++i) {
    gdjs.hatsCode.GDcoins2Objects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}{for(var i = 0, len = gdjs.hatsCode.GDcostObjects1.length ;i < len;++i) {
    gdjs.hatsCode.GDcostObjects1[i].returnVariable(gdjs.hatsCode.GDcostObjects1[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "hat", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
{ //Subevents
gdjs.hatsCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.hatsCode.eventsList2(runtimeScene);
}


{


gdjs.hatsCode.eventsList4(runtimeScene);
}


{


gdjs.hatsCode.eventsList8(runtimeScene);
}


{


gdjs.hatsCode.eventsList37(runtimeScene);
}


{



}


{


gdjs.hatsCode.eventsList39(runtimeScene);
}


{


gdjs.hatsCode.eventsList40(runtimeScene);
}


};

gdjs.hatsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.hatsCode.GDhat_95950Objects1.length = 0;
gdjs.hatsCode.GDhat_95950Objects2.length = 0;
gdjs.hatsCode.GDhat_95950Objects3.length = 0;
gdjs.hatsCode.GDhat_95950Objects4.length = 0;
gdjs.hatsCode.GDhat_95951Objects1.length = 0;
gdjs.hatsCode.GDhat_95951Objects2.length = 0;
gdjs.hatsCode.GDhat_95951Objects3.length = 0;
gdjs.hatsCode.GDhat_95951Objects4.length = 0;
gdjs.hatsCode.GDhat_95952Objects1.length = 0;
gdjs.hatsCode.GDhat_95952Objects2.length = 0;
gdjs.hatsCode.GDhat_95952Objects3.length = 0;
gdjs.hatsCode.GDhat_95952Objects4.length = 0;
gdjs.hatsCode.GDhat_95953Objects1.length = 0;
gdjs.hatsCode.GDhat_95953Objects2.length = 0;
gdjs.hatsCode.GDhat_95953Objects3.length = 0;
gdjs.hatsCode.GDhat_95953Objects4.length = 0;
gdjs.hatsCode.GDhat_95954Objects1.length = 0;
gdjs.hatsCode.GDhat_95954Objects2.length = 0;
gdjs.hatsCode.GDhat_95954Objects3.length = 0;
gdjs.hatsCode.GDhat_95954Objects4.length = 0;
gdjs.hatsCode.GDhat_95955Objects1.length = 0;
gdjs.hatsCode.GDhat_95955Objects2.length = 0;
gdjs.hatsCode.GDhat_95955Objects3.length = 0;
gdjs.hatsCode.GDhat_95955Objects4.length = 0;
gdjs.hatsCode.GDhat_95956Objects1.length = 0;
gdjs.hatsCode.GDhat_95956Objects2.length = 0;
gdjs.hatsCode.GDhat_95956Objects3.length = 0;
gdjs.hatsCode.GDhat_95956Objects4.length = 0;
gdjs.hatsCode.GDhat_95957Objects1.length = 0;
gdjs.hatsCode.GDhat_95957Objects2.length = 0;
gdjs.hatsCode.GDhat_95957Objects3.length = 0;
gdjs.hatsCode.GDhat_95957Objects4.length = 0;
gdjs.hatsCode.GDhat_95958Objects1.length = 0;
gdjs.hatsCode.GDhat_95958Objects2.length = 0;
gdjs.hatsCode.GDhat_95958Objects3.length = 0;
gdjs.hatsCode.GDhat_95958Objects4.length = 0;
gdjs.hatsCode.GDhat_95959Objects1.length = 0;
gdjs.hatsCode.GDhat_95959Objects2.length = 0;
gdjs.hatsCode.GDhat_95959Objects3.length = 0;
gdjs.hatsCode.GDhat_95959Objects4.length = 0;
gdjs.hatsCode.GDhat_9595randomObjects1.length = 0;
gdjs.hatsCode.GDhat_9595randomObjects2.length = 0;
gdjs.hatsCode.GDhat_9595randomObjects3.length = 0;
gdjs.hatsCode.GDhat_9595randomObjects4.length = 0;
gdjs.hatsCode.GDhat_9595dldoObjects1.length = 0;
gdjs.hatsCode.GDhat_9595dldoObjects2.length = 0;
gdjs.hatsCode.GDhat_9595dldoObjects3.length = 0;
gdjs.hatsCode.GDhat_9595dldoObjects4.length = 0;
gdjs.hatsCode.GDtext_9595pickObjects1.length = 0;
gdjs.hatsCode.GDtext_9595pickObjects2.length = 0;
gdjs.hatsCode.GDtext_9595pickObjects3.length = 0;
gdjs.hatsCode.GDtext_9595pickObjects4.length = 0;
gdjs.hatsCode.GDbuyObjects1.length = 0;
gdjs.hatsCode.GDbuyObjects2.length = 0;
gdjs.hatsCode.GDbuyObjects3.length = 0;
gdjs.hatsCode.GDbuyObjects4.length = 0;
gdjs.hatsCode.GDcostObjects1.length = 0;
gdjs.hatsCode.GDcostObjects2.length = 0;
gdjs.hatsCode.GDcostObjects3.length = 0;
gdjs.hatsCode.GDcostObjects4.length = 0;
gdjs.hatsCode.GDpickerObjects1.length = 0;
gdjs.hatsCode.GDpickerObjects2.length = 0;
gdjs.hatsCode.GDpickerObjects3.length = 0;
gdjs.hatsCode.GDpickerObjects4.length = 0;
gdjs.hatsCode.GDcoin_9595marker_9595hatsObjects1.length = 0;
gdjs.hatsCode.GDcoin_9595marker_9595hatsObjects2.length = 0;
gdjs.hatsCode.GDcoin_9595marker_9595hatsObjects3.length = 0;
gdjs.hatsCode.GDcoin_9595marker_9595hatsObjects4.length = 0;
gdjs.hatsCode.GDgrass_9595blockObjects1.length = 0;
gdjs.hatsCode.GDgrass_9595blockObjects2.length = 0;
gdjs.hatsCode.GDgrass_9595blockObjects3.length = 0;
gdjs.hatsCode.GDgrass_9595blockObjects4.length = 0;
gdjs.hatsCode.GDblockObjects1.length = 0;
gdjs.hatsCode.GDblockObjects2.length = 0;
gdjs.hatsCode.GDblockObjects3.length = 0;
gdjs.hatsCode.GDblockObjects4.length = 0;
gdjs.hatsCode.GDmenuObjects1.length = 0;
gdjs.hatsCode.GDmenuObjects2.length = 0;
gdjs.hatsCode.GDmenuObjects3.length = 0;
gdjs.hatsCode.GDmenuObjects4.length = 0;
gdjs.hatsCode.GDhomeObjects1.length = 0;
gdjs.hatsCode.GDhomeObjects2.length = 0;
gdjs.hatsCode.GDhomeObjects3.length = 0;
gdjs.hatsCode.GDhomeObjects4.length = 0;
gdjs.hatsCode.GDresetObjects1.length = 0;
gdjs.hatsCode.GDresetObjects2.length = 0;
gdjs.hatsCode.GDresetObjects3.length = 0;
gdjs.hatsCode.GDresetObjects4.length = 0;
gdjs.hatsCode.GDspikeObjects1.length = 0;
gdjs.hatsCode.GDspikeObjects2.length = 0;
gdjs.hatsCode.GDspikeObjects3.length = 0;
gdjs.hatsCode.GDspikeObjects4.length = 0;
gdjs.hatsCode.GDend_9595homeObjects1.length = 0;
gdjs.hatsCode.GDend_9595homeObjects2.length = 0;
gdjs.hatsCode.GDend_9595homeObjects3.length = 0;
gdjs.hatsCode.GDend_9595homeObjects4.length = 0;
gdjs.hatsCode.GDend_9595resetObjects1.length = 0;
gdjs.hatsCode.GDend_9595resetObjects2.length = 0;
gdjs.hatsCode.GDend_9595resetObjects3.length = 0;
gdjs.hatsCode.GDend_9595resetObjects4.length = 0;
gdjs.hatsCode.GDrobot_9595enemyObjects1.length = 0;
gdjs.hatsCode.GDrobot_9595enemyObjects2.length = 0;
gdjs.hatsCode.GDrobot_9595enemyObjects3.length = 0;
gdjs.hatsCode.GDrobot_9595enemyObjects4.length = 0;
gdjs.hatsCode.GDslime_9595enemyObjects1.length = 0;
gdjs.hatsCode.GDslime_9595enemyObjects2.length = 0;
gdjs.hatsCode.GDslime_9595enemyObjects3.length = 0;
gdjs.hatsCode.GDslime_9595enemyObjects4.length = 0;
gdjs.hatsCode.GDrob_9595enemy_9595rightObjects1.length = 0;
gdjs.hatsCode.GDrob_9595enemy_9595rightObjects2.length = 0;
gdjs.hatsCode.GDrob_9595enemy_9595rightObjects3.length = 0;
gdjs.hatsCode.GDrob_9595enemy_9595rightObjects4.length = 0;
gdjs.hatsCode.GDrob_9595enemy_9595leftObjects1.length = 0;
gdjs.hatsCode.GDrob_9595enemy_9595leftObjects2.length = 0;
gdjs.hatsCode.GDrob_9595enemy_9595leftObjects3.length = 0;
gdjs.hatsCode.GDrob_9595enemy_9595leftObjects4.length = 0;
gdjs.hatsCode.GDheroObjects1.length = 0;
gdjs.hatsCode.GDheroObjects2.length = 0;
gdjs.hatsCode.GDheroObjects3.length = 0;
gdjs.hatsCode.GDheroObjects4.length = 0;
gdjs.hatsCode.GDsawObjects1.length = 0;
gdjs.hatsCode.GDsawObjects2.length = 0;
gdjs.hatsCode.GDsawObjects3.length = 0;
gdjs.hatsCode.GDsawObjects4.length = 0;
gdjs.hatsCode.GDcoin_9595markerObjects1.length = 0;
gdjs.hatsCode.GDcoin_9595markerObjects2.length = 0;
gdjs.hatsCode.GDcoin_9595markerObjects3.length = 0;
gdjs.hatsCode.GDcoin_9595markerObjects4.length = 0;
gdjs.hatsCode.GDcoin_9595marker2Objects1.length = 0;
gdjs.hatsCode.GDcoin_9595marker2Objects2.length = 0;
gdjs.hatsCode.GDcoin_9595marker2Objects3.length = 0;
gdjs.hatsCode.GDcoin_9595marker2Objects4.length = 0;
gdjs.hatsCode.GDcoinsObjects1.length = 0;
gdjs.hatsCode.GDcoinsObjects2.length = 0;
gdjs.hatsCode.GDcoinsObjects3.length = 0;
gdjs.hatsCode.GDcoinsObjects4.length = 0;
gdjs.hatsCode.GDcoins2Objects1.length = 0;
gdjs.hatsCode.GDcoins2Objects2.length = 0;
gdjs.hatsCode.GDcoins2Objects3.length = 0;
gdjs.hatsCode.GDcoins2Objects4.length = 0;
gdjs.hatsCode.GDkey_9595lockerObjects1.length = 0;
gdjs.hatsCode.GDkey_9595lockerObjects2.length = 0;
gdjs.hatsCode.GDkey_9595lockerObjects3.length = 0;
gdjs.hatsCode.GDkey_9595lockerObjects4.length = 0;
gdjs.hatsCode.GDr_9595buttonObjects1.length = 0;
gdjs.hatsCode.GDr_9595buttonObjects2.length = 0;
gdjs.hatsCode.GDr_9595buttonObjects3.length = 0;
gdjs.hatsCode.GDr_9595buttonObjects4.length = 0;
gdjs.hatsCode.GDl_9595buttonObjects1.length = 0;
gdjs.hatsCode.GDl_9595buttonObjects2.length = 0;
gdjs.hatsCode.GDl_9595buttonObjects3.length = 0;
gdjs.hatsCode.GDl_9595buttonObjects4.length = 0;
gdjs.hatsCode.GDbackObjects1.length = 0;
gdjs.hatsCode.GDbackObjects2.length = 0;
gdjs.hatsCode.GDbackObjects3.length = 0;
gdjs.hatsCode.GDbackObjects4.length = 0;
gdjs.hatsCode.GDlockObjects1.length = 0;
gdjs.hatsCode.GDlockObjects2.length = 0;
gdjs.hatsCode.GDlockObjects3.length = 0;
gdjs.hatsCode.GDlockObjects4.length = 0;
gdjs.hatsCode.GDcamObjects1.length = 0;
gdjs.hatsCode.GDcamObjects2.length = 0;
gdjs.hatsCode.GDcamObjects3.length = 0;
gdjs.hatsCode.GDcamObjects4.length = 0;
gdjs.hatsCode.GDfonikObjects1.length = 0;
gdjs.hatsCode.GDfonikObjects2.length = 0;
gdjs.hatsCode.GDfonikObjects3.length = 0;
gdjs.hatsCode.GDfonikObjects4.length = 0;

gdjs.hatsCode.eventsList41(runtimeScene);

return;

}

gdjs['hatsCode'] = gdjs.hatsCode;
