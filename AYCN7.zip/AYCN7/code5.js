gdjs.hats2Code = {};
gdjs.hats2Code.GDbackObjects2_1final = [];

gdjs.hats2Code.GDl_9595buttonObjects2_1final = [];

gdjs.hats2Code.GDr_9595buttonObjects2_1final = [];

gdjs.hats2Code.GDhat_95950Objects1= [];
gdjs.hats2Code.GDhat_95950Objects2= [];
gdjs.hats2Code.GDhat_95950Objects3= [];
gdjs.hats2Code.GDhat_95950Objects4= [];
gdjs.hats2Code.GDhat_95951Objects1= [];
gdjs.hats2Code.GDhat_95951Objects2= [];
gdjs.hats2Code.GDhat_95951Objects3= [];
gdjs.hats2Code.GDhat_95951Objects4= [];
gdjs.hats2Code.GDhat_95952Objects1= [];
gdjs.hats2Code.GDhat_95952Objects2= [];
gdjs.hats2Code.GDhat_95952Objects3= [];
gdjs.hats2Code.GDhat_95952Objects4= [];
gdjs.hats2Code.GDhat_95953Objects1= [];
gdjs.hats2Code.GDhat_95953Objects2= [];
gdjs.hats2Code.GDhat_95953Objects3= [];
gdjs.hats2Code.GDhat_95953Objects4= [];
gdjs.hats2Code.GDhat_95954Objects1= [];
gdjs.hats2Code.GDhat_95954Objects2= [];
gdjs.hats2Code.GDhat_95954Objects3= [];
gdjs.hats2Code.GDhat_95954Objects4= [];
gdjs.hats2Code.GDhat_95955Objects1= [];
gdjs.hats2Code.GDhat_95955Objects2= [];
gdjs.hats2Code.GDhat_95955Objects3= [];
gdjs.hats2Code.GDhat_95955Objects4= [];
gdjs.hats2Code.GDhat_95956Objects1= [];
gdjs.hats2Code.GDhat_95956Objects2= [];
gdjs.hats2Code.GDhat_95956Objects3= [];
gdjs.hats2Code.GDhat_95956Objects4= [];
gdjs.hats2Code.GDhat_95957Objects1= [];
gdjs.hats2Code.GDhat_95957Objects2= [];
gdjs.hats2Code.GDhat_95957Objects3= [];
gdjs.hats2Code.GDhat_95957Objects4= [];
gdjs.hats2Code.GDhat_95958Objects1= [];
gdjs.hats2Code.GDhat_95958Objects2= [];
gdjs.hats2Code.GDhat_95958Objects3= [];
gdjs.hats2Code.GDhat_95958Objects4= [];
gdjs.hats2Code.GDhat_95959Objects1= [];
gdjs.hats2Code.GDhat_95959Objects2= [];
gdjs.hats2Code.GDhat_95959Objects3= [];
gdjs.hats2Code.GDhat_95959Objects4= [];
gdjs.hats2Code.GDhat_959510Objects1= [];
gdjs.hats2Code.GDhat_959510Objects2= [];
gdjs.hats2Code.GDhat_959510Objects3= [];
gdjs.hats2Code.GDhat_959510Objects4= [];
gdjs.hats2Code.GDhat_959511Objects1= [];
gdjs.hats2Code.GDhat_959511Objects2= [];
gdjs.hats2Code.GDhat_959511Objects3= [];
gdjs.hats2Code.GDhat_959511Objects4= [];
gdjs.hats2Code.GDhat_959512Objects1= [];
gdjs.hats2Code.GDhat_959512Objects2= [];
gdjs.hats2Code.GDhat_959512Objects3= [];
gdjs.hats2Code.GDhat_959512Objects4= [];
gdjs.hats2Code.GDhat_959513Objects1= [];
gdjs.hats2Code.GDhat_959513Objects2= [];
gdjs.hats2Code.GDhat_959513Objects3= [];
gdjs.hats2Code.GDhat_959513Objects4= [];
gdjs.hats2Code.GDhat_959514Objects1= [];
gdjs.hats2Code.GDhat_959514Objects2= [];
gdjs.hats2Code.GDhat_959514Objects3= [];
gdjs.hats2Code.GDhat_959514Objects4= [];
gdjs.hats2Code.GDhat_959515Objects1= [];
gdjs.hats2Code.GDhat_959515Objects2= [];
gdjs.hats2Code.GDhat_959515Objects3= [];
gdjs.hats2Code.GDhat_959515Objects4= [];
gdjs.hats2Code.GDhat_959516Objects1= [];
gdjs.hats2Code.GDhat_959516Objects2= [];
gdjs.hats2Code.GDhat_959516Objects3= [];
gdjs.hats2Code.GDhat_959516Objects4= [];
gdjs.hats2Code.GDhat_959517Objects1= [];
gdjs.hats2Code.GDhat_959517Objects2= [];
gdjs.hats2Code.GDhat_959517Objects3= [];
gdjs.hats2Code.GDhat_959517Objects4= [];
gdjs.hats2Code.GDhat_959518Objects1= [];
gdjs.hats2Code.GDhat_959518Objects2= [];
gdjs.hats2Code.GDhat_959518Objects3= [];
gdjs.hats2Code.GDhat_959518Objects4= [];
gdjs.hats2Code.GDhat_9595randomObjects1= [];
gdjs.hats2Code.GDhat_9595randomObjects2= [];
gdjs.hats2Code.GDhat_9595randomObjects3= [];
gdjs.hats2Code.GDhat_9595randomObjects4= [];
gdjs.hats2Code.GDhat_9595dldoObjects1= [];
gdjs.hats2Code.GDhat_9595dldoObjects2= [];
gdjs.hats2Code.GDhat_9595dldoObjects3= [];
gdjs.hats2Code.GDhat_9595dldoObjects4= [];
gdjs.hats2Code.GDtext_9595pickObjects1= [];
gdjs.hats2Code.GDtext_9595pickObjects2= [];
gdjs.hats2Code.GDtext_9595pickObjects3= [];
gdjs.hats2Code.GDtext_9595pickObjects4= [];
gdjs.hats2Code.GDbuyObjects1= [];
gdjs.hats2Code.GDbuyObjects2= [];
gdjs.hats2Code.GDbuyObjects3= [];
gdjs.hats2Code.GDbuyObjects4= [];
gdjs.hats2Code.GDcostObjects1= [];
gdjs.hats2Code.GDcostObjects2= [];
gdjs.hats2Code.GDcostObjects3= [];
gdjs.hats2Code.GDcostObjects4= [];
gdjs.hats2Code.GDpickerObjects1= [];
gdjs.hats2Code.GDpickerObjects2= [];
gdjs.hats2Code.GDpickerObjects3= [];
gdjs.hats2Code.GDpickerObjects4= [];
gdjs.hats2Code.GDcoin_9595marker_9595hatsObjects1= [];
gdjs.hats2Code.GDcoin_9595marker_9595hatsObjects2= [];
gdjs.hats2Code.GDcoin_9595marker_9595hatsObjects3= [];
gdjs.hats2Code.GDcoin_9595marker_9595hatsObjects4= [];
gdjs.hats2Code.GDgrass_9595blockObjects1= [];
gdjs.hats2Code.GDgrass_9595blockObjects2= [];
gdjs.hats2Code.GDgrass_9595blockObjects3= [];
gdjs.hats2Code.GDgrass_9595blockObjects4= [];
gdjs.hats2Code.GDblockObjects1= [];
gdjs.hats2Code.GDblockObjects2= [];
gdjs.hats2Code.GDblockObjects3= [];
gdjs.hats2Code.GDblockObjects4= [];
gdjs.hats2Code.GDmenuObjects1= [];
gdjs.hats2Code.GDmenuObjects2= [];
gdjs.hats2Code.GDmenuObjects3= [];
gdjs.hats2Code.GDmenuObjects4= [];
gdjs.hats2Code.GDhomeObjects1= [];
gdjs.hats2Code.GDhomeObjects2= [];
gdjs.hats2Code.GDhomeObjects3= [];
gdjs.hats2Code.GDhomeObjects4= [];
gdjs.hats2Code.GDresetObjects1= [];
gdjs.hats2Code.GDresetObjects2= [];
gdjs.hats2Code.GDresetObjects3= [];
gdjs.hats2Code.GDresetObjects4= [];
gdjs.hats2Code.GDspikeObjects1= [];
gdjs.hats2Code.GDspikeObjects2= [];
gdjs.hats2Code.GDspikeObjects3= [];
gdjs.hats2Code.GDspikeObjects4= [];
gdjs.hats2Code.GDend_9595homeObjects1= [];
gdjs.hats2Code.GDend_9595homeObjects2= [];
gdjs.hats2Code.GDend_9595homeObjects3= [];
gdjs.hats2Code.GDend_9595homeObjects4= [];
gdjs.hats2Code.GDend_9595resetObjects1= [];
gdjs.hats2Code.GDend_9595resetObjects2= [];
gdjs.hats2Code.GDend_9595resetObjects3= [];
gdjs.hats2Code.GDend_9595resetObjects4= [];
gdjs.hats2Code.GDrobot_9595enemyObjects1= [];
gdjs.hats2Code.GDrobot_9595enemyObjects2= [];
gdjs.hats2Code.GDrobot_9595enemyObjects3= [];
gdjs.hats2Code.GDrobot_9595enemyObjects4= [];
gdjs.hats2Code.GDslime_9595enemyObjects1= [];
gdjs.hats2Code.GDslime_9595enemyObjects2= [];
gdjs.hats2Code.GDslime_9595enemyObjects3= [];
gdjs.hats2Code.GDslime_9595enemyObjects4= [];
gdjs.hats2Code.GDrob_9595enemy_9595rightObjects1= [];
gdjs.hats2Code.GDrob_9595enemy_9595rightObjects2= [];
gdjs.hats2Code.GDrob_9595enemy_9595rightObjects3= [];
gdjs.hats2Code.GDrob_9595enemy_9595rightObjects4= [];
gdjs.hats2Code.GDrob_9595enemy_9595leftObjects1= [];
gdjs.hats2Code.GDrob_9595enemy_9595leftObjects2= [];
gdjs.hats2Code.GDrob_9595enemy_9595leftObjects3= [];
gdjs.hats2Code.GDrob_9595enemy_9595leftObjects4= [];
gdjs.hats2Code.GDheroObjects1= [];
gdjs.hats2Code.GDheroObjects2= [];
gdjs.hats2Code.GDheroObjects3= [];
gdjs.hats2Code.GDheroObjects4= [];
gdjs.hats2Code.GDsawObjects1= [];
gdjs.hats2Code.GDsawObjects2= [];
gdjs.hats2Code.GDsawObjects3= [];
gdjs.hats2Code.GDsawObjects4= [];
gdjs.hats2Code.GDcoin_9595markerObjects1= [];
gdjs.hats2Code.GDcoin_9595markerObjects2= [];
gdjs.hats2Code.GDcoin_9595markerObjects3= [];
gdjs.hats2Code.GDcoin_9595markerObjects4= [];
gdjs.hats2Code.GDcoin_9595marker2Objects1= [];
gdjs.hats2Code.GDcoin_9595marker2Objects2= [];
gdjs.hats2Code.GDcoin_9595marker2Objects3= [];
gdjs.hats2Code.GDcoin_9595marker2Objects4= [];
gdjs.hats2Code.GDcoinsObjects1= [];
gdjs.hats2Code.GDcoinsObjects2= [];
gdjs.hats2Code.GDcoinsObjects3= [];
gdjs.hats2Code.GDcoinsObjects4= [];
gdjs.hats2Code.GDcoins2Objects1= [];
gdjs.hats2Code.GDcoins2Objects2= [];
gdjs.hats2Code.GDcoins2Objects3= [];
gdjs.hats2Code.GDcoins2Objects4= [];
gdjs.hats2Code.GDkey_9595lockerObjects1= [];
gdjs.hats2Code.GDkey_9595lockerObjects2= [];
gdjs.hats2Code.GDkey_9595lockerObjects3= [];
gdjs.hats2Code.GDkey_9595lockerObjects4= [];
gdjs.hats2Code.GDr_9595buttonObjects1= [];
gdjs.hats2Code.GDr_9595buttonObjects2= [];
gdjs.hats2Code.GDr_9595buttonObjects3= [];
gdjs.hats2Code.GDr_9595buttonObjects4= [];
gdjs.hats2Code.GDl_9595buttonObjects1= [];
gdjs.hats2Code.GDl_9595buttonObjects2= [];
gdjs.hats2Code.GDl_9595buttonObjects3= [];
gdjs.hats2Code.GDl_9595buttonObjects4= [];
gdjs.hats2Code.GDbackObjects1= [];
gdjs.hats2Code.GDbackObjects2= [];
gdjs.hats2Code.GDbackObjects3= [];
gdjs.hats2Code.GDbackObjects4= [];
gdjs.hats2Code.GDlockObjects1= [];
gdjs.hats2Code.GDlockObjects2= [];
gdjs.hats2Code.GDlockObjects3= [];
gdjs.hats2Code.GDlockObjects4= [];
gdjs.hats2Code.GDcamObjects1= [];
gdjs.hats2Code.GDcamObjects2= [];
gdjs.hats2Code.GDcamObjects3= [];
gdjs.hats2Code.GDcamObjects4= [];
gdjs.hats2Code.GDfonikObjects1= [];
gdjs.hats2Code.GDfonikObjects2= [];
gdjs.hats2Code.GDfonikObjects3= [];
gdjs.hats2Code.GDfonikObjects4= [];


gdjs.hats2Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cam"), gdjs.hats2Code.GDcamObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.hats2Code.GDcamObjects1.length !== 0 ? gdjs.hats2Code.GDcamObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.hats2Code.GDcamObjects1.length ;i < len;++i) {
    gdjs.hats2Code.GDcamObjects1[i].hide();
}
}}

}


};gdjs.hats2Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.hats2Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}
{ //Subevents
gdjs.hats2Code.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDbackObjects2Objects = Hashtable.newFrom({"back": gdjs.hats2Code.GDbackObjects2});
gdjs.hats2Code.asyncCallback67230412 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}
gdjs.hats2Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.hats2Code.asyncCallback67230412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDl_95959595buttonObjects2Objects = Hashtable.newFrom({"l_button": gdjs.hats2Code.GDl_9595buttonObjects2});
gdjs.hats2Code.asyncCallback67231684 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats", false);
}}
gdjs.hats2Code.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.hats2Code.asyncCallback67231684(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDbackObjects3Objects = Hashtable.newFrom({"back": gdjs.hats2Code.GDbackObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDr_95959595buttonObjects3Objects = Hashtable.newFrom({"r_button": gdjs.hats2Code.GDr_9595buttonObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDl_95959595buttonObjects3Objects = Hashtable.newFrom({"l_button": gdjs.hats2Code.GDl_9595buttonObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDr_95959595buttonObjects1Objects = Hashtable.newFrom({"r_button": gdjs.hats2Code.GDr_9595buttonObjects1});
gdjs.hats2Code.asyncCallback67235580 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats3", false);
}}
gdjs.hats2Code.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.hats2Code.asyncCallback67235580(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hats2Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hats2Code.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDbackObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats2Code.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hats2Code.GDl_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDl_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats2Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.hats2Code.GDbackObjects2.length = 0;

gdjs.hats2Code.GDl_9595buttonObjects2.length = 0;

gdjs.hats2Code.GDr_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.hats2Code.GDbackObjects2_1final.length = 0;
gdjs.hats2Code.GDl_9595buttonObjects2_1final.length = 0;
gdjs.hats2Code.GDr_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hats2Code.GDbackObjects3);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDbackObjects3Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hats2Code.GDbackObjects3.length; j < jLen ; ++j) {
        if ( gdjs.hats2Code.GDbackObjects2_1final.indexOf(gdjs.hats2Code.GDbackObjects3[j]) === -1 )
            gdjs.hats2Code.GDbackObjects2_1final.push(gdjs.hats2Code.GDbackObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hats2Code.GDr_9595buttonObjects3);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDr_95959595buttonObjects3Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hats2Code.GDr_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.hats2Code.GDr_9595buttonObjects2_1final.indexOf(gdjs.hats2Code.GDr_9595buttonObjects3[j]) === -1 )
            gdjs.hats2Code.GDr_9595buttonObjects2_1final.push(gdjs.hats2Code.GDr_9595buttonObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hats2Code.GDl_9595buttonObjects3);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDl_95959595buttonObjects3Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hats2Code.GDl_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.hats2Code.GDl_9595buttonObjects2_1final.indexOf(gdjs.hats2Code.GDl_9595buttonObjects3[j]) === -1 )
            gdjs.hats2Code.GDl_9595buttonObjects2_1final.push(gdjs.hats2Code.GDl_9595buttonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.hats2Code.GDbackObjects2_1final, gdjs.hats2Code.GDbackObjects2);
gdjs.copyArray(gdjs.hats2Code.GDl_9595buttonObjects2_1final, gdjs.hats2Code.GDl_9595buttonObjects2);
gdjs.copyArray(gdjs.hats2Code.GDr_9595buttonObjects2_1final, gdjs.hats2Code.GDr_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{

gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hats2Code.GDr_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDr_95959595buttonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats2Code.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67229660);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats2Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959510Objects2Objects = Hashtable.newFrom({"hat_10": gdjs.hats2Code.GDhat_959510Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959511Objects2Objects = Hashtable.newFrom({"hat_11": gdjs.hats2Code.GDhat_959511Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959512Objects2Objects = Hashtable.newFrom({"hat_12": gdjs.hats2Code.GDhat_959512Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959513Objects2Objects = Hashtable.newFrom({"hat_13": gdjs.hats2Code.GDhat_959513Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959514Objects2Objects = Hashtable.newFrom({"hat_14": gdjs.hats2Code.GDhat_959514Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959515Objects2Objects = Hashtable.newFrom({"hat_15": gdjs.hats2Code.GDhat_959515Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959516Objects2Objects = Hashtable.newFrom({"hat_16": gdjs.hats2Code.GDhat_959516Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959517Objects2Objects = Hashtable.newFrom({"hat_17": gdjs.hats2Code.GDhat_959517Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects1Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects1});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959518Objects1Objects = Hashtable.newFrom({"hat_18": gdjs.hats2Code.GDhat_959518Objects1});
gdjs.hats2Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_10"), gdjs.hats2Code.GDhat_959510Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959510Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_10");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_11"), gdjs.hats2Code.GDhat_959511Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959511Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_11");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_12"), gdjs.hats2Code.GDhat_959512Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959512Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_12");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_13"), gdjs.hats2Code.GDhat_959513Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959513Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_13");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_14"), gdjs.hats2Code.GDhat_959514Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959514Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_14");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_15"), gdjs.hats2Code.GDhat_959515Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959515Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_15");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_16"), gdjs.hats2Code.GDhat_959516Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959516Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_16");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_17"), gdjs.hats2Code.GDhat_959517Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959517Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_17");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_18"), gdjs.hats2Code.GDhat_959518Objects1);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects1Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959518Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_18");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDlockObjects1 */
{for(var i = 0, len = gdjs.hats2Code.GDlockObjects1.length ;i < len;++i) {
    gdjs.hats2Code.GDlockObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.hats2Code.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats2Code.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDbuyObjects2Objects = Hashtable.newFrom({"buy": gdjs.hats2Code.GDbuyObjects2});
gdjs.hats2Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("key_locker"), gdjs.hats2Code.GDkey_9595lockerObjects3);
/* Reuse gdjs.hats2Code.GDlockObjects3 */
{for(var i = 0, len = gdjs.hats2Code.GDkey_9595lockerObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDkey_9595lockerObjects3[i].setPosition((( gdjs.hats2Code.GDlockObjects3.length === 0 ) ? 0 :gdjs.hats2Code.GDlockObjects3[0].getCenterXInScene()),(( gdjs.hats2Code.GDlockObjects3.length === 0 ) ? 0 :gdjs.hats2Code.GDlockObjects3[0].getCenterYInScene()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("buy"), gdjs.hats2Code.GDbuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDbuyObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects2);
gdjs.copyArray(runtimeScene.getObjects("key_locker"), gdjs.hats2Code.GDkey_9595lockerObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDkey_9595lockerObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDkey_9595lockerObjects2[i].setPosition(999,-(999));
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects2[i].setString("...");
}
}}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDbuyObjects2Objects = Hashtable.newFrom({"buy": gdjs.hats2Code.GDbuyObjects2});
gdjs.hats2Code.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats2Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats2Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats2Code.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats2Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats2Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats2Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats2Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats2Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats2Code.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats2Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats2Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats2Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats2Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats2Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats2Code.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats2Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats2Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats2Code.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats2Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats2Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats2Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats2Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats2Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats2Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats2Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats2Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats2Code.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 10;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats2Code.GDcostObjects2, gdjs.hats2Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_10", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats2Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats2Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats2Code.eventsList11(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 11;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats2Code.GDcostObjects2, gdjs.hats2Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_11", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats2Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats2Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats2Code.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 12;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats2Code.GDcostObjects2, gdjs.hats2Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_12", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats2Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats2Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats2Code.eventsList13(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 13;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats2Code.GDcostObjects2, gdjs.hats2Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_13", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats2Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats2Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats2Code.eventsList14(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 14;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats2Code.GDcostObjects2, gdjs.hats2Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_14", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats2Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats2Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats2Code.eventsList15(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 15;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats2Code.GDcostObjects2, gdjs.hats2Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_15", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats2Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats2Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats2Code.eventsList16(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 16;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats2Code.GDcostObjects2, gdjs.hats2Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_16", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats2Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats2Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats2Code.eventsList17(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 17;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats2Code.GDcostObjects2, gdjs.hats2Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_17", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats2Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats2Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats2Code.eventsList18(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 18;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats2Code.GDcostObjects2, gdjs.hats2Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_18", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats2Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats2Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats2Code.eventsList19(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.hats2Code.GDcostObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects2[i].returnVariable(gdjs.hats2Code.GDcostObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects2[i].returnVariable(gdjs.hats2Code.GDcostObjects2[i].getVariables().getFromIndex(0)).setString("ok");
}
}}

}


};gdjs.hats2Code.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("buy"), gdjs.hats2Code.GDbuyObjects2);
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDbuyObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.hats2Code.GDcostObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats2Code.GDcostObjects2[0].getVariables()).getFromIndex(0)));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats2Code.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959510Objects2Objects = Hashtable.newFrom({"hat_10": gdjs.hats2Code.GDhat_959510Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959510Objects3Objects = Hashtable.newFrom({"hat_10": gdjs.hats2Code.GDhat_959510Objects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959510Objects2Objects = Hashtable.newFrom({"hat_10": gdjs.hats2Code.GDhat_959510Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats2Code.GDhat_959510Objects2, gdjs.hats2Code.GDhat_959510Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959510Objects3Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].setString("50");
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].returnVariable(gdjs.hats2Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(10);
}}

}


{

/* Reuse gdjs.hats2Code.GDhat_959510Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959510Objects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(10);
}}

}


};gdjs.hats2Code.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_10"), gdjs.hats2Code.GDhat_959510Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959510Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats2Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDtext_9595pickObjects2[i].setString("ушки зайки");
}
}
{ //Subevents
gdjs.hats2Code.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959511Objects2Objects = Hashtable.newFrom({"hat_11": gdjs.hats2Code.GDhat_959511Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959511Objects3Objects = Hashtable.newFrom({"hat_11": gdjs.hats2Code.GDhat_959511Objects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959511Objects2Objects = Hashtable.newFrom({"hat_11": gdjs.hats2Code.GDhat_959511Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats2Code.GDhat_959511Objects2, gdjs.hats2Code.GDhat_959511Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959511Objects3Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].setString("8");
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].returnVariable(gdjs.hats2Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(8);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(11);
}}

}


{

/* Reuse gdjs.hats2Code.GDhat_959511Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959511Objects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(11);
}}

}


};gdjs.hats2Code.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_11"), gdjs.hats2Code.GDhat_959511Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959511Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats2Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDtext_9595pickObjects2[i].setString("<3");
}
}
{ //Subevents
gdjs.hats2Code.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959512Objects2Objects = Hashtable.newFrom({"hat_12": gdjs.hats2Code.GDhat_959512Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959512Objects3Objects = Hashtable.newFrom({"hat_12": gdjs.hats2Code.GDhat_959512Objects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959512Objects2Objects = Hashtable.newFrom({"hat_12": gdjs.hats2Code.GDhat_959512Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats2Code.GDhat_959512Objects2, gdjs.hats2Code.GDhat_959512Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959512Objects3Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].setString("35");
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].returnVariable(gdjs.hats2Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(35);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(12);
}}

}


{

/* Reuse gdjs.hats2Code.GDhat_959512Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959512Objects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(12);
}}

}


};gdjs.hats2Code.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_12"), gdjs.hats2Code.GDhat_959512Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959512Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats2Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDtext_9595pickObjects2[i].setString("стрела");
}
}
{ //Subevents
gdjs.hats2Code.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959513Objects2Objects = Hashtable.newFrom({"hat_13": gdjs.hats2Code.GDhat_959513Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959513Objects3Objects = Hashtable.newFrom({"hat_13": gdjs.hats2Code.GDhat_959513Objects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959513Objects2Objects = Hashtable.newFrom({"hat_13": gdjs.hats2Code.GDhat_959513Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats2Code.GDhat_959513Objects2, gdjs.hats2Code.GDhat_959513Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959513Objects3Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].setString("25");
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].returnVariable(gdjs.hats2Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(25);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(13);
}}

}


{

/* Reuse gdjs.hats2Code.GDhat_959513Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959513Objects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(13);
}}

}


};gdjs.hats2Code.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_13"), gdjs.hats2Code.GDhat_959513Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959513Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats2Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDtext_9595pickObjects2[i].setString("феска");
}
}
{ //Subevents
gdjs.hats2Code.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959514Objects2Objects = Hashtable.newFrom({"hat_14": gdjs.hats2Code.GDhat_959514Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959514Objects3Objects = Hashtable.newFrom({"hat_14": gdjs.hats2Code.GDhat_959514Objects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959514Objects2Objects = Hashtable.newFrom({"hat_14": gdjs.hats2Code.GDhat_959514Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats2Code.GDhat_959514Objects2, gdjs.hats2Code.GDhat_959514Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959514Objects3Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].setString("70");
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].returnVariable(gdjs.hats2Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(70);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(14);
}}

}


{

/* Reuse gdjs.hats2Code.GDhat_959514Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959514Objects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(14);
}}

}


};gdjs.hats2Code.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_14"), gdjs.hats2Code.GDhat_959514Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959514Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats2Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDtext_9595pickObjects2[i].setString("алмазная шапка");
}
}
{ //Subevents
gdjs.hats2Code.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959515Objects2Objects = Hashtable.newFrom({"hat_15": gdjs.hats2Code.GDhat_959515Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959515Objects3Objects = Hashtable.newFrom({"hat_15": gdjs.hats2Code.GDhat_959515Objects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959515Objects2Objects = Hashtable.newFrom({"hat_15": gdjs.hats2Code.GDhat_959515Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.eventsList32 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats2Code.GDhat_959515Objects2, gdjs.hats2Code.GDhat_959515Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959515Objects3Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].setString("25");
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].returnVariable(gdjs.hats2Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(25);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(15);
}}

}


{

/* Reuse gdjs.hats2Code.GDhat_959515Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959515Objects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(15);
}}

}


};gdjs.hats2Code.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_15"), gdjs.hats2Code.GDhat_959515Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959515Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats2Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDtext_9595pickObjects2[i].setString("3Д очки");
}
}
{ //Subevents
gdjs.hats2Code.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959516Objects2Objects = Hashtable.newFrom({"hat_16": gdjs.hats2Code.GDhat_959516Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959516Objects3Objects = Hashtable.newFrom({"hat_16": gdjs.hats2Code.GDhat_959516Objects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959516Objects2Objects = Hashtable.newFrom({"hat_16": gdjs.hats2Code.GDhat_959516Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats2Code.GDhat_959516Objects2, gdjs.hats2Code.GDhat_959516Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959516Objects3Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].setString("20");
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].returnVariable(gdjs.hats2Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(20);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(16);
}}

}


{

/* Reuse gdjs.hats2Code.GDhat_959516Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959516Objects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(16);
}}

}


};gdjs.hats2Code.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_16"), gdjs.hats2Code.GDhat_959516Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959516Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats2Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDtext_9595pickObjects2[i].setString("усы");
}
}
{ //Subevents
gdjs.hats2Code.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959517Objects2Objects = Hashtable.newFrom({"hat_17": gdjs.hats2Code.GDhat_959517Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959517Objects3Objects = Hashtable.newFrom({"hat_17": gdjs.hats2Code.GDhat_959517Objects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects3});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959517Objects2Objects = Hashtable.newFrom({"hat_17": gdjs.hats2Code.GDhat_959517Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats2Code.GDhat_959517Objects2, gdjs.hats2Code.GDhat_959517Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959517Objects3Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].setString("25");
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects3[i].returnVariable(gdjs.hats2Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(25);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(17);
}}

}


{

/* Reuse gdjs.hats2Code.GDhat_959517Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959517Objects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(17);
}}

}


};gdjs.hats2Code.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_17"), gdjs.hats2Code.GDhat_959517Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959517Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats2Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDtext_9595pickObjects2[i].setString("шапка ронина");
}
}
{ //Subevents
gdjs.hats2Code.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959518Objects1Objects = Hashtable.newFrom({"hat_18": gdjs.hats2Code.GDhat_959518Objects1});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959518Objects2Objects = Hashtable.newFrom({"hat_18": gdjs.hats2Code.GDhat_959518Objects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects2});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959518Objects1Objects = Hashtable.newFrom({"hat_18": gdjs.hats2Code.GDhat_959518Objects1});
gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects1Objects = Hashtable.newFrom({"lock": gdjs.hats2Code.GDlockObjects1});
gdjs.hats2Code.eventsList38 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats2Code.GDhat_959518Objects1, gdjs.hats2Code.GDhat_959518Objects2);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959518Objects2Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects2[i].setString("40");
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects2[i].returnVariable(gdjs.hats2Code.GDcostObjects2[i].getVariables().getFromIndex(0)).setNumber(40);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(18);
}}

}


{

/* Reuse gdjs.hats2Code.GDhat_959518Objects1 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats2Code.GDlockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959518Objects1Objects, gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDlockObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(18);
}}

}


};gdjs.hats2Code.eventsList39 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_18"), gdjs.hats2Code.GDhat_959518Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats2Code.mapOfGDgdjs_9546hats2Code_9546GDhat_9595959518Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats2Code.GDtext_9595pickObjects1);
{for(var i = 0, len = gdjs.hats2Code.GDtext_9595pickObjects1.length ;i < len;++i) {
    gdjs.hats2Code.GDtext_9595pickObjects1[i].setString("шлем");
}
}
{ //Subevents
gdjs.hats2Code.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.eventsList40 = function(runtimeScene) {

{


gdjs.hats2Code.eventsList10(runtimeScene);
}


{


gdjs.hats2Code.eventsList21(runtimeScene);
}


{


gdjs.hats2Code.eventsList23(runtimeScene);
}


{


gdjs.hats2Code.eventsList25(runtimeScene);
}


{


gdjs.hats2Code.eventsList27(runtimeScene);
}


{


gdjs.hats2Code.eventsList29(runtimeScene);
}


{


gdjs.hats2Code.eventsList31(runtimeScene);
}


{


gdjs.hats2Code.eventsList33(runtimeScene);
}


{


gdjs.hats2Code.eventsList35(runtimeScene);
}


{


gdjs.hats2Code.eventsList37(runtimeScene);
}


{


gdjs.hats2Code.eventsList39(runtimeScene);
}


};gdjs.hats2Code.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67256228);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats2Code.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.eventsList42 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hats2Code.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hats2Code.GDbackObjects2.length;i<l;++i) {
    if ( gdjs.hats2Code.GDbackObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hats2Code.GDbackObjects2[k] = gdjs.hats2Code.GDbackObjects2[i];
        ++k;
    }
}
gdjs.hats2Code.GDbackObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67301420);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDbackObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDbackObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDbackObjects2[i].setAnimationName("back");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hats2Code.GDr_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hats2Code.GDr_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.hats2Code.GDr_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hats2Code.GDr_9595buttonObjects2[k] = gdjs.hats2Code.GDr_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.hats2Code.GDr_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67302252);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDr_9595buttonObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDr_9595buttonObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDr_9595buttonObjects2[i].setAnimationName("r_button");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hats2Code.GDl_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hats2Code.GDl_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.hats2Code.GDl_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hats2Code.GDl_9595buttonObjects2[k] = gdjs.hats2Code.GDl_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.hats2Code.GDl_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67303020);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats2Code.GDl_9595buttonObjects2 */
{for(var i = 0, len = gdjs.hats2Code.GDl_9595buttonObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDl_9595buttonObjects2[i].setAnimationName("l_button");
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.hats2Code.eventsList43 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 10;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_10"), gdjs.hats2Code.GDhat_959510Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats2Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDpickerObjects2[i].setPosition((( gdjs.hats2Code.GDhat_959510Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959510Objects2[0].getCenterXInScene()),(( gdjs.hats2Code.GDhat_959510Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959510Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 11;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_11"), gdjs.hats2Code.GDhat_959511Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats2Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDpickerObjects2[i].setPosition((( gdjs.hats2Code.GDhat_959511Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959511Objects2[0].getCenterXInScene()),(( gdjs.hats2Code.GDhat_959511Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959511Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 12;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_12"), gdjs.hats2Code.GDhat_959512Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats2Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDpickerObjects2[i].setPosition((( gdjs.hats2Code.GDhat_959512Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959512Objects2[0].getCenterXInScene()),(( gdjs.hats2Code.GDhat_959512Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959512Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 13;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_13"), gdjs.hats2Code.GDhat_959513Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats2Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDpickerObjects2[i].setPosition((( gdjs.hats2Code.GDhat_959513Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959513Objects2[0].getCenterXInScene()),(( gdjs.hats2Code.GDhat_959513Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959513Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 14;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_14"), gdjs.hats2Code.GDhat_959514Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats2Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDpickerObjects2[i].setPosition((( gdjs.hats2Code.GDhat_959514Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959514Objects2[0].getCenterXInScene()),(( gdjs.hats2Code.GDhat_959514Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959514Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 15;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_15"), gdjs.hats2Code.GDhat_959515Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats2Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDpickerObjects2[i].setPosition((( gdjs.hats2Code.GDhat_959515Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959515Objects2[0].getCenterXInScene()),(( gdjs.hats2Code.GDhat_959515Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959515Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 16;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_16"), gdjs.hats2Code.GDhat_959516Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats2Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDpickerObjects2[i].setPosition((( gdjs.hats2Code.GDhat_959516Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959516Objects2[0].getCenterXInScene()),(( gdjs.hats2Code.GDhat_959516Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959516Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 17;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_17"), gdjs.hats2Code.GDhat_959517Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats2Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDpickerObjects2[i].setPosition((( gdjs.hats2Code.GDhat_959517Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959517Objects2[0].getCenterXInScene()),(( gdjs.hats2Code.GDhat_959517Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959517Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 18;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_18"), gdjs.hats2Code.GDhat_959518Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats2Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats2Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats2Code.GDpickerObjects2[i].setPosition((( gdjs.hats2Code.GDhat_959518Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959518Objects2[0].getCenterXInScene()),(( gdjs.hats2Code.GDhat_959518Objects2.length === 0 ) ? 0 :gdjs.hats2Code.GDhat_959518Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats2Code.GDpickerObjects1);
{for(var i = 0, len = gdjs.hats2Code.GDpickerObjects1.length ;i < len;++i) {
    gdjs.hats2Code.GDpickerObjects1[i].setPosition(999,999);
}
}}

}


};gdjs.hats2Code.eventsList44 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(67304972);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats2Code.eventsList43(runtimeScene);} //End of subevents
}

}


};gdjs.hats2Code.eventsList45 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats2Code.GDcoins2Objects1);
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats2Code.GDcostObjects1);
{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "coin", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{for(var i = 0, len = gdjs.hats2Code.GDcoins2Objects1.length ;i < len;++i) {
    gdjs.hats2Code.GDcoins2Objects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}{for(var i = 0, len = gdjs.hats2Code.GDcostObjects1.length ;i < len;++i) {
    gdjs.hats2Code.GDcostObjects1[i].returnVariable(gdjs.hats2Code.GDcostObjects1[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "hat", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
{ //Subevents
gdjs.hats2Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.hats2Code.eventsList2(runtimeScene);
}


{


gdjs.hats2Code.eventsList7(runtimeScene);
}


{


gdjs.hats2Code.eventsList9(runtimeScene);
}


{


gdjs.hats2Code.eventsList41(runtimeScene);
}


{



}


{


gdjs.hats2Code.eventsList42(runtimeScene);
}


{


gdjs.hats2Code.eventsList44(runtimeScene);
}


};

gdjs.hats2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.hats2Code.GDhat_95950Objects1.length = 0;
gdjs.hats2Code.GDhat_95950Objects2.length = 0;
gdjs.hats2Code.GDhat_95950Objects3.length = 0;
gdjs.hats2Code.GDhat_95950Objects4.length = 0;
gdjs.hats2Code.GDhat_95951Objects1.length = 0;
gdjs.hats2Code.GDhat_95951Objects2.length = 0;
gdjs.hats2Code.GDhat_95951Objects3.length = 0;
gdjs.hats2Code.GDhat_95951Objects4.length = 0;
gdjs.hats2Code.GDhat_95952Objects1.length = 0;
gdjs.hats2Code.GDhat_95952Objects2.length = 0;
gdjs.hats2Code.GDhat_95952Objects3.length = 0;
gdjs.hats2Code.GDhat_95952Objects4.length = 0;
gdjs.hats2Code.GDhat_95953Objects1.length = 0;
gdjs.hats2Code.GDhat_95953Objects2.length = 0;
gdjs.hats2Code.GDhat_95953Objects3.length = 0;
gdjs.hats2Code.GDhat_95953Objects4.length = 0;
gdjs.hats2Code.GDhat_95954Objects1.length = 0;
gdjs.hats2Code.GDhat_95954Objects2.length = 0;
gdjs.hats2Code.GDhat_95954Objects3.length = 0;
gdjs.hats2Code.GDhat_95954Objects4.length = 0;
gdjs.hats2Code.GDhat_95955Objects1.length = 0;
gdjs.hats2Code.GDhat_95955Objects2.length = 0;
gdjs.hats2Code.GDhat_95955Objects3.length = 0;
gdjs.hats2Code.GDhat_95955Objects4.length = 0;
gdjs.hats2Code.GDhat_95956Objects1.length = 0;
gdjs.hats2Code.GDhat_95956Objects2.length = 0;
gdjs.hats2Code.GDhat_95956Objects3.length = 0;
gdjs.hats2Code.GDhat_95956Objects4.length = 0;
gdjs.hats2Code.GDhat_95957Objects1.length = 0;
gdjs.hats2Code.GDhat_95957Objects2.length = 0;
gdjs.hats2Code.GDhat_95957Objects3.length = 0;
gdjs.hats2Code.GDhat_95957Objects4.length = 0;
gdjs.hats2Code.GDhat_95958Objects1.length = 0;
gdjs.hats2Code.GDhat_95958Objects2.length = 0;
gdjs.hats2Code.GDhat_95958Objects3.length = 0;
gdjs.hats2Code.GDhat_95958Objects4.length = 0;
gdjs.hats2Code.GDhat_95959Objects1.length = 0;
gdjs.hats2Code.GDhat_95959Objects2.length = 0;
gdjs.hats2Code.GDhat_95959Objects3.length = 0;
gdjs.hats2Code.GDhat_95959Objects4.length = 0;
gdjs.hats2Code.GDhat_959510Objects1.length = 0;
gdjs.hats2Code.GDhat_959510Objects2.length = 0;
gdjs.hats2Code.GDhat_959510Objects3.length = 0;
gdjs.hats2Code.GDhat_959510Objects4.length = 0;
gdjs.hats2Code.GDhat_959511Objects1.length = 0;
gdjs.hats2Code.GDhat_959511Objects2.length = 0;
gdjs.hats2Code.GDhat_959511Objects3.length = 0;
gdjs.hats2Code.GDhat_959511Objects4.length = 0;
gdjs.hats2Code.GDhat_959512Objects1.length = 0;
gdjs.hats2Code.GDhat_959512Objects2.length = 0;
gdjs.hats2Code.GDhat_959512Objects3.length = 0;
gdjs.hats2Code.GDhat_959512Objects4.length = 0;
gdjs.hats2Code.GDhat_959513Objects1.length = 0;
gdjs.hats2Code.GDhat_959513Objects2.length = 0;
gdjs.hats2Code.GDhat_959513Objects3.length = 0;
gdjs.hats2Code.GDhat_959513Objects4.length = 0;
gdjs.hats2Code.GDhat_959514Objects1.length = 0;
gdjs.hats2Code.GDhat_959514Objects2.length = 0;
gdjs.hats2Code.GDhat_959514Objects3.length = 0;
gdjs.hats2Code.GDhat_959514Objects4.length = 0;
gdjs.hats2Code.GDhat_959515Objects1.length = 0;
gdjs.hats2Code.GDhat_959515Objects2.length = 0;
gdjs.hats2Code.GDhat_959515Objects3.length = 0;
gdjs.hats2Code.GDhat_959515Objects4.length = 0;
gdjs.hats2Code.GDhat_959516Objects1.length = 0;
gdjs.hats2Code.GDhat_959516Objects2.length = 0;
gdjs.hats2Code.GDhat_959516Objects3.length = 0;
gdjs.hats2Code.GDhat_959516Objects4.length = 0;
gdjs.hats2Code.GDhat_959517Objects1.length = 0;
gdjs.hats2Code.GDhat_959517Objects2.length = 0;
gdjs.hats2Code.GDhat_959517Objects3.length = 0;
gdjs.hats2Code.GDhat_959517Objects4.length = 0;
gdjs.hats2Code.GDhat_959518Objects1.length = 0;
gdjs.hats2Code.GDhat_959518Objects2.length = 0;
gdjs.hats2Code.GDhat_959518Objects3.length = 0;
gdjs.hats2Code.GDhat_959518Objects4.length = 0;
gdjs.hats2Code.GDhat_9595randomObjects1.length = 0;
gdjs.hats2Code.GDhat_9595randomObjects2.length = 0;
gdjs.hats2Code.GDhat_9595randomObjects3.length = 0;
gdjs.hats2Code.GDhat_9595randomObjects4.length = 0;
gdjs.hats2Code.GDhat_9595dldoObjects1.length = 0;
gdjs.hats2Code.GDhat_9595dldoObjects2.length = 0;
gdjs.hats2Code.GDhat_9595dldoObjects3.length = 0;
gdjs.hats2Code.GDhat_9595dldoObjects4.length = 0;
gdjs.hats2Code.GDtext_9595pickObjects1.length = 0;
gdjs.hats2Code.GDtext_9595pickObjects2.length = 0;
gdjs.hats2Code.GDtext_9595pickObjects3.length = 0;
gdjs.hats2Code.GDtext_9595pickObjects4.length = 0;
gdjs.hats2Code.GDbuyObjects1.length = 0;
gdjs.hats2Code.GDbuyObjects2.length = 0;
gdjs.hats2Code.GDbuyObjects3.length = 0;
gdjs.hats2Code.GDbuyObjects4.length = 0;
gdjs.hats2Code.GDcostObjects1.length = 0;
gdjs.hats2Code.GDcostObjects2.length = 0;
gdjs.hats2Code.GDcostObjects3.length = 0;
gdjs.hats2Code.GDcostObjects4.length = 0;
gdjs.hats2Code.GDpickerObjects1.length = 0;
gdjs.hats2Code.GDpickerObjects2.length = 0;
gdjs.hats2Code.GDpickerObjects3.length = 0;
gdjs.hats2Code.GDpickerObjects4.length = 0;
gdjs.hats2Code.GDcoin_9595marker_9595hatsObjects1.length = 0;
gdjs.hats2Code.GDcoin_9595marker_9595hatsObjects2.length = 0;
gdjs.hats2Code.GDcoin_9595marker_9595hatsObjects3.length = 0;
gdjs.hats2Code.GDcoin_9595marker_9595hatsObjects4.length = 0;
gdjs.hats2Code.GDgrass_9595blockObjects1.length = 0;
gdjs.hats2Code.GDgrass_9595blockObjects2.length = 0;
gdjs.hats2Code.GDgrass_9595blockObjects3.length = 0;
gdjs.hats2Code.GDgrass_9595blockObjects4.length = 0;
gdjs.hats2Code.GDblockObjects1.length = 0;
gdjs.hats2Code.GDblockObjects2.length = 0;
gdjs.hats2Code.GDblockObjects3.length = 0;
gdjs.hats2Code.GDblockObjects4.length = 0;
gdjs.hats2Code.GDmenuObjects1.length = 0;
gdjs.hats2Code.GDmenuObjects2.length = 0;
gdjs.hats2Code.GDmenuObjects3.length = 0;
gdjs.hats2Code.GDmenuObjects4.length = 0;
gdjs.hats2Code.GDhomeObjects1.length = 0;
gdjs.hats2Code.GDhomeObjects2.length = 0;
gdjs.hats2Code.GDhomeObjects3.length = 0;
gdjs.hats2Code.GDhomeObjects4.length = 0;
gdjs.hats2Code.GDresetObjects1.length = 0;
gdjs.hats2Code.GDresetObjects2.length = 0;
gdjs.hats2Code.GDresetObjects3.length = 0;
gdjs.hats2Code.GDresetObjects4.length = 0;
gdjs.hats2Code.GDspikeObjects1.length = 0;
gdjs.hats2Code.GDspikeObjects2.length = 0;
gdjs.hats2Code.GDspikeObjects3.length = 0;
gdjs.hats2Code.GDspikeObjects4.length = 0;
gdjs.hats2Code.GDend_9595homeObjects1.length = 0;
gdjs.hats2Code.GDend_9595homeObjects2.length = 0;
gdjs.hats2Code.GDend_9595homeObjects3.length = 0;
gdjs.hats2Code.GDend_9595homeObjects4.length = 0;
gdjs.hats2Code.GDend_9595resetObjects1.length = 0;
gdjs.hats2Code.GDend_9595resetObjects2.length = 0;
gdjs.hats2Code.GDend_9595resetObjects3.length = 0;
gdjs.hats2Code.GDend_9595resetObjects4.length = 0;
gdjs.hats2Code.GDrobot_9595enemyObjects1.length = 0;
gdjs.hats2Code.GDrobot_9595enemyObjects2.length = 0;
gdjs.hats2Code.GDrobot_9595enemyObjects3.length = 0;
gdjs.hats2Code.GDrobot_9595enemyObjects4.length = 0;
gdjs.hats2Code.GDslime_9595enemyObjects1.length = 0;
gdjs.hats2Code.GDslime_9595enemyObjects2.length = 0;
gdjs.hats2Code.GDslime_9595enemyObjects3.length = 0;
gdjs.hats2Code.GDslime_9595enemyObjects4.length = 0;
gdjs.hats2Code.GDrob_9595enemy_9595rightObjects1.length = 0;
gdjs.hats2Code.GDrob_9595enemy_9595rightObjects2.length = 0;
gdjs.hats2Code.GDrob_9595enemy_9595rightObjects3.length = 0;
gdjs.hats2Code.GDrob_9595enemy_9595rightObjects4.length = 0;
gdjs.hats2Code.GDrob_9595enemy_9595leftObjects1.length = 0;
gdjs.hats2Code.GDrob_9595enemy_9595leftObjects2.length = 0;
gdjs.hats2Code.GDrob_9595enemy_9595leftObjects3.length = 0;
gdjs.hats2Code.GDrob_9595enemy_9595leftObjects4.length = 0;
gdjs.hats2Code.GDheroObjects1.length = 0;
gdjs.hats2Code.GDheroObjects2.length = 0;
gdjs.hats2Code.GDheroObjects3.length = 0;
gdjs.hats2Code.GDheroObjects4.length = 0;
gdjs.hats2Code.GDsawObjects1.length = 0;
gdjs.hats2Code.GDsawObjects2.length = 0;
gdjs.hats2Code.GDsawObjects3.length = 0;
gdjs.hats2Code.GDsawObjects4.length = 0;
gdjs.hats2Code.GDcoin_9595markerObjects1.length = 0;
gdjs.hats2Code.GDcoin_9595markerObjects2.length = 0;
gdjs.hats2Code.GDcoin_9595markerObjects3.length = 0;
gdjs.hats2Code.GDcoin_9595markerObjects4.length = 0;
gdjs.hats2Code.GDcoin_9595marker2Objects1.length = 0;
gdjs.hats2Code.GDcoin_9595marker2Objects2.length = 0;
gdjs.hats2Code.GDcoin_9595marker2Objects3.length = 0;
gdjs.hats2Code.GDcoin_9595marker2Objects4.length = 0;
gdjs.hats2Code.GDcoinsObjects1.length = 0;
gdjs.hats2Code.GDcoinsObjects2.length = 0;
gdjs.hats2Code.GDcoinsObjects3.length = 0;
gdjs.hats2Code.GDcoinsObjects4.length = 0;
gdjs.hats2Code.GDcoins2Objects1.length = 0;
gdjs.hats2Code.GDcoins2Objects2.length = 0;
gdjs.hats2Code.GDcoins2Objects3.length = 0;
gdjs.hats2Code.GDcoins2Objects4.length = 0;
gdjs.hats2Code.GDkey_9595lockerObjects1.length = 0;
gdjs.hats2Code.GDkey_9595lockerObjects2.length = 0;
gdjs.hats2Code.GDkey_9595lockerObjects3.length = 0;
gdjs.hats2Code.GDkey_9595lockerObjects4.length = 0;
gdjs.hats2Code.GDr_9595buttonObjects1.length = 0;
gdjs.hats2Code.GDr_9595buttonObjects2.length = 0;
gdjs.hats2Code.GDr_9595buttonObjects3.length = 0;
gdjs.hats2Code.GDr_9595buttonObjects4.length = 0;
gdjs.hats2Code.GDl_9595buttonObjects1.length = 0;
gdjs.hats2Code.GDl_9595buttonObjects2.length = 0;
gdjs.hats2Code.GDl_9595buttonObjects3.length = 0;
gdjs.hats2Code.GDl_9595buttonObjects4.length = 0;
gdjs.hats2Code.GDbackObjects1.length = 0;
gdjs.hats2Code.GDbackObjects2.length = 0;
gdjs.hats2Code.GDbackObjects3.length = 0;
gdjs.hats2Code.GDbackObjects4.length = 0;
gdjs.hats2Code.GDlockObjects1.length = 0;
gdjs.hats2Code.GDlockObjects2.length = 0;
gdjs.hats2Code.GDlockObjects3.length = 0;
gdjs.hats2Code.GDlockObjects4.length = 0;
gdjs.hats2Code.GDcamObjects1.length = 0;
gdjs.hats2Code.GDcamObjects2.length = 0;
gdjs.hats2Code.GDcamObjects3.length = 0;
gdjs.hats2Code.GDcamObjects4.length = 0;
gdjs.hats2Code.GDfonikObjects1.length = 0;
gdjs.hats2Code.GDfonikObjects2.length = 0;
gdjs.hats2Code.GDfonikObjects3.length = 0;
gdjs.hats2Code.GDfonikObjects4.length = 0;

gdjs.hats2Code.eventsList45(runtimeScene);

return;

}

gdjs['hats2Code'] = gdjs.hats2Code;
