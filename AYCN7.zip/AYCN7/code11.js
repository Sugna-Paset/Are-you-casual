gdjs.hats8Code = {};
gdjs.hats8Code.GDbackObjects3_1final = [];

gdjs.hats8Code.GDl_9595buttonObjects3_1final = [];

gdjs.hats8Code.GDr_9595buttonObjects3_1final = [];

gdjs.hats8Code.GDhat_95950Objects1= [];
gdjs.hats8Code.GDhat_95950Objects2= [];
gdjs.hats8Code.GDhat_95950Objects3= [];
gdjs.hats8Code.GDhat_95950Objects4= [];
gdjs.hats8Code.GDhat_95950Objects5= [];
gdjs.hats8Code.GDhat_95951Objects1= [];
gdjs.hats8Code.GDhat_95951Objects2= [];
gdjs.hats8Code.GDhat_95951Objects3= [];
gdjs.hats8Code.GDhat_95951Objects4= [];
gdjs.hats8Code.GDhat_95951Objects5= [];
gdjs.hats8Code.GDhat_95952Objects1= [];
gdjs.hats8Code.GDhat_95952Objects2= [];
gdjs.hats8Code.GDhat_95952Objects3= [];
gdjs.hats8Code.GDhat_95952Objects4= [];
gdjs.hats8Code.GDhat_95952Objects5= [];
gdjs.hats8Code.GDhat_95953Objects1= [];
gdjs.hats8Code.GDhat_95953Objects2= [];
gdjs.hats8Code.GDhat_95953Objects3= [];
gdjs.hats8Code.GDhat_95953Objects4= [];
gdjs.hats8Code.GDhat_95953Objects5= [];
gdjs.hats8Code.GDhat_95954Objects1= [];
gdjs.hats8Code.GDhat_95954Objects2= [];
gdjs.hats8Code.GDhat_95954Objects3= [];
gdjs.hats8Code.GDhat_95954Objects4= [];
gdjs.hats8Code.GDhat_95954Objects5= [];
gdjs.hats8Code.GDhat_95955Objects1= [];
gdjs.hats8Code.GDhat_95955Objects2= [];
gdjs.hats8Code.GDhat_95955Objects3= [];
gdjs.hats8Code.GDhat_95955Objects4= [];
gdjs.hats8Code.GDhat_95955Objects5= [];
gdjs.hats8Code.GDhat_95956Objects1= [];
gdjs.hats8Code.GDhat_95956Objects2= [];
gdjs.hats8Code.GDhat_95956Objects3= [];
gdjs.hats8Code.GDhat_95956Objects4= [];
gdjs.hats8Code.GDhat_95956Objects5= [];
gdjs.hats8Code.GDhat_95957Objects1= [];
gdjs.hats8Code.GDhat_95957Objects2= [];
gdjs.hats8Code.GDhat_95957Objects3= [];
gdjs.hats8Code.GDhat_95957Objects4= [];
gdjs.hats8Code.GDhat_95957Objects5= [];
gdjs.hats8Code.GDhat_95958Objects1= [];
gdjs.hats8Code.GDhat_95958Objects2= [];
gdjs.hats8Code.GDhat_95958Objects3= [];
gdjs.hats8Code.GDhat_95958Objects4= [];
gdjs.hats8Code.GDhat_95958Objects5= [];
gdjs.hats8Code.GDhat_95959Objects1= [];
gdjs.hats8Code.GDhat_95959Objects2= [];
gdjs.hats8Code.GDhat_95959Objects3= [];
gdjs.hats8Code.GDhat_95959Objects4= [];
gdjs.hats8Code.GDhat_95959Objects5= [];
gdjs.hats8Code.GDhat_959510Objects1= [];
gdjs.hats8Code.GDhat_959510Objects2= [];
gdjs.hats8Code.GDhat_959510Objects3= [];
gdjs.hats8Code.GDhat_959510Objects4= [];
gdjs.hats8Code.GDhat_959510Objects5= [];
gdjs.hats8Code.GDhat_959511Objects1= [];
gdjs.hats8Code.GDhat_959511Objects2= [];
gdjs.hats8Code.GDhat_959511Objects3= [];
gdjs.hats8Code.GDhat_959511Objects4= [];
gdjs.hats8Code.GDhat_959511Objects5= [];
gdjs.hats8Code.GDhat_959512Objects1= [];
gdjs.hats8Code.GDhat_959512Objects2= [];
gdjs.hats8Code.GDhat_959512Objects3= [];
gdjs.hats8Code.GDhat_959512Objects4= [];
gdjs.hats8Code.GDhat_959512Objects5= [];
gdjs.hats8Code.GDhat_959513Objects1= [];
gdjs.hats8Code.GDhat_959513Objects2= [];
gdjs.hats8Code.GDhat_959513Objects3= [];
gdjs.hats8Code.GDhat_959513Objects4= [];
gdjs.hats8Code.GDhat_959513Objects5= [];
gdjs.hats8Code.GDhat_959514Objects1= [];
gdjs.hats8Code.GDhat_959514Objects2= [];
gdjs.hats8Code.GDhat_959514Objects3= [];
gdjs.hats8Code.GDhat_959514Objects4= [];
gdjs.hats8Code.GDhat_959514Objects5= [];
gdjs.hats8Code.GDhat_959515Objects1= [];
gdjs.hats8Code.GDhat_959515Objects2= [];
gdjs.hats8Code.GDhat_959515Objects3= [];
gdjs.hats8Code.GDhat_959515Objects4= [];
gdjs.hats8Code.GDhat_959515Objects5= [];
gdjs.hats8Code.GDhat_959516Objects1= [];
gdjs.hats8Code.GDhat_959516Objects2= [];
gdjs.hats8Code.GDhat_959516Objects3= [];
gdjs.hats8Code.GDhat_959516Objects4= [];
gdjs.hats8Code.GDhat_959516Objects5= [];
gdjs.hats8Code.GDhat_959517Objects1= [];
gdjs.hats8Code.GDhat_959517Objects2= [];
gdjs.hats8Code.GDhat_959517Objects3= [];
gdjs.hats8Code.GDhat_959517Objects4= [];
gdjs.hats8Code.GDhat_959517Objects5= [];
gdjs.hats8Code.GDhat_959518Objects1= [];
gdjs.hats8Code.GDhat_959518Objects2= [];
gdjs.hats8Code.GDhat_959518Objects3= [];
gdjs.hats8Code.GDhat_959518Objects4= [];
gdjs.hats8Code.GDhat_959518Objects5= [];
gdjs.hats8Code.GDhat_959555Objects1= [];
gdjs.hats8Code.GDhat_959555Objects2= [];
gdjs.hats8Code.GDhat_959555Objects3= [];
gdjs.hats8Code.GDhat_959555Objects4= [];
gdjs.hats8Code.GDhat_959555Objects5= [];
gdjs.hats8Code.GDhat_959556Objects1= [];
gdjs.hats8Code.GDhat_959556Objects2= [];
gdjs.hats8Code.GDhat_959556Objects3= [];
gdjs.hats8Code.GDhat_959556Objects4= [];
gdjs.hats8Code.GDhat_959556Objects5= [];
gdjs.hats8Code.GDhat_959557Objects1= [];
gdjs.hats8Code.GDhat_959557Objects2= [];
gdjs.hats8Code.GDhat_959557Objects3= [];
gdjs.hats8Code.GDhat_959557Objects4= [];
gdjs.hats8Code.GDhat_959557Objects5= [];
gdjs.hats8Code.GDhat_959558Objects1= [];
gdjs.hats8Code.GDhat_959558Objects2= [];
gdjs.hats8Code.GDhat_959558Objects3= [];
gdjs.hats8Code.GDhat_959558Objects4= [];
gdjs.hats8Code.GDhat_959558Objects5= [];
gdjs.hats8Code.GDhat_959559Objects1= [];
gdjs.hats8Code.GDhat_959559Objects2= [];
gdjs.hats8Code.GDhat_959559Objects3= [];
gdjs.hats8Code.GDhat_959559Objects4= [];
gdjs.hats8Code.GDhat_959559Objects5= [];
gdjs.hats8Code.GDhat_959560Objects1= [];
gdjs.hats8Code.GDhat_959560Objects2= [];
gdjs.hats8Code.GDhat_959560Objects3= [];
gdjs.hats8Code.GDhat_959560Objects4= [];
gdjs.hats8Code.GDhat_959560Objects5= [];
gdjs.hats8Code.GDhat_959561Objects1= [];
gdjs.hats8Code.GDhat_959561Objects2= [];
gdjs.hats8Code.GDhat_959561Objects3= [];
gdjs.hats8Code.GDhat_959561Objects4= [];
gdjs.hats8Code.GDhat_959561Objects5= [];
gdjs.hats8Code.GDhat_959562Objects1= [];
gdjs.hats8Code.GDhat_959562Objects2= [];
gdjs.hats8Code.GDhat_959562Objects3= [];
gdjs.hats8Code.GDhat_959562Objects4= [];
gdjs.hats8Code.GDhat_959562Objects5= [];
gdjs.hats8Code.GDhat_959563Objects1= [];
gdjs.hats8Code.GDhat_959563Objects2= [];
gdjs.hats8Code.GDhat_959563Objects3= [];
gdjs.hats8Code.GDhat_959563Objects4= [];
gdjs.hats8Code.GDhat_959563Objects5= [];
gdjs.hats8Code.GDhat_959564Objects1= [];
gdjs.hats8Code.GDhat_959564Objects2= [];
gdjs.hats8Code.GDhat_959564Objects3= [];
gdjs.hats8Code.GDhat_959564Objects4= [];
gdjs.hats8Code.GDhat_959564Objects5= [];
gdjs.hats8Code.GDhat_959565Objects1= [];
gdjs.hats8Code.GDhat_959565Objects2= [];
gdjs.hats8Code.GDhat_959565Objects3= [];
gdjs.hats8Code.GDhat_959565Objects4= [];
gdjs.hats8Code.GDhat_959565Objects5= [];
gdjs.hats8Code.GDhat_959566Objects1= [];
gdjs.hats8Code.GDhat_959566Objects2= [];
gdjs.hats8Code.GDhat_959566Objects3= [];
gdjs.hats8Code.GDhat_959566Objects4= [];
gdjs.hats8Code.GDhat_959566Objects5= [];
gdjs.hats8Code.GDhat_959567Objects1= [];
gdjs.hats8Code.GDhat_959567Objects2= [];
gdjs.hats8Code.GDhat_959567Objects3= [];
gdjs.hats8Code.GDhat_959567Objects4= [];
gdjs.hats8Code.GDhat_959567Objects5= [];
gdjs.hats8Code.GDhat_959568Objects1= [];
gdjs.hats8Code.GDhat_959568Objects2= [];
gdjs.hats8Code.GDhat_959568Objects3= [];
gdjs.hats8Code.GDhat_959568Objects4= [];
gdjs.hats8Code.GDhat_959568Objects5= [];
gdjs.hats8Code.GDhat_959569Objects1= [];
gdjs.hats8Code.GDhat_959569Objects2= [];
gdjs.hats8Code.GDhat_959569Objects3= [];
gdjs.hats8Code.GDhat_959569Objects4= [];
gdjs.hats8Code.GDhat_959569Objects5= [];
gdjs.hats8Code.GDhat_959570Objects1= [];
gdjs.hats8Code.GDhat_959570Objects2= [];
gdjs.hats8Code.GDhat_959570Objects3= [];
gdjs.hats8Code.GDhat_959570Objects4= [];
gdjs.hats8Code.GDhat_959570Objects5= [];
gdjs.hats8Code.GDhat_959571Objects1= [];
gdjs.hats8Code.GDhat_959571Objects2= [];
gdjs.hats8Code.GDhat_959571Objects3= [];
gdjs.hats8Code.GDhat_959571Objects4= [];
gdjs.hats8Code.GDhat_959571Objects5= [];
gdjs.hats8Code.GDhat_959572Objects1= [];
gdjs.hats8Code.GDhat_959572Objects2= [];
gdjs.hats8Code.GDhat_959572Objects3= [];
gdjs.hats8Code.GDhat_959572Objects4= [];
gdjs.hats8Code.GDhat_959572Objects5= [];
gdjs.hats8Code.GDhat_9595randomObjects1= [];
gdjs.hats8Code.GDhat_9595randomObjects2= [];
gdjs.hats8Code.GDhat_9595randomObjects3= [];
gdjs.hats8Code.GDhat_9595randomObjects4= [];
gdjs.hats8Code.GDhat_9595randomObjects5= [];
gdjs.hats8Code.GDhat_9595dldoObjects1= [];
gdjs.hats8Code.GDhat_9595dldoObjects2= [];
gdjs.hats8Code.GDhat_9595dldoObjects3= [];
gdjs.hats8Code.GDhat_9595dldoObjects4= [];
gdjs.hats8Code.GDhat_9595dldoObjects5= [];
gdjs.hats8Code.GDtext_9595pickObjects1= [];
gdjs.hats8Code.GDtext_9595pickObjects2= [];
gdjs.hats8Code.GDtext_9595pickObjects3= [];
gdjs.hats8Code.GDtext_9595pickObjects4= [];
gdjs.hats8Code.GDtext_9595pickObjects5= [];
gdjs.hats8Code.GDbuyObjects1= [];
gdjs.hats8Code.GDbuyObjects2= [];
gdjs.hats8Code.GDbuyObjects3= [];
gdjs.hats8Code.GDbuyObjects4= [];
gdjs.hats8Code.GDbuyObjects5= [];
gdjs.hats8Code.GDcostObjects1= [];
gdjs.hats8Code.GDcostObjects2= [];
gdjs.hats8Code.GDcostObjects3= [];
gdjs.hats8Code.GDcostObjects4= [];
gdjs.hats8Code.GDcostObjects5= [];
gdjs.hats8Code.GDpickerObjects1= [];
gdjs.hats8Code.GDpickerObjects2= [];
gdjs.hats8Code.GDpickerObjects3= [];
gdjs.hats8Code.GDpickerObjects4= [];
gdjs.hats8Code.GDpickerObjects5= [];
gdjs.hats8Code.GDcoin_9595marker_9595hatsObjects1= [];
gdjs.hats8Code.GDcoin_9595marker_9595hatsObjects2= [];
gdjs.hats8Code.GDcoin_9595marker_9595hatsObjects3= [];
gdjs.hats8Code.GDcoin_9595marker_9595hatsObjects4= [];
gdjs.hats8Code.GDcoin_9595marker_9595hatsObjects5= [];
gdjs.hats8Code.GDgrass_9595blockObjects1= [];
gdjs.hats8Code.GDgrass_9595blockObjects2= [];
gdjs.hats8Code.GDgrass_9595blockObjects3= [];
gdjs.hats8Code.GDgrass_9595blockObjects4= [];
gdjs.hats8Code.GDgrass_9595blockObjects5= [];
gdjs.hats8Code.GDblockObjects1= [];
gdjs.hats8Code.GDblockObjects2= [];
gdjs.hats8Code.GDblockObjects3= [];
gdjs.hats8Code.GDblockObjects4= [];
gdjs.hats8Code.GDblockObjects5= [];
gdjs.hats8Code.GDmenuObjects1= [];
gdjs.hats8Code.GDmenuObjects2= [];
gdjs.hats8Code.GDmenuObjects3= [];
gdjs.hats8Code.GDmenuObjects4= [];
gdjs.hats8Code.GDmenuObjects5= [];
gdjs.hats8Code.GDhomeObjects1= [];
gdjs.hats8Code.GDhomeObjects2= [];
gdjs.hats8Code.GDhomeObjects3= [];
gdjs.hats8Code.GDhomeObjects4= [];
gdjs.hats8Code.GDhomeObjects5= [];
gdjs.hats8Code.GDresetObjects1= [];
gdjs.hats8Code.GDresetObjects2= [];
gdjs.hats8Code.GDresetObjects3= [];
gdjs.hats8Code.GDresetObjects4= [];
gdjs.hats8Code.GDresetObjects5= [];
gdjs.hats8Code.GDspikeObjects1= [];
gdjs.hats8Code.GDspikeObjects2= [];
gdjs.hats8Code.GDspikeObjects3= [];
gdjs.hats8Code.GDspikeObjects4= [];
gdjs.hats8Code.GDspikeObjects5= [];
gdjs.hats8Code.GDend_9595homeObjects1= [];
gdjs.hats8Code.GDend_9595homeObjects2= [];
gdjs.hats8Code.GDend_9595homeObjects3= [];
gdjs.hats8Code.GDend_9595homeObjects4= [];
gdjs.hats8Code.GDend_9595homeObjects5= [];
gdjs.hats8Code.GDend_9595resetObjects1= [];
gdjs.hats8Code.GDend_9595resetObjects2= [];
gdjs.hats8Code.GDend_9595resetObjects3= [];
gdjs.hats8Code.GDend_9595resetObjects4= [];
gdjs.hats8Code.GDend_9595resetObjects5= [];
gdjs.hats8Code.GDrobot_9595enemyObjects1= [];
gdjs.hats8Code.GDrobot_9595enemyObjects2= [];
gdjs.hats8Code.GDrobot_9595enemyObjects3= [];
gdjs.hats8Code.GDrobot_9595enemyObjects4= [];
gdjs.hats8Code.GDrobot_9595enemyObjects5= [];
gdjs.hats8Code.GDslime_9595enemyObjects1= [];
gdjs.hats8Code.GDslime_9595enemyObjects2= [];
gdjs.hats8Code.GDslime_9595enemyObjects3= [];
gdjs.hats8Code.GDslime_9595enemyObjects4= [];
gdjs.hats8Code.GDslime_9595enemyObjects5= [];
gdjs.hats8Code.GDrob_9595enemy_9595rightObjects1= [];
gdjs.hats8Code.GDrob_9595enemy_9595rightObjects2= [];
gdjs.hats8Code.GDrob_9595enemy_9595rightObjects3= [];
gdjs.hats8Code.GDrob_9595enemy_9595rightObjects4= [];
gdjs.hats8Code.GDrob_9595enemy_9595rightObjects5= [];
gdjs.hats8Code.GDrob_9595enemy_9595leftObjects1= [];
gdjs.hats8Code.GDrob_9595enemy_9595leftObjects2= [];
gdjs.hats8Code.GDrob_9595enemy_9595leftObjects3= [];
gdjs.hats8Code.GDrob_9595enemy_9595leftObjects4= [];
gdjs.hats8Code.GDrob_9595enemy_9595leftObjects5= [];
gdjs.hats8Code.GDheroObjects1= [];
gdjs.hats8Code.GDheroObjects2= [];
gdjs.hats8Code.GDheroObjects3= [];
gdjs.hats8Code.GDheroObjects4= [];
gdjs.hats8Code.GDheroObjects5= [];
gdjs.hats8Code.GDsawObjects1= [];
gdjs.hats8Code.GDsawObjects2= [];
gdjs.hats8Code.GDsawObjects3= [];
gdjs.hats8Code.GDsawObjects4= [];
gdjs.hats8Code.GDsawObjects5= [];
gdjs.hats8Code.GDcoin_9595markerObjects1= [];
gdjs.hats8Code.GDcoin_9595markerObjects2= [];
gdjs.hats8Code.GDcoin_9595markerObjects3= [];
gdjs.hats8Code.GDcoin_9595markerObjects4= [];
gdjs.hats8Code.GDcoin_9595markerObjects5= [];
gdjs.hats8Code.GDcoin_9595marker2Objects1= [];
gdjs.hats8Code.GDcoin_9595marker2Objects2= [];
gdjs.hats8Code.GDcoin_9595marker2Objects3= [];
gdjs.hats8Code.GDcoin_9595marker2Objects4= [];
gdjs.hats8Code.GDcoin_9595marker2Objects5= [];
gdjs.hats8Code.GDcoinsObjects1= [];
gdjs.hats8Code.GDcoinsObjects2= [];
gdjs.hats8Code.GDcoinsObjects3= [];
gdjs.hats8Code.GDcoinsObjects4= [];
gdjs.hats8Code.GDcoinsObjects5= [];
gdjs.hats8Code.GDcoins2Objects1= [];
gdjs.hats8Code.GDcoins2Objects2= [];
gdjs.hats8Code.GDcoins2Objects3= [];
gdjs.hats8Code.GDcoins2Objects4= [];
gdjs.hats8Code.GDcoins2Objects5= [];
gdjs.hats8Code.GDkey_9595lockerObjects1= [];
gdjs.hats8Code.GDkey_9595lockerObjects2= [];
gdjs.hats8Code.GDkey_9595lockerObjects3= [];
gdjs.hats8Code.GDkey_9595lockerObjects4= [];
gdjs.hats8Code.GDkey_9595lockerObjects5= [];
gdjs.hats8Code.GDr_9595buttonObjects1= [];
gdjs.hats8Code.GDr_9595buttonObjects2= [];
gdjs.hats8Code.GDr_9595buttonObjects3= [];
gdjs.hats8Code.GDr_9595buttonObjects4= [];
gdjs.hats8Code.GDr_9595buttonObjects5= [];
gdjs.hats8Code.GDl_9595buttonObjects1= [];
gdjs.hats8Code.GDl_9595buttonObjects2= [];
gdjs.hats8Code.GDl_9595buttonObjects3= [];
gdjs.hats8Code.GDl_9595buttonObjects4= [];
gdjs.hats8Code.GDl_9595buttonObjects5= [];
gdjs.hats8Code.GDbackObjects1= [];
gdjs.hats8Code.GDbackObjects2= [];
gdjs.hats8Code.GDbackObjects3= [];
gdjs.hats8Code.GDbackObjects4= [];
gdjs.hats8Code.GDbackObjects5= [];
gdjs.hats8Code.GDlockObjects1= [];
gdjs.hats8Code.GDlockObjects2= [];
gdjs.hats8Code.GDlockObjects3= [];
gdjs.hats8Code.GDlockObjects4= [];
gdjs.hats8Code.GDlockObjects5= [];
gdjs.hats8Code.GDcamObjects1= [];
gdjs.hats8Code.GDcamObjects2= [];
gdjs.hats8Code.GDcamObjects3= [];
gdjs.hats8Code.GDcamObjects4= [];
gdjs.hats8Code.GDcamObjects5= [];
gdjs.hats8Code.GDfonikObjects1= [];
gdjs.hats8Code.GDfonikObjects2= [];
gdjs.hats8Code.GDfonikObjects3= [];
gdjs.hats8Code.GDfonikObjects4= [];
gdjs.hats8Code.GDfonikObjects5= [];


gdjs.hats8Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cam"), gdjs.hats8Code.GDcamObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.hats8Code.GDcamObjects2.length !== 0 ? gdjs.hats8Code.GDcamObjects2[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.hats8Code.GDcamObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDcamObjects2[i].hide();
}
}}

}


};gdjs.hats8Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.hats8Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}
{ //Subevents
gdjs.hats8Code.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDbackObjects3Objects = Hashtable.newFrom({"back": gdjs.hats8Code.GDbackObjects3});
gdjs.hats8Code.asyncCallback68268692 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}
gdjs.hats8Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.hats8Code.asyncCallback68268692(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDl_95959595buttonObjects3Objects = Hashtable.newFrom({"l_button": gdjs.hats8Code.GDl_9595buttonObjects3});
gdjs.hats8Code.asyncCallback68269876 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats7", false);
}}
gdjs.hats8Code.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.hats8Code.asyncCallback68269876(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDbackObjects4Objects = Hashtable.newFrom({"back": gdjs.hats8Code.GDbackObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDr_95959595buttonObjects4Objects = Hashtable.newFrom({"r_button": gdjs.hats8Code.GDr_9595buttonObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDl_95959595buttonObjects4Objects = Hashtable.newFrom({"l_button": gdjs.hats8Code.GDl_9595buttonObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDr_95959595buttonObjects2Objects = Hashtable.newFrom({"r_button": gdjs.hats8Code.GDr_9595buttonObjects2});
gdjs.hats8Code.asyncCallback68273772 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats9", false);
}}
gdjs.hats8Code.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.hats8Code.asyncCallback68273772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hats8Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hats8Code.GDbackObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDbackObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats8Code.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hats8Code.GDl_9595buttonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDl_95959595buttonObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats8Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.hats8Code.GDbackObjects3.length = 0;

gdjs.hats8Code.GDl_9595buttonObjects3.length = 0;

gdjs.hats8Code.GDr_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.hats8Code.GDbackObjects3_1final.length = 0;
gdjs.hats8Code.GDl_9595buttonObjects3_1final.length = 0;
gdjs.hats8Code.GDr_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hats8Code.GDbackObjects4);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDbackObjects4Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hats8Code.GDbackObjects4.length; j < jLen ; ++j) {
        if ( gdjs.hats8Code.GDbackObjects3_1final.indexOf(gdjs.hats8Code.GDbackObjects4[j]) === -1 )
            gdjs.hats8Code.GDbackObjects3_1final.push(gdjs.hats8Code.GDbackObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hats8Code.GDr_9595buttonObjects4);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDr_95959595buttonObjects4Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hats8Code.GDr_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.hats8Code.GDr_9595buttonObjects3_1final.indexOf(gdjs.hats8Code.GDr_9595buttonObjects4[j]) === -1 )
            gdjs.hats8Code.GDr_9595buttonObjects3_1final.push(gdjs.hats8Code.GDr_9595buttonObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hats8Code.GDl_9595buttonObjects4);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDl_95959595buttonObjects4Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hats8Code.GDl_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.hats8Code.GDl_9595buttonObjects3_1final.indexOf(gdjs.hats8Code.GDl_9595buttonObjects4[j]) === -1 )
            gdjs.hats8Code.GDl_9595buttonObjects3_1final.push(gdjs.hats8Code.GDl_9595buttonObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.hats8Code.GDbackObjects3_1final, gdjs.hats8Code.GDbackObjects3);
gdjs.copyArray(gdjs.hats8Code.GDl_9595buttonObjects3_1final, gdjs.hats8Code.GDl_9595buttonObjects3);
gdjs.copyArray(gdjs.hats8Code.GDr_9595buttonObjects3_1final, gdjs.hats8Code.GDr_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{

gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hats8Code.GDr_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDr_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats8Code.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68268028);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats8Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959564Objects3Objects = Hashtable.newFrom({"hat_64": gdjs.hats8Code.GDhat_959564Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959565Objects3Objects = Hashtable.newFrom({"hat_65": gdjs.hats8Code.GDhat_959565Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959566Objects3Objects = Hashtable.newFrom({"hat_66": gdjs.hats8Code.GDhat_959566Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959567Objects3Objects = Hashtable.newFrom({"hat_67": gdjs.hats8Code.GDhat_959567Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959568Objects3Objects = Hashtable.newFrom({"hat_68": gdjs.hats8Code.GDhat_959568Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959569Objects3Objects = Hashtable.newFrom({"hat_69": gdjs.hats8Code.GDhat_959569Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959570Objects3Objects = Hashtable.newFrom({"hat_70": gdjs.hats8Code.GDhat_959570Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959571Objects3Objects = Hashtable.newFrom({"hat_71": gdjs.hats8Code.GDhat_959571Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects2});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959572Objects2Objects = Hashtable.newFrom({"hat_72": gdjs.hats8Code.GDhat_959572Objects2});
gdjs.hats8Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_64"), gdjs.hats8Code.GDhat_959564Objects3);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959564Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_64");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDlockObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDlockObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDlockObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_65"), gdjs.hats8Code.GDhat_959565Objects3);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959565Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_65");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDlockObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDlockObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDlockObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_66"), gdjs.hats8Code.GDhat_959566Objects3);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959566Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_66");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDlockObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDlockObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDlockObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_67"), gdjs.hats8Code.GDhat_959567Objects3);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959567Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_67");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDlockObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDlockObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDlockObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_68"), gdjs.hats8Code.GDhat_959568Objects3);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959568Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_68");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDlockObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDlockObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDlockObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_69"), gdjs.hats8Code.GDhat_959569Objects3);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959569Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_69");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDlockObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDlockObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDlockObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_70"), gdjs.hats8Code.GDhat_959570Objects3);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959570Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_70");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDlockObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDlockObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDlockObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_71"), gdjs.hats8Code.GDhat_959571Objects3);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959571Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_71");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDlockObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDlockObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDlockObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_72"), gdjs.hats8Code.GDhat_959572Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects2Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959572Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_72");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats8Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.hats8Code.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats8Code.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDbuyObjects3Objects = Hashtable.newFrom({"buy": gdjs.hats8Code.GDbuyObjects3});
gdjs.hats8Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("key_locker"), gdjs.hats8Code.GDkey_9595lockerObjects4);
/* Reuse gdjs.hats8Code.GDlockObjects4 */
{for(var i = 0, len = gdjs.hats8Code.GDkey_9595lockerObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDkey_9595lockerObjects4[i].setPosition((( gdjs.hats8Code.GDlockObjects4.length === 0 ) ? 0 :gdjs.hats8Code.GDlockObjects4[0].getCenterXInScene()),(( gdjs.hats8Code.GDlockObjects4.length === 0 ) ? 0 :gdjs.hats8Code.GDlockObjects4[0].getCenterYInScene()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("buy"), gdjs.hats8Code.GDbuyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDbuyObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects3);
gdjs.copyArray(runtimeScene.getObjects("key_locker"), gdjs.hats8Code.GDkey_9595lockerObjects3);
{for(var i = 0, len = gdjs.hats8Code.GDkey_9595lockerObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDkey_9595lockerObjects3[i].setPosition(999,-(999));
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects3[i].setString("...");
}
}}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDbuyObjects3Objects = Hashtable.newFrom({"buy": gdjs.hats8Code.GDbuyObjects3});
gdjs.hats8Code.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats8Code.GDcoins2Objects4);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats8Code.GDcoins2Objects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcoins2Objects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats8Code.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats8Code.GDcoins2Objects4);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats8Code.GDcoins2Objects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcoins2Objects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats8Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats8Code.GDcoins2Objects4);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats8Code.GDcoins2Objects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcoins2Objects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats8Code.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats8Code.GDcoins2Objects4);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats8Code.GDcoins2Objects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcoins2Objects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats8Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats8Code.GDcoins2Objects4);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats8Code.GDcoins2Objects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcoins2Objects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats8Code.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats8Code.GDcoins2Objects4);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats8Code.GDcoins2Objects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcoins2Objects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats8Code.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats8Code.GDcoins2Objects4);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats8Code.GDcoins2Objects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcoins2Objects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats8Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats8Code.GDcoins2Objects4);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats8Code.GDcoins2Objects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcoins2Objects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats8Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats8Code.GDcoins2Objects4);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats8Code.GDcoins2Objects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcoins2Objects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats8Code.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 64;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats8Code.GDcostObjects3, gdjs.hats8Code.GDcostObjects4);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_64", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats8Code.GDcostObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats8Code.GDcostObjects4[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats8Code.eventsList11(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 65;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats8Code.GDcostObjects3, gdjs.hats8Code.GDcostObjects4);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_65", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats8Code.GDcostObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats8Code.GDcostObjects4[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats8Code.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 66;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats8Code.GDcostObjects3, gdjs.hats8Code.GDcostObjects4);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_66", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats8Code.GDcostObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats8Code.GDcostObjects4[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats8Code.eventsList13(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 67;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats8Code.GDcostObjects3, gdjs.hats8Code.GDcostObjects4);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_67", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats8Code.GDcostObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats8Code.GDcostObjects4[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats8Code.eventsList14(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 68;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats8Code.GDcostObjects3, gdjs.hats8Code.GDcostObjects4);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_68", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats8Code.GDcostObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats8Code.GDcostObjects4[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats8Code.eventsList15(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 69;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats8Code.GDcostObjects3, gdjs.hats8Code.GDcostObjects4);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_69", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats8Code.GDcostObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats8Code.GDcostObjects4[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats8Code.eventsList16(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 70;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats8Code.GDcostObjects3, gdjs.hats8Code.GDcostObjects4);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_70", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats8Code.GDcostObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats8Code.GDcostObjects4[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats8Code.eventsList17(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 71;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats8Code.GDcostObjects3, gdjs.hats8Code.GDcostObjects4);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_71", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats8Code.GDcostObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats8Code.GDcostObjects4[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats8Code.eventsList18(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 72;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats8Code.GDcostObjects3, gdjs.hats8Code.GDcostObjects4);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_72", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats8Code.GDcostObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats8Code.GDcostObjects4[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats8Code.eventsList19(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.hats8Code.GDcostObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects3[i].returnVariable(gdjs.hats8Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects3[i].returnVariable(gdjs.hats8Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setString("ok");
}
}}

}


};gdjs.hats8Code.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("buy"), gdjs.hats8Code.GDbuyObjects3);
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDbuyObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.hats8Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats8Code.GDcostObjects3[0].getVariables()).getFromIndex(0)));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats8Code.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959564Objects3Objects = Hashtable.newFrom({"hat_64": gdjs.hats8Code.GDhat_959564Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959564Objects4Objects = Hashtable.newFrom({"hat_64": gdjs.hats8Code.GDhat_959564Objects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959564Objects3Objects = Hashtable.newFrom({"hat_64": gdjs.hats8Code.GDhat_959564Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats8Code.GDhat_959564Objects3, gdjs.hats8Code.GDhat_959564Objects4);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959564Objects4Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects4);
{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].setString("30");
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].returnVariable(gdjs.hats8Code.GDcostObjects4[i].getVariables().getFromIndex(0)).setNumber(30);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(64);
}}

}


{

/* Reuse gdjs.hats8Code.GDhat_959564Objects3 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959564Objects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(64);
}}

}


};gdjs.hats8Code.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_64"), gdjs.hats8Code.GDhat_959564Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959564Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats8Code.GDtext_9595pickObjects3);
{for(var i = 0, len = gdjs.hats8Code.GDtext_9595pickObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDtext_9595pickObjects3[i].setString("сердитые бровки");
}
}
{ //Subevents
gdjs.hats8Code.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959565Objects3Objects = Hashtable.newFrom({"hat_65": gdjs.hats8Code.GDhat_959565Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959565Objects4Objects = Hashtable.newFrom({"hat_65": gdjs.hats8Code.GDhat_959565Objects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959565Objects3Objects = Hashtable.newFrom({"hat_65": gdjs.hats8Code.GDhat_959565Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats8Code.GDhat_959565Objects3, gdjs.hats8Code.GDhat_959565Objects4);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959565Objects4Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects4);
{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].setString("150");
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].returnVariable(gdjs.hats8Code.GDcostObjects4[i].getVariables().getFromIndex(0)).setNumber(150);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(65);
}}

}


{

/* Reuse gdjs.hats8Code.GDhat_959565Objects3 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959565Objects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(65);
}}

}


};gdjs.hats8Code.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_65"), gdjs.hats8Code.GDhat_959565Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959565Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats8Code.GDtext_9595pickObjects3);
{for(var i = 0, len = gdjs.hats8Code.GDtext_9595pickObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDtext_9595pickObjects3[i].setString("Телевизор на голову");
}
}
{ //Subevents
gdjs.hats8Code.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959566Objects3Objects = Hashtable.newFrom({"hat_66": gdjs.hats8Code.GDhat_959566Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959566Objects4Objects = Hashtable.newFrom({"hat_66": gdjs.hats8Code.GDhat_959566Objects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959566Objects3Objects = Hashtable.newFrom({"hat_66": gdjs.hats8Code.GDhat_959566Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats8Code.GDhat_959566Objects3, gdjs.hats8Code.GDhat_959566Objects4);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959566Objects4Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects4);
{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].setString("75");
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].returnVariable(gdjs.hats8Code.GDcostObjects4[i].getVariables().getFromIndex(0)).setNumber(75);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(66);
}}

}


{

/* Reuse gdjs.hats8Code.GDhat_959566Objects3 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959566Objects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(66);
}}

}


};gdjs.hats8Code.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_66"), gdjs.hats8Code.GDhat_959566Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959566Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats8Code.GDtext_9595pickObjects3);
{for(var i = 0, len = gdjs.hats8Code.GDtext_9595pickObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDtext_9595pickObjects3[i].setString("шлем подводника");
}
}
{ //Subevents
gdjs.hats8Code.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959567Objects3Objects = Hashtable.newFrom({"hat_67": gdjs.hats8Code.GDhat_959567Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959567Objects4Objects = Hashtable.newFrom({"hat_67": gdjs.hats8Code.GDhat_959567Objects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959567Objects3Objects = Hashtable.newFrom({"hat_67": gdjs.hats8Code.GDhat_959567Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats8Code.GDhat_959567Objects3, gdjs.hats8Code.GDhat_959567Objects4);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959567Objects4Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects4);
{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].setString("65");
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].returnVariable(gdjs.hats8Code.GDcostObjects4[i].getVariables().getFromIndex(0)).setNumber(65);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(67);
}}

}


{

/* Reuse gdjs.hats8Code.GDhat_959567Objects3 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959567Objects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(67);
}}

}


};gdjs.hats8Code.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_67"), gdjs.hats8Code.GDhat_959567Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959567Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats8Code.GDtext_9595pickObjects3);
{for(var i = 0, len = gdjs.hats8Code.GDtext_9595pickObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDtext_9595pickObjects3[i].setString("медвежья шляпа");
}
}
{ //Subevents
gdjs.hats8Code.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959568Objects3Objects = Hashtable.newFrom({"hat_68": gdjs.hats8Code.GDhat_959568Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959568Objects4Objects = Hashtable.newFrom({"hat_68": gdjs.hats8Code.GDhat_959568Objects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959568Objects3Objects = Hashtable.newFrom({"hat_68": gdjs.hats8Code.GDhat_959568Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats8Code.GDhat_959568Objects3, gdjs.hats8Code.GDhat_959568Objects4);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959568Objects4Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects4);
{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].setString("50");
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].returnVariable(gdjs.hats8Code.GDcostObjects4[i].getVariables().getFromIndex(0)).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(68);
}}

}


{

/* Reuse gdjs.hats8Code.GDhat_959568Objects3 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959568Objects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(68);
}}

}


};gdjs.hats8Code.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_68"), gdjs.hats8Code.GDhat_959568Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959568Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats8Code.GDtext_9595pickObjects3);
{for(var i = 0, len = gdjs.hats8Code.GDtext_9595pickObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDtext_9595pickObjects3[i].setString("лягушачья шляпа");
}
}
{ //Subevents
gdjs.hats8Code.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959569Objects3Objects = Hashtable.newFrom({"hat_69": gdjs.hats8Code.GDhat_959569Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959569Objects4Objects = Hashtable.newFrom({"hat_69": gdjs.hats8Code.GDhat_959569Objects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959569Objects3Objects = Hashtable.newFrom({"hat_69": gdjs.hats8Code.GDhat_959569Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.eventsList32 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats8Code.GDhat_959569Objects3, gdjs.hats8Code.GDhat_959569Objects4);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959569Objects4Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects4);
{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].setString("50");
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].returnVariable(gdjs.hats8Code.GDcostObjects4[i].getVariables().getFromIndex(0)).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(69);
}}

}


{

/* Reuse gdjs.hats8Code.GDhat_959569Objects3 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959569Objects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(69);
}}

}


};gdjs.hats8Code.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_69"), gdjs.hats8Code.GDhat_959569Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959569Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats8Code.GDtext_9595pickObjects3);
{for(var i = 0, len = gdjs.hats8Code.GDtext_9595pickObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDtext_9595pickObjects3[i].setString("шапка бойца");
}
}
{ //Subevents
gdjs.hats8Code.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959570Objects3Objects = Hashtable.newFrom({"hat_70": gdjs.hats8Code.GDhat_959570Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959570Objects4Objects = Hashtable.newFrom({"hat_70": gdjs.hats8Code.GDhat_959570Objects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959570Objects3Objects = Hashtable.newFrom({"hat_70": gdjs.hats8Code.GDhat_959570Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats8Code.GDhat_959570Objects3, gdjs.hats8Code.GDhat_959570Objects4);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959570Objects4Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects4);
{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].setString("60");
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].returnVariable(gdjs.hats8Code.GDcostObjects4[i].getVariables().getFromIndex(0)).setNumber(60);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(70);
}}

}


{

/* Reuse gdjs.hats8Code.GDhat_959570Objects3 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959570Objects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(70);
}}

}


};gdjs.hats8Code.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_70"), gdjs.hats8Code.GDhat_959570Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959570Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats8Code.GDtext_9595pickObjects3);
{for(var i = 0, len = gdjs.hats8Code.GDtext_9595pickObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDtext_9595pickObjects3[i].setString("лопаточный шлем");
}
}
{ //Subevents
gdjs.hats8Code.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959571Objects3Objects = Hashtable.newFrom({"hat_71": gdjs.hats8Code.GDhat_959571Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959571Objects4Objects = Hashtable.newFrom({"hat_71": gdjs.hats8Code.GDhat_959571Objects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects4});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959571Objects3Objects = Hashtable.newFrom({"hat_71": gdjs.hats8Code.GDhat_959571Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats8Code.GDhat_959571Objects3, gdjs.hats8Code.GDhat_959571Objects4);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959571Objects4Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects4);
{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].setString("40");
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects4.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects4[i].returnVariable(gdjs.hats8Code.GDcostObjects4[i].getVariables().getFromIndex(0)).setNumber(40);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(71);
}}

}


{

/* Reuse gdjs.hats8Code.GDhat_959571Objects3 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959571Objects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(71);
}}

}


};gdjs.hats8Code.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_71"), gdjs.hats8Code.GDhat_959571Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959571Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats8Code.GDtext_9595pickObjects3);
{for(var i = 0, len = gdjs.hats8Code.GDtext_9595pickObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDtext_9595pickObjects3[i].setString("смайлик B)");
}
}
{ //Subevents
gdjs.hats8Code.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959572Objects2Objects = Hashtable.newFrom({"hat_72": gdjs.hats8Code.GDhat_959572Objects2});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959572Objects3Objects = Hashtable.newFrom({"hat_72": gdjs.hats8Code.GDhat_959572Objects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects3});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959572Objects2Objects = Hashtable.newFrom({"hat_72": gdjs.hats8Code.GDhat_959572Objects2});
gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats8Code.GDlockObjects2});
gdjs.hats8Code.eventsList38 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats8Code.GDhat_959572Objects2, gdjs.hats8Code.GDhat_959572Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959572Objects3Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats8Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects3[i].setString("150");
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects3[i].returnVariable(gdjs.hats8Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(150);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(72);
}}

}


{

/* Reuse gdjs.hats8Code.GDhat_959572Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats8Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959572Objects2Objects, gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(72);
}}

}


};gdjs.hats8Code.eventsList39 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_72"), gdjs.hats8Code.GDhat_959572Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats8Code.mapOfGDgdjs_9546hats8Code_9546GDhat_9595959572Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats8Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats8Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDtext_9595pickObjects2[i].setString("паучья голова ::3");
}
}
{ //Subevents
gdjs.hats8Code.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.eventsList40 = function(runtimeScene) {

{


gdjs.hats8Code.eventsList10(runtimeScene);
}


{


gdjs.hats8Code.eventsList21(runtimeScene);
}


{


gdjs.hats8Code.eventsList23(runtimeScene);
}


{


gdjs.hats8Code.eventsList25(runtimeScene);
}


{


gdjs.hats8Code.eventsList27(runtimeScene);
}


{


gdjs.hats8Code.eventsList29(runtimeScene);
}


{


gdjs.hats8Code.eventsList31(runtimeScene);
}


{


gdjs.hats8Code.eventsList33(runtimeScene);
}


{


gdjs.hats8Code.eventsList35(runtimeScene);
}


{


gdjs.hats8Code.eventsList37(runtimeScene);
}


{


gdjs.hats8Code.eventsList39(runtimeScene);
}


};gdjs.hats8Code.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68294428);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats8Code.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.eventsList42 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hats8Code.GDbackObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hats8Code.GDbackObjects3.length;i<l;++i) {
    if ( gdjs.hats8Code.GDbackObjects3[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hats8Code.GDbackObjects3[k] = gdjs.hats8Code.GDbackObjects3[i];
        ++k;
    }
}
gdjs.hats8Code.GDbackObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68339708);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDbackObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDbackObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDbackObjects3[i].setAnimationName("back");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hats8Code.GDr_9595buttonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hats8Code.GDr_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.hats8Code.GDr_9595buttonObjects3[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hats8Code.GDr_9595buttonObjects3[k] = gdjs.hats8Code.GDr_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.hats8Code.GDr_9595buttonObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68340540);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDr_9595buttonObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDr_9595buttonObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDr_9595buttonObjects3[i].setAnimationName("r_button");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hats8Code.GDl_9595buttonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hats8Code.GDl_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.hats8Code.GDl_9595buttonObjects3[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hats8Code.GDl_9595buttonObjects3[k] = gdjs.hats8Code.GDl_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.hats8Code.GDl_9595buttonObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68341308);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats8Code.GDl_9595buttonObjects3 */
{for(var i = 0, len = gdjs.hats8Code.GDl_9595buttonObjects3.length ;i < len;++i) {
    gdjs.hats8Code.GDl_9595buttonObjects3[i].setAnimationName("l_button");
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.hats8Code.eventsList43 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 64;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_64"), gdjs.hats8Code.GDhat_959564Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats8Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats8Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDpickerObjects2[i].setPosition((( gdjs.hats8Code.GDhat_959564Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959564Objects2[0].getCenterXInScene()),(( gdjs.hats8Code.GDhat_959564Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959564Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 65;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_65"), gdjs.hats8Code.GDhat_959565Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats8Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats8Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDpickerObjects2[i].setPosition((( gdjs.hats8Code.GDhat_959565Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959565Objects2[0].getCenterXInScene()),(( gdjs.hats8Code.GDhat_959565Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959565Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 66;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_66"), gdjs.hats8Code.GDhat_959566Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats8Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats8Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDpickerObjects2[i].setPosition((( gdjs.hats8Code.GDhat_959566Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959566Objects2[0].getCenterXInScene()),(( gdjs.hats8Code.GDhat_959566Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959566Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 67;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_67"), gdjs.hats8Code.GDhat_959567Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats8Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats8Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDpickerObjects2[i].setPosition((( gdjs.hats8Code.GDhat_959567Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959567Objects2[0].getCenterXInScene()),(( gdjs.hats8Code.GDhat_959567Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959567Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 68;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_68"), gdjs.hats8Code.GDhat_959568Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats8Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats8Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDpickerObjects2[i].setPosition((( gdjs.hats8Code.GDhat_959568Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959568Objects2[0].getCenterXInScene()),(( gdjs.hats8Code.GDhat_959568Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959568Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 69;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_69"), gdjs.hats8Code.GDhat_959569Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats8Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats8Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDpickerObjects2[i].setPosition((( gdjs.hats8Code.GDhat_959569Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959569Objects2[0].getCenterXInScene()),(( gdjs.hats8Code.GDhat_959569Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959569Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 70;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_70"), gdjs.hats8Code.GDhat_959570Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats8Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats8Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDpickerObjects2[i].setPosition((( gdjs.hats8Code.GDhat_959570Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959570Objects2[0].getCenterXInScene()),(( gdjs.hats8Code.GDhat_959570Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959570Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 71;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_71"), gdjs.hats8Code.GDhat_959571Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats8Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats8Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDpickerObjects2[i].setPosition((( gdjs.hats8Code.GDhat_959571Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959571Objects2[0].getCenterXInScene()),(( gdjs.hats8Code.GDhat_959571Objects2.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959571Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 72;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_72"), gdjs.hats8Code.GDhat_959572Objects1);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats8Code.GDpickerObjects1);
{for(var i = 0, len = gdjs.hats8Code.GDpickerObjects1.length ;i < len;++i) {
    gdjs.hats8Code.GDpickerObjects1[i].setPosition((( gdjs.hats8Code.GDhat_959572Objects1.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959572Objects1[0].getCenterXInScene()),(( gdjs.hats8Code.GDhat_959572Objects1.length === 0 ) ? 0 :gdjs.hats8Code.GDhat_959572Objects1[0].getCenterYInScene()));
}
}}

}


};gdjs.hats8Code.eventsList44 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68343260);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats8Code.eventsList43(runtimeScene);} //End of subevents
}

}


};gdjs.hats8Code.eventsList45 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats8Code.GDcoins2Objects2);
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats8Code.GDcostObjects2);
{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "coin", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{for(var i = 0, len = gdjs.hats8Code.GDcoins2Objects2.length ;i < len;++i) {
    gdjs.hats8Code.GDcoins2Objects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}{for(var i = 0, len = gdjs.hats8Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats8Code.GDcostObjects2[i].returnVariable(gdjs.hats8Code.GDcostObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "hat", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
{ //Subevents
gdjs.hats8Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.hats8Code.eventsList2(runtimeScene);
}


{


gdjs.hats8Code.eventsList7(runtimeScene);
}


{


gdjs.hats8Code.eventsList9(runtimeScene);
}


{


gdjs.hats8Code.eventsList41(runtimeScene);
}


{



}


{


gdjs.hats8Code.eventsList42(runtimeScene);
}


{


gdjs.hats8Code.eventsList44(runtimeScene);
}


};gdjs.hats8Code.eventsList46 = function(runtimeScene) {

{


gdjs.hats8Code.eventsList45(runtimeScene);
}


};

gdjs.hats8Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.hats8Code.GDhat_95950Objects1.length = 0;
gdjs.hats8Code.GDhat_95950Objects2.length = 0;
gdjs.hats8Code.GDhat_95950Objects3.length = 0;
gdjs.hats8Code.GDhat_95950Objects4.length = 0;
gdjs.hats8Code.GDhat_95950Objects5.length = 0;
gdjs.hats8Code.GDhat_95951Objects1.length = 0;
gdjs.hats8Code.GDhat_95951Objects2.length = 0;
gdjs.hats8Code.GDhat_95951Objects3.length = 0;
gdjs.hats8Code.GDhat_95951Objects4.length = 0;
gdjs.hats8Code.GDhat_95951Objects5.length = 0;
gdjs.hats8Code.GDhat_95952Objects1.length = 0;
gdjs.hats8Code.GDhat_95952Objects2.length = 0;
gdjs.hats8Code.GDhat_95952Objects3.length = 0;
gdjs.hats8Code.GDhat_95952Objects4.length = 0;
gdjs.hats8Code.GDhat_95952Objects5.length = 0;
gdjs.hats8Code.GDhat_95953Objects1.length = 0;
gdjs.hats8Code.GDhat_95953Objects2.length = 0;
gdjs.hats8Code.GDhat_95953Objects3.length = 0;
gdjs.hats8Code.GDhat_95953Objects4.length = 0;
gdjs.hats8Code.GDhat_95953Objects5.length = 0;
gdjs.hats8Code.GDhat_95954Objects1.length = 0;
gdjs.hats8Code.GDhat_95954Objects2.length = 0;
gdjs.hats8Code.GDhat_95954Objects3.length = 0;
gdjs.hats8Code.GDhat_95954Objects4.length = 0;
gdjs.hats8Code.GDhat_95954Objects5.length = 0;
gdjs.hats8Code.GDhat_95955Objects1.length = 0;
gdjs.hats8Code.GDhat_95955Objects2.length = 0;
gdjs.hats8Code.GDhat_95955Objects3.length = 0;
gdjs.hats8Code.GDhat_95955Objects4.length = 0;
gdjs.hats8Code.GDhat_95955Objects5.length = 0;
gdjs.hats8Code.GDhat_95956Objects1.length = 0;
gdjs.hats8Code.GDhat_95956Objects2.length = 0;
gdjs.hats8Code.GDhat_95956Objects3.length = 0;
gdjs.hats8Code.GDhat_95956Objects4.length = 0;
gdjs.hats8Code.GDhat_95956Objects5.length = 0;
gdjs.hats8Code.GDhat_95957Objects1.length = 0;
gdjs.hats8Code.GDhat_95957Objects2.length = 0;
gdjs.hats8Code.GDhat_95957Objects3.length = 0;
gdjs.hats8Code.GDhat_95957Objects4.length = 0;
gdjs.hats8Code.GDhat_95957Objects5.length = 0;
gdjs.hats8Code.GDhat_95958Objects1.length = 0;
gdjs.hats8Code.GDhat_95958Objects2.length = 0;
gdjs.hats8Code.GDhat_95958Objects3.length = 0;
gdjs.hats8Code.GDhat_95958Objects4.length = 0;
gdjs.hats8Code.GDhat_95958Objects5.length = 0;
gdjs.hats8Code.GDhat_95959Objects1.length = 0;
gdjs.hats8Code.GDhat_95959Objects2.length = 0;
gdjs.hats8Code.GDhat_95959Objects3.length = 0;
gdjs.hats8Code.GDhat_95959Objects4.length = 0;
gdjs.hats8Code.GDhat_95959Objects5.length = 0;
gdjs.hats8Code.GDhat_959510Objects1.length = 0;
gdjs.hats8Code.GDhat_959510Objects2.length = 0;
gdjs.hats8Code.GDhat_959510Objects3.length = 0;
gdjs.hats8Code.GDhat_959510Objects4.length = 0;
gdjs.hats8Code.GDhat_959510Objects5.length = 0;
gdjs.hats8Code.GDhat_959511Objects1.length = 0;
gdjs.hats8Code.GDhat_959511Objects2.length = 0;
gdjs.hats8Code.GDhat_959511Objects3.length = 0;
gdjs.hats8Code.GDhat_959511Objects4.length = 0;
gdjs.hats8Code.GDhat_959511Objects5.length = 0;
gdjs.hats8Code.GDhat_959512Objects1.length = 0;
gdjs.hats8Code.GDhat_959512Objects2.length = 0;
gdjs.hats8Code.GDhat_959512Objects3.length = 0;
gdjs.hats8Code.GDhat_959512Objects4.length = 0;
gdjs.hats8Code.GDhat_959512Objects5.length = 0;
gdjs.hats8Code.GDhat_959513Objects1.length = 0;
gdjs.hats8Code.GDhat_959513Objects2.length = 0;
gdjs.hats8Code.GDhat_959513Objects3.length = 0;
gdjs.hats8Code.GDhat_959513Objects4.length = 0;
gdjs.hats8Code.GDhat_959513Objects5.length = 0;
gdjs.hats8Code.GDhat_959514Objects1.length = 0;
gdjs.hats8Code.GDhat_959514Objects2.length = 0;
gdjs.hats8Code.GDhat_959514Objects3.length = 0;
gdjs.hats8Code.GDhat_959514Objects4.length = 0;
gdjs.hats8Code.GDhat_959514Objects5.length = 0;
gdjs.hats8Code.GDhat_959515Objects1.length = 0;
gdjs.hats8Code.GDhat_959515Objects2.length = 0;
gdjs.hats8Code.GDhat_959515Objects3.length = 0;
gdjs.hats8Code.GDhat_959515Objects4.length = 0;
gdjs.hats8Code.GDhat_959515Objects5.length = 0;
gdjs.hats8Code.GDhat_959516Objects1.length = 0;
gdjs.hats8Code.GDhat_959516Objects2.length = 0;
gdjs.hats8Code.GDhat_959516Objects3.length = 0;
gdjs.hats8Code.GDhat_959516Objects4.length = 0;
gdjs.hats8Code.GDhat_959516Objects5.length = 0;
gdjs.hats8Code.GDhat_959517Objects1.length = 0;
gdjs.hats8Code.GDhat_959517Objects2.length = 0;
gdjs.hats8Code.GDhat_959517Objects3.length = 0;
gdjs.hats8Code.GDhat_959517Objects4.length = 0;
gdjs.hats8Code.GDhat_959517Objects5.length = 0;
gdjs.hats8Code.GDhat_959518Objects1.length = 0;
gdjs.hats8Code.GDhat_959518Objects2.length = 0;
gdjs.hats8Code.GDhat_959518Objects3.length = 0;
gdjs.hats8Code.GDhat_959518Objects4.length = 0;
gdjs.hats8Code.GDhat_959518Objects5.length = 0;
gdjs.hats8Code.GDhat_959555Objects1.length = 0;
gdjs.hats8Code.GDhat_959555Objects2.length = 0;
gdjs.hats8Code.GDhat_959555Objects3.length = 0;
gdjs.hats8Code.GDhat_959555Objects4.length = 0;
gdjs.hats8Code.GDhat_959555Objects5.length = 0;
gdjs.hats8Code.GDhat_959556Objects1.length = 0;
gdjs.hats8Code.GDhat_959556Objects2.length = 0;
gdjs.hats8Code.GDhat_959556Objects3.length = 0;
gdjs.hats8Code.GDhat_959556Objects4.length = 0;
gdjs.hats8Code.GDhat_959556Objects5.length = 0;
gdjs.hats8Code.GDhat_959557Objects1.length = 0;
gdjs.hats8Code.GDhat_959557Objects2.length = 0;
gdjs.hats8Code.GDhat_959557Objects3.length = 0;
gdjs.hats8Code.GDhat_959557Objects4.length = 0;
gdjs.hats8Code.GDhat_959557Objects5.length = 0;
gdjs.hats8Code.GDhat_959558Objects1.length = 0;
gdjs.hats8Code.GDhat_959558Objects2.length = 0;
gdjs.hats8Code.GDhat_959558Objects3.length = 0;
gdjs.hats8Code.GDhat_959558Objects4.length = 0;
gdjs.hats8Code.GDhat_959558Objects5.length = 0;
gdjs.hats8Code.GDhat_959559Objects1.length = 0;
gdjs.hats8Code.GDhat_959559Objects2.length = 0;
gdjs.hats8Code.GDhat_959559Objects3.length = 0;
gdjs.hats8Code.GDhat_959559Objects4.length = 0;
gdjs.hats8Code.GDhat_959559Objects5.length = 0;
gdjs.hats8Code.GDhat_959560Objects1.length = 0;
gdjs.hats8Code.GDhat_959560Objects2.length = 0;
gdjs.hats8Code.GDhat_959560Objects3.length = 0;
gdjs.hats8Code.GDhat_959560Objects4.length = 0;
gdjs.hats8Code.GDhat_959560Objects5.length = 0;
gdjs.hats8Code.GDhat_959561Objects1.length = 0;
gdjs.hats8Code.GDhat_959561Objects2.length = 0;
gdjs.hats8Code.GDhat_959561Objects3.length = 0;
gdjs.hats8Code.GDhat_959561Objects4.length = 0;
gdjs.hats8Code.GDhat_959561Objects5.length = 0;
gdjs.hats8Code.GDhat_959562Objects1.length = 0;
gdjs.hats8Code.GDhat_959562Objects2.length = 0;
gdjs.hats8Code.GDhat_959562Objects3.length = 0;
gdjs.hats8Code.GDhat_959562Objects4.length = 0;
gdjs.hats8Code.GDhat_959562Objects5.length = 0;
gdjs.hats8Code.GDhat_959563Objects1.length = 0;
gdjs.hats8Code.GDhat_959563Objects2.length = 0;
gdjs.hats8Code.GDhat_959563Objects3.length = 0;
gdjs.hats8Code.GDhat_959563Objects4.length = 0;
gdjs.hats8Code.GDhat_959563Objects5.length = 0;
gdjs.hats8Code.GDhat_959564Objects1.length = 0;
gdjs.hats8Code.GDhat_959564Objects2.length = 0;
gdjs.hats8Code.GDhat_959564Objects3.length = 0;
gdjs.hats8Code.GDhat_959564Objects4.length = 0;
gdjs.hats8Code.GDhat_959564Objects5.length = 0;
gdjs.hats8Code.GDhat_959565Objects1.length = 0;
gdjs.hats8Code.GDhat_959565Objects2.length = 0;
gdjs.hats8Code.GDhat_959565Objects3.length = 0;
gdjs.hats8Code.GDhat_959565Objects4.length = 0;
gdjs.hats8Code.GDhat_959565Objects5.length = 0;
gdjs.hats8Code.GDhat_959566Objects1.length = 0;
gdjs.hats8Code.GDhat_959566Objects2.length = 0;
gdjs.hats8Code.GDhat_959566Objects3.length = 0;
gdjs.hats8Code.GDhat_959566Objects4.length = 0;
gdjs.hats8Code.GDhat_959566Objects5.length = 0;
gdjs.hats8Code.GDhat_959567Objects1.length = 0;
gdjs.hats8Code.GDhat_959567Objects2.length = 0;
gdjs.hats8Code.GDhat_959567Objects3.length = 0;
gdjs.hats8Code.GDhat_959567Objects4.length = 0;
gdjs.hats8Code.GDhat_959567Objects5.length = 0;
gdjs.hats8Code.GDhat_959568Objects1.length = 0;
gdjs.hats8Code.GDhat_959568Objects2.length = 0;
gdjs.hats8Code.GDhat_959568Objects3.length = 0;
gdjs.hats8Code.GDhat_959568Objects4.length = 0;
gdjs.hats8Code.GDhat_959568Objects5.length = 0;
gdjs.hats8Code.GDhat_959569Objects1.length = 0;
gdjs.hats8Code.GDhat_959569Objects2.length = 0;
gdjs.hats8Code.GDhat_959569Objects3.length = 0;
gdjs.hats8Code.GDhat_959569Objects4.length = 0;
gdjs.hats8Code.GDhat_959569Objects5.length = 0;
gdjs.hats8Code.GDhat_959570Objects1.length = 0;
gdjs.hats8Code.GDhat_959570Objects2.length = 0;
gdjs.hats8Code.GDhat_959570Objects3.length = 0;
gdjs.hats8Code.GDhat_959570Objects4.length = 0;
gdjs.hats8Code.GDhat_959570Objects5.length = 0;
gdjs.hats8Code.GDhat_959571Objects1.length = 0;
gdjs.hats8Code.GDhat_959571Objects2.length = 0;
gdjs.hats8Code.GDhat_959571Objects3.length = 0;
gdjs.hats8Code.GDhat_959571Objects4.length = 0;
gdjs.hats8Code.GDhat_959571Objects5.length = 0;
gdjs.hats8Code.GDhat_959572Objects1.length = 0;
gdjs.hats8Code.GDhat_959572Objects2.length = 0;
gdjs.hats8Code.GDhat_959572Objects3.length = 0;
gdjs.hats8Code.GDhat_959572Objects4.length = 0;
gdjs.hats8Code.GDhat_959572Objects5.length = 0;
gdjs.hats8Code.GDhat_9595randomObjects1.length = 0;
gdjs.hats8Code.GDhat_9595randomObjects2.length = 0;
gdjs.hats8Code.GDhat_9595randomObjects3.length = 0;
gdjs.hats8Code.GDhat_9595randomObjects4.length = 0;
gdjs.hats8Code.GDhat_9595randomObjects5.length = 0;
gdjs.hats8Code.GDhat_9595dldoObjects1.length = 0;
gdjs.hats8Code.GDhat_9595dldoObjects2.length = 0;
gdjs.hats8Code.GDhat_9595dldoObjects3.length = 0;
gdjs.hats8Code.GDhat_9595dldoObjects4.length = 0;
gdjs.hats8Code.GDhat_9595dldoObjects5.length = 0;
gdjs.hats8Code.GDtext_9595pickObjects1.length = 0;
gdjs.hats8Code.GDtext_9595pickObjects2.length = 0;
gdjs.hats8Code.GDtext_9595pickObjects3.length = 0;
gdjs.hats8Code.GDtext_9595pickObjects4.length = 0;
gdjs.hats8Code.GDtext_9595pickObjects5.length = 0;
gdjs.hats8Code.GDbuyObjects1.length = 0;
gdjs.hats8Code.GDbuyObjects2.length = 0;
gdjs.hats8Code.GDbuyObjects3.length = 0;
gdjs.hats8Code.GDbuyObjects4.length = 0;
gdjs.hats8Code.GDbuyObjects5.length = 0;
gdjs.hats8Code.GDcostObjects1.length = 0;
gdjs.hats8Code.GDcostObjects2.length = 0;
gdjs.hats8Code.GDcostObjects3.length = 0;
gdjs.hats8Code.GDcostObjects4.length = 0;
gdjs.hats8Code.GDcostObjects5.length = 0;
gdjs.hats8Code.GDpickerObjects1.length = 0;
gdjs.hats8Code.GDpickerObjects2.length = 0;
gdjs.hats8Code.GDpickerObjects3.length = 0;
gdjs.hats8Code.GDpickerObjects4.length = 0;
gdjs.hats8Code.GDpickerObjects5.length = 0;
gdjs.hats8Code.GDcoin_9595marker_9595hatsObjects1.length = 0;
gdjs.hats8Code.GDcoin_9595marker_9595hatsObjects2.length = 0;
gdjs.hats8Code.GDcoin_9595marker_9595hatsObjects3.length = 0;
gdjs.hats8Code.GDcoin_9595marker_9595hatsObjects4.length = 0;
gdjs.hats8Code.GDcoin_9595marker_9595hatsObjects5.length = 0;
gdjs.hats8Code.GDgrass_9595blockObjects1.length = 0;
gdjs.hats8Code.GDgrass_9595blockObjects2.length = 0;
gdjs.hats8Code.GDgrass_9595blockObjects3.length = 0;
gdjs.hats8Code.GDgrass_9595blockObjects4.length = 0;
gdjs.hats8Code.GDgrass_9595blockObjects5.length = 0;
gdjs.hats8Code.GDblockObjects1.length = 0;
gdjs.hats8Code.GDblockObjects2.length = 0;
gdjs.hats8Code.GDblockObjects3.length = 0;
gdjs.hats8Code.GDblockObjects4.length = 0;
gdjs.hats8Code.GDblockObjects5.length = 0;
gdjs.hats8Code.GDmenuObjects1.length = 0;
gdjs.hats8Code.GDmenuObjects2.length = 0;
gdjs.hats8Code.GDmenuObjects3.length = 0;
gdjs.hats8Code.GDmenuObjects4.length = 0;
gdjs.hats8Code.GDmenuObjects5.length = 0;
gdjs.hats8Code.GDhomeObjects1.length = 0;
gdjs.hats8Code.GDhomeObjects2.length = 0;
gdjs.hats8Code.GDhomeObjects3.length = 0;
gdjs.hats8Code.GDhomeObjects4.length = 0;
gdjs.hats8Code.GDhomeObjects5.length = 0;
gdjs.hats8Code.GDresetObjects1.length = 0;
gdjs.hats8Code.GDresetObjects2.length = 0;
gdjs.hats8Code.GDresetObjects3.length = 0;
gdjs.hats8Code.GDresetObjects4.length = 0;
gdjs.hats8Code.GDresetObjects5.length = 0;
gdjs.hats8Code.GDspikeObjects1.length = 0;
gdjs.hats8Code.GDspikeObjects2.length = 0;
gdjs.hats8Code.GDspikeObjects3.length = 0;
gdjs.hats8Code.GDspikeObjects4.length = 0;
gdjs.hats8Code.GDspikeObjects5.length = 0;
gdjs.hats8Code.GDend_9595homeObjects1.length = 0;
gdjs.hats8Code.GDend_9595homeObjects2.length = 0;
gdjs.hats8Code.GDend_9595homeObjects3.length = 0;
gdjs.hats8Code.GDend_9595homeObjects4.length = 0;
gdjs.hats8Code.GDend_9595homeObjects5.length = 0;
gdjs.hats8Code.GDend_9595resetObjects1.length = 0;
gdjs.hats8Code.GDend_9595resetObjects2.length = 0;
gdjs.hats8Code.GDend_9595resetObjects3.length = 0;
gdjs.hats8Code.GDend_9595resetObjects4.length = 0;
gdjs.hats8Code.GDend_9595resetObjects5.length = 0;
gdjs.hats8Code.GDrobot_9595enemyObjects1.length = 0;
gdjs.hats8Code.GDrobot_9595enemyObjects2.length = 0;
gdjs.hats8Code.GDrobot_9595enemyObjects3.length = 0;
gdjs.hats8Code.GDrobot_9595enemyObjects4.length = 0;
gdjs.hats8Code.GDrobot_9595enemyObjects5.length = 0;
gdjs.hats8Code.GDslime_9595enemyObjects1.length = 0;
gdjs.hats8Code.GDslime_9595enemyObjects2.length = 0;
gdjs.hats8Code.GDslime_9595enemyObjects3.length = 0;
gdjs.hats8Code.GDslime_9595enemyObjects4.length = 0;
gdjs.hats8Code.GDslime_9595enemyObjects5.length = 0;
gdjs.hats8Code.GDrob_9595enemy_9595rightObjects1.length = 0;
gdjs.hats8Code.GDrob_9595enemy_9595rightObjects2.length = 0;
gdjs.hats8Code.GDrob_9595enemy_9595rightObjects3.length = 0;
gdjs.hats8Code.GDrob_9595enemy_9595rightObjects4.length = 0;
gdjs.hats8Code.GDrob_9595enemy_9595rightObjects5.length = 0;
gdjs.hats8Code.GDrob_9595enemy_9595leftObjects1.length = 0;
gdjs.hats8Code.GDrob_9595enemy_9595leftObjects2.length = 0;
gdjs.hats8Code.GDrob_9595enemy_9595leftObjects3.length = 0;
gdjs.hats8Code.GDrob_9595enemy_9595leftObjects4.length = 0;
gdjs.hats8Code.GDrob_9595enemy_9595leftObjects5.length = 0;
gdjs.hats8Code.GDheroObjects1.length = 0;
gdjs.hats8Code.GDheroObjects2.length = 0;
gdjs.hats8Code.GDheroObjects3.length = 0;
gdjs.hats8Code.GDheroObjects4.length = 0;
gdjs.hats8Code.GDheroObjects5.length = 0;
gdjs.hats8Code.GDsawObjects1.length = 0;
gdjs.hats8Code.GDsawObjects2.length = 0;
gdjs.hats8Code.GDsawObjects3.length = 0;
gdjs.hats8Code.GDsawObjects4.length = 0;
gdjs.hats8Code.GDsawObjects5.length = 0;
gdjs.hats8Code.GDcoin_9595markerObjects1.length = 0;
gdjs.hats8Code.GDcoin_9595markerObjects2.length = 0;
gdjs.hats8Code.GDcoin_9595markerObjects3.length = 0;
gdjs.hats8Code.GDcoin_9595markerObjects4.length = 0;
gdjs.hats8Code.GDcoin_9595markerObjects5.length = 0;
gdjs.hats8Code.GDcoin_9595marker2Objects1.length = 0;
gdjs.hats8Code.GDcoin_9595marker2Objects2.length = 0;
gdjs.hats8Code.GDcoin_9595marker2Objects3.length = 0;
gdjs.hats8Code.GDcoin_9595marker2Objects4.length = 0;
gdjs.hats8Code.GDcoin_9595marker2Objects5.length = 0;
gdjs.hats8Code.GDcoinsObjects1.length = 0;
gdjs.hats8Code.GDcoinsObjects2.length = 0;
gdjs.hats8Code.GDcoinsObjects3.length = 0;
gdjs.hats8Code.GDcoinsObjects4.length = 0;
gdjs.hats8Code.GDcoinsObjects5.length = 0;
gdjs.hats8Code.GDcoins2Objects1.length = 0;
gdjs.hats8Code.GDcoins2Objects2.length = 0;
gdjs.hats8Code.GDcoins2Objects3.length = 0;
gdjs.hats8Code.GDcoins2Objects4.length = 0;
gdjs.hats8Code.GDcoins2Objects5.length = 0;
gdjs.hats8Code.GDkey_9595lockerObjects1.length = 0;
gdjs.hats8Code.GDkey_9595lockerObjects2.length = 0;
gdjs.hats8Code.GDkey_9595lockerObjects3.length = 0;
gdjs.hats8Code.GDkey_9595lockerObjects4.length = 0;
gdjs.hats8Code.GDkey_9595lockerObjects5.length = 0;
gdjs.hats8Code.GDr_9595buttonObjects1.length = 0;
gdjs.hats8Code.GDr_9595buttonObjects2.length = 0;
gdjs.hats8Code.GDr_9595buttonObjects3.length = 0;
gdjs.hats8Code.GDr_9595buttonObjects4.length = 0;
gdjs.hats8Code.GDr_9595buttonObjects5.length = 0;
gdjs.hats8Code.GDl_9595buttonObjects1.length = 0;
gdjs.hats8Code.GDl_9595buttonObjects2.length = 0;
gdjs.hats8Code.GDl_9595buttonObjects3.length = 0;
gdjs.hats8Code.GDl_9595buttonObjects4.length = 0;
gdjs.hats8Code.GDl_9595buttonObjects5.length = 0;
gdjs.hats8Code.GDbackObjects1.length = 0;
gdjs.hats8Code.GDbackObjects2.length = 0;
gdjs.hats8Code.GDbackObjects3.length = 0;
gdjs.hats8Code.GDbackObjects4.length = 0;
gdjs.hats8Code.GDbackObjects5.length = 0;
gdjs.hats8Code.GDlockObjects1.length = 0;
gdjs.hats8Code.GDlockObjects2.length = 0;
gdjs.hats8Code.GDlockObjects3.length = 0;
gdjs.hats8Code.GDlockObjects4.length = 0;
gdjs.hats8Code.GDlockObjects5.length = 0;
gdjs.hats8Code.GDcamObjects1.length = 0;
gdjs.hats8Code.GDcamObjects2.length = 0;
gdjs.hats8Code.GDcamObjects3.length = 0;
gdjs.hats8Code.GDcamObjects4.length = 0;
gdjs.hats8Code.GDcamObjects5.length = 0;
gdjs.hats8Code.GDfonikObjects1.length = 0;
gdjs.hats8Code.GDfonikObjects2.length = 0;
gdjs.hats8Code.GDfonikObjects3.length = 0;
gdjs.hats8Code.GDfonikObjects4.length = 0;
gdjs.hats8Code.GDfonikObjects5.length = 0;

gdjs.hats8Code.eventsList46(runtimeScene);

return;

}

gdjs['hats8Code'] = gdjs.hats8Code;
