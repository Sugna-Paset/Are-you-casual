gdjs.menu_95chooseCode = {};
gdjs.menu_95chooseCode.GDNextLVLObjects1_1final = [];

gdjs.menu_95chooseCode.GDRandomObjects1_1final = [];

gdjs.menu_95chooseCode.GDRandomObjects1= [];
gdjs.menu_95chooseCode.GDRandomObjects2= [];
gdjs.menu_95chooseCode.GDRandomObjects3= [];
gdjs.menu_95chooseCode.GDNextLVLObjects1= [];
gdjs.menu_95chooseCode.GDNextLVLObjects2= [];
gdjs.menu_95chooseCode.GDNextLVLObjects3= [];
gdjs.menu_95chooseCode.GDnext_9595levelObjects1= [];
gdjs.menu_95chooseCode.GDnext_9595levelObjects2= [];
gdjs.menu_95chooseCode.GDnext_9595levelObjects3= [];
gdjs.menu_95chooseCode.GDrandom_9595levelObjects1= [];
gdjs.menu_95chooseCode.GDrandom_9595levelObjects2= [];
gdjs.menu_95chooseCode.GDrandom_9595levelObjects3= [];
gdjs.menu_95chooseCode.GDovalObjects1= [];
gdjs.menu_95chooseCode.GDovalObjects2= [];
gdjs.menu_95chooseCode.GDovalObjects3= [];
gdjs.menu_95chooseCode.GDgrass_9595blockObjects1= [];
gdjs.menu_95chooseCode.GDgrass_9595blockObjects2= [];
gdjs.menu_95chooseCode.GDgrass_9595blockObjects3= [];
gdjs.menu_95chooseCode.GDblockObjects1= [];
gdjs.menu_95chooseCode.GDblockObjects2= [];
gdjs.menu_95chooseCode.GDblockObjects3= [];
gdjs.menu_95chooseCode.GDmenuObjects1= [];
gdjs.menu_95chooseCode.GDmenuObjects2= [];
gdjs.menu_95chooseCode.GDmenuObjects3= [];
gdjs.menu_95chooseCode.GDhomeObjects1= [];
gdjs.menu_95chooseCode.GDhomeObjects2= [];
gdjs.menu_95chooseCode.GDhomeObjects3= [];
gdjs.menu_95chooseCode.GDresetObjects1= [];
gdjs.menu_95chooseCode.GDresetObjects2= [];
gdjs.menu_95chooseCode.GDresetObjects3= [];
gdjs.menu_95chooseCode.GDspikeObjects1= [];
gdjs.menu_95chooseCode.GDspikeObjects2= [];
gdjs.menu_95chooseCode.GDspikeObjects3= [];
gdjs.menu_95chooseCode.GDend_9595homeObjects1= [];
gdjs.menu_95chooseCode.GDend_9595homeObjects2= [];
gdjs.menu_95chooseCode.GDend_9595homeObjects3= [];
gdjs.menu_95chooseCode.GDend_9595resetObjects1= [];
gdjs.menu_95chooseCode.GDend_9595resetObjects2= [];
gdjs.menu_95chooseCode.GDend_9595resetObjects3= [];
gdjs.menu_95chooseCode.GDrobot_9595enemyObjects1= [];
gdjs.menu_95chooseCode.GDrobot_9595enemyObjects2= [];
gdjs.menu_95chooseCode.GDrobot_9595enemyObjects3= [];
gdjs.menu_95chooseCode.GDslime_9595enemyObjects1= [];
gdjs.menu_95chooseCode.GDslime_9595enemyObjects2= [];
gdjs.menu_95chooseCode.GDslime_9595enemyObjects3= [];
gdjs.menu_95chooseCode.GDrob_9595enemy_9595rightObjects1= [];
gdjs.menu_95chooseCode.GDrob_9595enemy_9595rightObjects2= [];
gdjs.menu_95chooseCode.GDrob_9595enemy_9595rightObjects3= [];
gdjs.menu_95chooseCode.GDrob_9595enemy_9595leftObjects1= [];
gdjs.menu_95chooseCode.GDrob_9595enemy_9595leftObjects2= [];
gdjs.menu_95chooseCode.GDrob_9595enemy_9595leftObjects3= [];
gdjs.menu_95chooseCode.GDheroObjects1= [];
gdjs.menu_95chooseCode.GDheroObjects2= [];
gdjs.menu_95chooseCode.GDheroObjects3= [];
gdjs.menu_95chooseCode.GDsawObjects1= [];
gdjs.menu_95chooseCode.GDsawObjects2= [];
gdjs.menu_95chooseCode.GDsawObjects3= [];
gdjs.menu_95chooseCode.GDcoin_9595markerObjects1= [];
gdjs.menu_95chooseCode.GDcoin_9595markerObjects2= [];
gdjs.menu_95chooseCode.GDcoin_9595markerObjects3= [];
gdjs.menu_95chooseCode.GDcoin_9595marker2Objects1= [];
gdjs.menu_95chooseCode.GDcoin_9595marker2Objects2= [];
gdjs.menu_95chooseCode.GDcoin_9595marker2Objects3= [];
gdjs.menu_95chooseCode.GDcoinsObjects1= [];
gdjs.menu_95chooseCode.GDcoinsObjects2= [];
gdjs.menu_95chooseCode.GDcoinsObjects3= [];
gdjs.menu_95chooseCode.GDcoins2Objects1= [];
gdjs.menu_95chooseCode.GDcoins2Objects2= [];
gdjs.menu_95chooseCode.GDcoins2Objects3= [];
gdjs.menu_95chooseCode.GDkey_9595lockerObjects1= [];
gdjs.menu_95chooseCode.GDkey_9595lockerObjects2= [];
gdjs.menu_95chooseCode.GDkey_9595lockerObjects3= [];
gdjs.menu_95chooseCode.GDr_9595buttonObjects1= [];
gdjs.menu_95chooseCode.GDr_9595buttonObjects2= [];
gdjs.menu_95chooseCode.GDr_9595buttonObjects3= [];
gdjs.menu_95chooseCode.GDl_9595buttonObjects1= [];
gdjs.menu_95chooseCode.GDl_9595buttonObjects2= [];
gdjs.menu_95chooseCode.GDl_9595buttonObjects3= [];
gdjs.menu_95chooseCode.GDbackObjects1= [];
gdjs.menu_95chooseCode.GDbackObjects2= [];
gdjs.menu_95chooseCode.GDbackObjects3= [];
gdjs.menu_95chooseCode.GDlockObjects1= [];
gdjs.menu_95chooseCode.GDlockObjects2= [];
gdjs.menu_95chooseCode.GDlockObjects3= [];
gdjs.menu_95chooseCode.GDcamObjects1= [];
gdjs.menu_95chooseCode.GDcamObjects2= [];
gdjs.menu_95chooseCode.GDcamObjects3= [];
gdjs.menu_95chooseCode.GDfonikObjects1= [];
gdjs.menu_95chooseCode.GDfonikObjects2= [];
gdjs.menu_95chooseCode.GDfonikObjects3= [];


gdjs.menu_95chooseCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cam"), gdjs.menu_95chooseCode.GDcamObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.menu_95chooseCode.GDcamObjects2.length !== 0 ? gdjs.menu_95chooseCode.GDcamObjects2[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.menu_95chooseCode.GDcamObjects2.length ;i < len;++i) {
    gdjs.menu_95chooseCode.GDcamObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.storage.elementExistsInJSONFile("storage", "level"));
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "level", 3);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "level");
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "level", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}}

}


};gdjs.menu_95chooseCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.menu_95chooseCode.mapOfGDgdjs_9546menu_959595chooseCode_9546GDNextLVLObjects2Objects = Hashtable.newFrom({"NextLVL": gdjs.menu_95chooseCode.GDNextLVLObjects2});
gdjs.menu_95chooseCode.mapOfGDgdjs_9546menu_959595chooseCode_9546GDRandomObjects2Objects = Hashtable.newFrom({"Random": gdjs.menu_95chooseCode.GDRandomObjects2});
gdjs.menu_95chooseCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}
{ //Subevents
gdjs.menu_95chooseCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{

gdjs.menu_95chooseCode.GDNextLVLObjects1.length = 0;

gdjs.menu_95chooseCode.GDRandomObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.menu_95chooseCode.GDNextLVLObjects1_1final.length = 0;
gdjs.menu_95chooseCode.GDRandomObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NextLVL"), gdjs.menu_95chooseCode.GDNextLVLObjects2);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.menu_95chooseCode.mapOfGDgdjs_9546menu_959595chooseCode_9546GDNextLVLObjects2Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.menu_95chooseCode.GDNextLVLObjects2.length; j < jLen ; ++j) {
        if ( gdjs.menu_95chooseCode.GDNextLVLObjects1_1final.indexOf(gdjs.menu_95chooseCode.GDNextLVLObjects2[j]) === -1 )
            gdjs.menu_95chooseCode.GDNextLVLObjects1_1final.push(gdjs.menu_95chooseCode.GDNextLVLObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Random"), gdjs.menu_95chooseCode.GDRandomObjects2);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.menu_95chooseCode.mapOfGDgdjs_9546menu_959595chooseCode_9546GDRandomObjects2Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.menu_95chooseCode.GDRandomObjects2.length; j < jLen ; ++j) {
        if ( gdjs.menu_95chooseCode.GDRandomObjects1_1final.indexOf(gdjs.menu_95chooseCode.GDRandomObjects2[j]) === -1 )
            gdjs.menu_95chooseCode.GDRandomObjects1_1final.push(gdjs.menu_95chooseCode.GDRandomObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.menu_95chooseCode.GDNextLVLObjects1_1final, gdjs.menu_95chooseCode.GDNextLVLObjects1);
gdjs.copyArray(gdjs.menu_95chooseCode.GDRandomObjects1_1final, gdjs.menu_95chooseCode.GDRandomObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68647500);
}
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.menu_95chooseCode.asyncCallback68650068 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "test2", false);
}}
gdjs.menu_95chooseCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.menu_95chooseCode.asyncCallback68650068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.menu_95chooseCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.menu_95chooseCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.menu_95chooseCode.asyncCallback68659668 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "test2", false);
}}
gdjs.menu_95chooseCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.menu_95chooseCode.asyncCallback68659668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.menu_95chooseCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.menu_95chooseCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.menu_95chooseCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Random"), gdjs.menu_95chooseCode.GDRandomObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.menu_95chooseCode.GDRandomObjects2.length;i<l;++i) {
    if ( gdjs.menu_95chooseCode.GDRandomObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.menu_95chooseCode.GDRandomObjects2[k] = gdjs.menu_95chooseCode.GDRandomObjects2[i];
        ++k;
    }
}
gdjs.menu_95chooseCode.GDRandomObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68648836);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.menu_95chooseCode.GDRandomObjects2 */
{for(var i = 0, len = gdjs.menu_95chooseCode.GDRandomObjects2.length ;i < len;++i) {
    gdjs.menu_95chooseCode.GDRandomObjects2[i].setAnimationName("Random");
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).setString("random");
}
{ //Subevents
gdjs.menu_95chooseCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NextLVL"), gdjs.menu_95chooseCode.GDNextLVLObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.menu_95chooseCode.GDNextLVLObjects1.length;i<l;++i) {
    if ( gdjs.menu_95chooseCode.GDNextLVLObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.menu_95chooseCode.GDNextLVLObjects1[k] = gdjs.menu_95chooseCode.GDNextLVLObjects1[i];
        ++k;
    }
}
gdjs.menu_95chooseCode.GDNextLVLObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68651124);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.menu_95chooseCode.GDNextLVLObjects1 */
{for(var i = 0, len = gdjs.menu_95chooseCode.GDNextLVLObjects1.length ;i < len;++i) {
    gdjs.menu_95chooseCode.GDNextLVLObjects1[i].setAnimationName("NextLVL");
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).setString("next");
}
{ //Subevents
gdjs.menu_95chooseCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.menu_95chooseCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.menu_95chooseCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("oval"), gdjs.menu_95chooseCode.GDovalObjects1);
{for(var i = 0, len = gdjs.menu_95chooseCode.GDovalObjects1.length ;i < len;++i) {
    gdjs.menu_95chooseCode.GDovalObjects1[i].rotate(50, runtimeScene);
}
}}

}


{


gdjs.menu_95chooseCode.eventsList2(runtimeScene);
}


{


gdjs.menu_95chooseCode.eventsList7(runtimeScene);
}


{



}


};

gdjs.menu_95chooseCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.menu_95chooseCode.GDRandomObjects1.length = 0;
gdjs.menu_95chooseCode.GDRandomObjects2.length = 0;
gdjs.menu_95chooseCode.GDRandomObjects3.length = 0;
gdjs.menu_95chooseCode.GDNextLVLObjects1.length = 0;
gdjs.menu_95chooseCode.GDNextLVLObjects2.length = 0;
gdjs.menu_95chooseCode.GDNextLVLObjects3.length = 0;
gdjs.menu_95chooseCode.GDnext_9595levelObjects1.length = 0;
gdjs.menu_95chooseCode.GDnext_9595levelObjects2.length = 0;
gdjs.menu_95chooseCode.GDnext_9595levelObjects3.length = 0;
gdjs.menu_95chooseCode.GDrandom_9595levelObjects1.length = 0;
gdjs.menu_95chooseCode.GDrandom_9595levelObjects2.length = 0;
gdjs.menu_95chooseCode.GDrandom_9595levelObjects3.length = 0;
gdjs.menu_95chooseCode.GDovalObjects1.length = 0;
gdjs.menu_95chooseCode.GDovalObjects2.length = 0;
gdjs.menu_95chooseCode.GDovalObjects3.length = 0;
gdjs.menu_95chooseCode.GDgrass_9595blockObjects1.length = 0;
gdjs.menu_95chooseCode.GDgrass_9595blockObjects2.length = 0;
gdjs.menu_95chooseCode.GDgrass_9595blockObjects3.length = 0;
gdjs.menu_95chooseCode.GDblockObjects1.length = 0;
gdjs.menu_95chooseCode.GDblockObjects2.length = 0;
gdjs.menu_95chooseCode.GDblockObjects3.length = 0;
gdjs.menu_95chooseCode.GDmenuObjects1.length = 0;
gdjs.menu_95chooseCode.GDmenuObjects2.length = 0;
gdjs.menu_95chooseCode.GDmenuObjects3.length = 0;
gdjs.menu_95chooseCode.GDhomeObjects1.length = 0;
gdjs.menu_95chooseCode.GDhomeObjects2.length = 0;
gdjs.menu_95chooseCode.GDhomeObjects3.length = 0;
gdjs.menu_95chooseCode.GDresetObjects1.length = 0;
gdjs.menu_95chooseCode.GDresetObjects2.length = 0;
gdjs.menu_95chooseCode.GDresetObjects3.length = 0;
gdjs.menu_95chooseCode.GDspikeObjects1.length = 0;
gdjs.menu_95chooseCode.GDspikeObjects2.length = 0;
gdjs.menu_95chooseCode.GDspikeObjects3.length = 0;
gdjs.menu_95chooseCode.GDend_9595homeObjects1.length = 0;
gdjs.menu_95chooseCode.GDend_9595homeObjects2.length = 0;
gdjs.menu_95chooseCode.GDend_9595homeObjects3.length = 0;
gdjs.menu_95chooseCode.GDend_9595resetObjects1.length = 0;
gdjs.menu_95chooseCode.GDend_9595resetObjects2.length = 0;
gdjs.menu_95chooseCode.GDend_9595resetObjects3.length = 0;
gdjs.menu_95chooseCode.GDrobot_9595enemyObjects1.length = 0;
gdjs.menu_95chooseCode.GDrobot_9595enemyObjects2.length = 0;
gdjs.menu_95chooseCode.GDrobot_9595enemyObjects3.length = 0;
gdjs.menu_95chooseCode.GDslime_9595enemyObjects1.length = 0;
gdjs.menu_95chooseCode.GDslime_9595enemyObjects2.length = 0;
gdjs.menu_95chooseCode.GDslime_9595enemyObjects3.length = 0;
gdjs.menu_95chooseCode.GDrob_9595enemy_9595rightObjects1.length = 0;
gdjs.menu_95chooseCode.GDrob_9595enemy_9595rightObjects2.length = 0;
gdjs.menu_95chooseCode.GDrob_9595enemy_9595rightObjects3.length = 0;
gdjs.menu_95chooseCode.GDrob_9595enemy_9595leftObjects1.length = 0;
gdjs.menu_95chooseCode.GDrob_9595enemy_9595leftObjects2.length = 0;
gdjs.menu_95chooseCode.GDrob_9595enemy_9595leftObjects3.length = 0;
gdjs.menu_95chooseCode.GDheroObjects1.length = 0;
gdjs.menu_95chooseCode.GDheroObjects2.length = 0;
gdjs.menu_95chooseCode.GDheroObjects3.length = 0;
gdjs.menu_95chooseCode.GDsawObjects1.length = 0;
gdjs.menu_95chooseCode.GDsawObjects2.length = 0;
gdjs.menu_95chooseCode.GDsawObjects3.length = 0;
gdjs.menu_95chooseCode.GDcoin_9595markerObjects1.length = 0;
gdjs.menu_95chooseCode.GDcoin_9595markerObjects2.length = 0;
gdjs.menu_95chooseCode.GDcoin_9595markerObjects3.length = 0;
gdjs.menu_95chooseCode.GDcoin_9595marker2Objects1.length = 0;
gdjs.menu_95chooseCode.GDcoin_9595marker2Objects2.length = 0;
gdjs.menu_95chooseCode.GDcoin_9595marker2Objects3.length = 0;
gdjs.menu_95chooseCode.GDcoinsObjects1.length = 0;
gdjs.menu_95chooseCode.GDcoinsObjects2.length = 0;
gdjs.menu_95chooseCode.GDcoinsObjects3.length = 0;
gdjs.menu_95chooseCode.GDcoins2Objects1.length = 0;
gdjs.menu_95chooseCode.GDcoins2Objects2.length = 0;
gdjs.menu_95chooseCode.GDcoins2Objects3.length = 0;
gdjs.menu_95chooseCode.GDkey_9595lockerObjects1.length = 0;
gdjs.menu_95chooseCode.GDkey_9595lockerObjects2.length = 0;
gdjs.menu_95chooseCode.GDkey_9595lockerObjects3.length = 0;
gdjs.menu_95chooseCode.GDr_9595buttonObjects1.length = 0;
gdjs.menu_95chooseCode.GDr_9595buttonObjects2.length = 0;
gdjs.menu_95chooseCode.GDr_9595buttonObjects3.length = 0;
gdjs.menu_95chooseCode.GDl_9595buttonObjects1.length = 0;
gdjs.menu_95chooseCode.GDl_9595buttonObjects2.length = 0;
gdjs.menu_95chooseCode.GDl_9595buttonObjects3.length = 0;
gdjs.menu_95chooseCode.GDbackObjects1.length = 0;
gdjs.menu_95chooseCode.GDbackObjects2.length = 0;
gdjs.menu_95chooseCode.GDbackObjects3.length = 0;
gdjs.menu_95chooseCode.GDlockObjects1.length = 0;
gdjs.menu_95chooseCode.GDlockObjects2.length = 0;
gdjs.menu_95chooseCode.GDlockObjects3.length = 0;
gdjs.menu_95chooseCode.GDcamObjects1.length = 0;
gdjs.menu_95chooseCode.GDcamObjects2.length = 0;
gdjs.menu_95chooseCode.GDcamObjects3.length = 0;
gdjs.menu_95chooseCode.GDfonikObjects1.length = 0;
gdjs.menu_95chooseCode.GDfonikObjects2.length = 0;
gdjs.menu_95chooseCode.GDfonikObjects3.length = 0;

gdjs.menu_95chooseCode.eventsList8(runtimeScene);

return;

}

gdjs['menu_95chooseCode'] = gdjs.menu_95chooseCode;
