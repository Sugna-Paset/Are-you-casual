gdjs.scene0Code = {};
gdjs.scene0Code.GDADD_9595TEXTIKObjects1= [];
gdjs.scene0Code.GDADD_9595TEXTIKObjects2= [];
gdjs.scene0Code.GDgrass_9595blockObjects1= [];
gdjs.scene0Code.GDgrass_9595blockObjects2= [];
gdjs.scene0Code.GDblockObjects1= [];
gdjs.scene0Code.GDblockObjects2= [];
gdjs.scene0Code.GDmenuObjects1= [];
gdjs.scene0Code.GDmenuObjects2= [];
gdjs.scene0Code.GDhomeObjects1= [];
gdjs.scene0Code.GDhomeObjects2= [];
gdjs.scene0Code.GDresetObjects1= [];
gdjs.scene0Code.GDresetObjects2= [];
gdjs.scene0Code.GDspikeObjects1= [];
gdjs.scene0Code.GDspikeObjects2= [];
gdjs.scene0Code.GDend_9595homeObjects1= [];
gdjs.scene0Code.GDend_9595homeObjects2= [];
gdjs.scene0Code.GDend_9595resetObjects1= [];
gdjs.scene0Code.GDend_9595resetObjects2= [];
gdjs.scene0Code.GDrobot_9595enemyObjects1= [];
gdjs.scene0Code.GDrobot_9595enemyObjects2= [];
gdjs.scene0Code.GDslime_9595enemyObjects1= [];
gdjs.scene0Code.GDslime_9595enemyObjects2= [];
gdjs.scene0Code.GDrob_9595enemy_9595rightObjects1= [];
gdjs.scene0Code.GDrob_9595enemy_9595rightObjects2= [];
gdjs.scene0Code.GDrob_9595enemy_9595leftObjects1= [];
gdjs.scene0Code.GDrob_9595enemy_9595leftObjects2= [];
gdjs.scene0Code.GDheroObjects1= [];
gdjs.scene0Code.GDheroObjects2= [];
gdjs.scene0Code.GDsawObjects1= [];
gdjs.scene0Code.GDsawObjects2= [];
gdjs.scene0Code.GDcoin_9595markerObjects1= [];
gdjs.scene0Code.GDcoin_9595markerObjects2= [];
gdjs.scene0Code.GDcoin_9595marker2Objects1= [];
gdjs.scene0Code.GDcoin_9595marker2Objects2= [];
gdjs.scene0Code.GDcoinsObjects1= [];
gdjs.scene0Code.GDcoinsObjects2= [];
gdjs.scene0Code.GDcoins2Objects1= [];
gdjs.scene0Code.GDcoins2Objects2= [];
gdjs.scene0Code.GDkey_9595lockerObjects1= [];
gdjs.scene0Code.GDkey_9595lockerObjects2= [];
gdjs.scene0Code.GDr_9595buttonObjects1= [];
gdjs.scene0Code.GDr_9595buttonObjects2= [];
gdjs.scene0Code.GDl_9595buttonObjects1= [];
gdjs.scene0Code.GDl_9595buttonObjects2= [];
gdjs.scene0Code.GDbackObjects1= [];
gdjs.scene0Code.GDbackObjects2= [];
gdjs.scene0Code.GDlockObjects1= [];
gdjs.scene0Code.GDlockObjects2= [];
gdjs.scene0Code.GDcamObjects1= [];
gdjs.scene0Code.GDcamObjects2= [];
gdjs.scene0Code.GDfonikObjects1= [];
gdjs.scene0Code.GDfonikObjects2= [];


gdjs.scene0Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtsExt__YandexGamesSDK__Init.func(runtimeScene, false, "portrait", false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "HolizonaCCO_DayDreams2.mp3");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__YandexGamesSDK__Initialized.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{gdjs.evtsExt__YandexGamesSDK__ShowInterstitialAd.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.scene0Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.scene0Code.GDADD_9595TEXTIKObjects1.length = 0;
gdjs.scene0Code.GDADD_9595TEXTIKObjects2.length = 0;
gdjs.scene0Code.GDgrass_9595blockObjects1.length = 0;
gdjs.scene0Code.GDgrass_9595blockObjects2.length = 0;
gdjs.scene0Code.GDblockObjects1.length = 0;
gdjs.scene0Code.GDblockObjects2.length = 0;
gdjs.scene0Code.GDmenuObjects1.length = 0;
gdjs.scene0Code.GDmenuObjects2.length = 0;
gdjs.scene0Code.GDhomeObjects1.length = 0;
gdjs.scene0Code.GDhomeObjects2.length = 0;
gdjs.scene0Code.GDresetObjects1.length = 0;
gdjs.scene0Code.GDresetObjects2.length = 0;
gdjs.scene0Code.GDspikeObjects1.length = 0;
gdjs.scene0Code.GDspikeObjects2.length = 0;
gdjs.scene0Code.GDend_9595homeObjects1.length = 0;
gdjs.scene0Code.GDend_9595homeObjects2.length = 0;
gdjs.scene0Code.GDend_9595resetObjects1.length = 0;
gdjs.scene0Code.GDend_9595resetObjects2.length = 0;
gdjs.scene0Code.GDrobot_9595enemyObjects1.length = 0;
gdjs.scene0Code.GDrobot_9595enemyObjects2.length = 0;
gdjs.scene0Code.GDslime_9595enemyObjects1.length = 0;
gdjs.scene0Code.GDslime_9595enemyObjects2.length = 0;
gdjs.scene0Code.GDrob_9595enemy_9595rightObjects1.length = 0;
gdjs.scene0Code.GDrob_9595enemy_9595rightObjects2.length = 0;
gdjs.scene0Code.GDrob_9595enemy_9595leftObjects1.length = 0;
gdjs.scene0Code.GDrob_9595enemy_9595leftObjects2.length = 0;
gdjs.scene0Code.GDheroObjects1.length = 0;
gdjs.scene0Code.GDheroObjects2.length = 0;
gdjs.scene0Code.GDsawObjects1.length = 0;
gdjs.scene0Code.GDsawObjects2.length = 0;
gdjs.scene0Code.GDcoin_9595markerObjects1.length = 0;
gdjs.scene0Code.GDcoin_9595markerObjects2.length = 0;
gdjs.scene0Code.GDcoin_9595marker2Objects1.length = 0;
gdjs.scene0Code.GDcoin_9595marker2Objects2.length = 0;
gdjs.scene0Code.GDcoinsObjects1.length = 0;
gdjs.scene0Code.GDcoinsObjects2.length = 0;
gdjs.scene0Code.GDcoins2Objects1.length = 0;
gdjs.scene0Code.GDcoins2Objects2.length = 0;
gdjs.scene0Code.GDkey_9595lockerObjects1.length = 0;
gdjs.scene0Code.GDkey_9595lockerObjects2.length = 0;
gdjs.scene0Code.GDr_9595buttonObjects1.length = 0;
gdjs.scene0Code.GDr_9595buttonObjects2.length = 0;
gdjs.scene0Code.GDl_9595buttonObjects1.length = 0;
gdjs.scene0Code.GDl_9595buttonObjects2.length = 0;
gdjs.scene0Code.GDbackObjects1.length = 0;
gdjs.scene0Code.GDbackObjects2.length = 0;
gdjs.scene0Code.GDlockObjects1.length = 0;
gdjs.scene0Code.GDlockObjects2.length = 0;
gdjs.scene0Code.GDcamObjects1.length = 0;
gdjs.scene0Code.GDcamObjects2.length = 0;
gdjs.scene0Code.GDfonikObjects1.length = 0;
gdjs.scene0Code.GDfonikObjects2.length = 0;

gdjs.scene0Code.eventsList0(runtimeScene);

return;

}

gdjs['scene0Code'] = gdjs.scene0Code;
