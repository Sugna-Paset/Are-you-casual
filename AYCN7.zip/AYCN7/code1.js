gdjs.menuCode = {};
gdjs.menuCode.GDskin1Objects1= [];
gdjs.menuCode.GDskin1Objects2= [];
gdjs.menuCode.GDskin1Objects3= [];
gdjs.menuCode.GDskin1Objects4= [];
gdjs.menuCode.GDskin1Objects5= [];
gdjs.menuCode.GDmenutwxtObjects1= [];
gdjs.menuCode.GDmenutwxtObjects2= [];
gdjs.menuCode.GDmenutwxtObjects3= [];
gdjs.menuCode.GDmenutwxtObjects4= [];
gdjs.menuCode.GDmenutwxtObjects5= [];
gdjs.menuCode.GDplayObjects1= [];
gdjs.menuCode.GDplayObjects2= [];
gdjs.menuCode.GDplayObjects3= [];
gdjs.menuCode.GDplayObjects4= [];
gdjs.menuCode.GDplayObjects5= [];
gdjs.menuCode.GDhatsObjects1= [];
gdjs.menuCode.GDhatsObjects2= [];
gdjs.menuCode.GDhatsObjects3= [];
gdjs.menuCode.GDhatsObjects4= [];
gdjs.menuCode.GDhatsObjects5= [];
gdjs.menuCode.GDstore_9595textObjects1= [];
gdjs.menuCode.GDstore_9595textObjects2= [];
gdjs.menuCode.GDstore_9595textObjects3= [];
gdjs.menuCode.GDstore_9595textObjects4= [];
gdjs.menuCode.GDstore_9595textObjects5= [];
gdjs.menuCode.GDbg_9595textObjects1= [];
gdjs.menuCode.GDbg_9595textObjects2= [];
gdjs.menuCode.GDbg_9595textObjects3= [];
gdjs.menuCode.GDbg_9595textObjects4= [];
gdjs.menuCode.GDbg_9595textObjects5= [];
gdjs.menuCode.GDadd_9595textObjects1= [];
gdjs.menuCode.GDadd_9595textObjects2= [];
gdjs.menuCode.GDadd_9595textObjects3= [];
gdjs.menuCode.GDadd_9595textObjects4= [];
gdjs.menuCode.GDadd_9595textObjects5= [];
gdjs.menuCode.GDhat_9595buttonObjects1= [];
gdjs.menuCode.GDhat_9595buttonObjects2= [];
gdjs.menuCode.GDhat_9595buttonObjects3= [];
gdjs.menuCode.GDhat_9595buttonObjects4= [];
gdjs.menuCode.GDhat_9595buttonObjects5= [];
gdjs.menuCode.GDbgObjects1= [];
gdjs.menuCode.GDbgObjects2= [];
gdjs.menuCode.GDbgObjects3= [];
gdjs.menuCode.GDbgObjects4= [];
gdjs.menuCode.GDbgObjects5= [];
gdjs.menuCode.GDadd_9595buttonObjects1= [];
gdjs.menuCode.GDadd_9595buttonObjects2= [];
gdjs.menuCode.GDadd_9595buttonObjects3= [];
gdjs.menuCode.GDadd_9595buttonObjects4= [];
gdjs.menuCode.GDadd_9595buttonObjects5= [];
gdjs.menuCode.GDstoreObjects1= [];
gdjs.menuCode.GDstoreObjects2= [];
gdjs.menuCode.GDstoreObjects3= [];
gdjs.menuCode.GDstoreObjects4= [];
gdjs.menuCode.GDstoreObjects5= [];
gdjs.menuCode.GDNewSpriteObjects1= [];
gdjs.menuCode.GDNewSpriteObjects2= [];
gdjs.menuCode.GDNewSpriteObjects3= [];
gdjs.menuCode.GDNewSpriteObjects4= [];
gdjs.menuCode.GDNewSpriteObjects5= [];
gdjs.menuCode.GDAre_9595you_9595casualObjects1= [];
gdjs.menuCode.GDAre_9595you_9595casualObjects2= [];
gdjs.menuCode.GDAre_9595you_9595casualObjects3= [];
gdjs.menuCode.GDAre_9595you_9595casualObjects4= [];
gdjs.menuCode.GDAre_9595you_9595casualObjects5= [];
gdjs.menuCode.GDtouch_9595me_9595to_9595playObjects1= [];
gdjs.menuCode.GDtouch_9595me_9595to_9595playObjects2= [];
gdjs.menuCode.GDtouch_9595me_9595to_9595playObjects3= [];
gdjs.menuCode.GDtouch_9595me_9595to_9595playObjects4= [];
gdjs.menuCode.GDtouch_9595me_9595to_9595playObjects5= [];
gdjs.menuCode.GDAre_9595you_9595casual2Objects1= [];
gdjs.menuCode.GDAre_9595you_9595casual2Objects2= [];
gdjs.menuCode.GDAre_9595you_9595casual2Objects3= [];
gdjs.menuCode.GDAre_9595you_9595casual2Objects4= [];
gdjs.menuCode.GDAre_9595you_9595casual2Objects5= [];
gdjs.menuCode.GDtouch_9595me_9595to_9595play2Objects1= [];
gdjs.menuCode.GDtouch_9595me_9595to_9595play2Objects2= [];
gdjs.menuCode.GDtouch_9595me_9595to_9595play2Objects3= [];
gdjs.menuCode.GDtouch_9595me_9595to_9595play2Objects4= [];
gdjs.menuCode.GDtouch_9595me_9595to_9595play2Objects5= [];
gdjs.menuCode.GDgrass_9595blockObjects1= [];
gdjs.menuCode.GDgrass_9595blockObjects2= [];
gdjs.menuCode.GDgrass_9595blockObjects3= [];
gdjs.menuCode.GDgrass_9595blockObjects4= [];
gdjs.menuCode.GDgrass_9595blockObjects5= [];
gdjs.menuCode.GDblockObjects1= [];
gdjs.menuCode.GDblockObjects2= [];
gdjs.menuCode.GDblockObjects3= [];
gdjs.menuCode.GDblockObjects4= [];
gdjs.menuCode.GDblockObjects5= [];
gdjs.menuCode.GDmenuObjects1= [];
gdjs.menuCode.GDmenuObjects2= [];
gdjs.menuCode.GDmenuObjects3= [];
gdjs.menuCode.GDmenuObjects4= [];
gdjs.menuCode.GDmenuObjects5= [];
gdjs.menuCode.GDhomeObjects1= [];
gdjs.menuCode.GDhomeObjects2= [];
gdjs.menuCode.GDhomeObjects3= [];
gdjs.menuCode.GDhomeObjects4= [];
gdjs.menuCode.GDhomeObjects5= [];
gdjs.menuCode.GDresetObjects1= [];
gdjs.menuCode.GDresetObjects2= [];
gdjs.menuCode.GDresetObjects3= [];
gdjs.menuCode.GDresetObjects4= [];
gdjs.menuCode.GDresetObjects5= [];
gdjs.menuCode.GDspikeObjects1= [];
gdjs.menuCode.GDspikeObjects2= [];
gdjs.menuCode.GDspikeObjects3= [];
gdjs.menuCode.GDspikeObjects4= [];
gdjs.menuCode.GDspikeObjects5= [];
gdjs.menuCode.GDend_9595homeObjects1= [];
gdjs.menuCode.GDend_9595homeObjects2= [];
gdjs.menuCode.GDend_9595homeObjects3= [];
gdjs.menuCode.GDend_9595homeObjects4= [];
gdjs.menuCode.GDend_9595homeObjects5= [];
gdjs.menuCode.GDend_9595resetObjects1= [];
gdjs.menuCode.GDend_9595resetObjects2= [];
gdjs.menuCode.GDend_9595resetObjects3= [];
gdjs.menuCode.GDend_9595resetObjects4= [];
gdjs.menuCode.GDend_9595resetObjects5= [];
gdjs.menuCode.GDrobot_9595enemyObjects1= [];
gdjs.menuCode.GDrobot_9595enemyObjects2= [];
gdjs.menuCode.GDrobot_9595enemyObjects3= [];
gdjs.menuCode.GDrobot_9595enemyObjects4= [];
gdjs.menuCode.GDrobot_9595enemyObjects5= [];
gdjs.menuCode.GDslime_9595enemyObjects1= [];
gdjs.menuCode.GDslime_9595enemyObjects2= [];
gdjs.menuCode.GDslime_9595enemyObjects3= [];
gdjs.menuCode.GDslime_9595enemyObjects4= [];
gdjs.menuCode.GDslime_9595enemyObjects5= [];
gdjs.menuCode.GDrob_9595enemy_9595rightObjects1= [];
gdjs.menuCode.GDrob_9595enemy_9595rightObjects2= [];
gdjs.menuCode.GDrob_9595enemy_9595rightObjects3= [];
gdjs.menuCode.GDrob_9595enemy_9595rightObjects4= [];
gdjs.menuCode.GDrob_9595enemy_9595rightObjects5= [];
gdjs.menuCode.GDrob_9595enemy_9595leftObjects1= [];
gdjs.menuCode.GDrob_9595enemy_9595leftObjects2= [];
gdjs.menuCode.GDrob_9595enemy_9595leftObjects3= [];
gdjs.menuCode.GDrob_9595enemy_9595leftObjects4= [];
gdjs.menuCode.GDrob_9595enemy_9595leftObjects5= [];
gdjs.menuCode.GDheroObjects1= [];
gdjs.menuCode.GDheroObjects2= [];
gdjs.menuCode.GDheroObjects3= [];
gdjs.menuCode.GDheroObjects4= [];
gdjs.menuCode.GDheroObjects5= [];
gdjs.menuCode.GDsawObjects1= [];
gdjs.menuCode.GDsawObjects2= [];
gdjs.menuCode.GDsawObjects3= [];
gdjs.menuCode.GDsawObjects4= [];
gdjs.menuCode.GDsawObjects5= [];
gdjs.menuCode.GDcoin_9595markerObjects1= [];
gdjs.menuCode.GDcoin_9595markerObjects2= [];
gdjs.menuCode.GDcoin_9595markerObjects3= [];
gdjs.menuCode.GDcoin_9595markerObjects4= [];
gdjs.menuCode.GDcoin_9595markerObjects5= [];
gdjs.menuCode.GDcoin_9595marker2Objects1= [];
gdjs.menuCode.GDcoin_9595marker2Objects2= [];
gdjs.menuCode.GDcoin_9595marker2Objects3= [];
gdjs.menuCode.GDcoin_9595marker2Objects4= [];
gdjs.menuCode.GDcoin_9595marker2Objects5= [];
gdjs.menuCode.GDcoinsObjects1= [];
gdjs.menuCode.GDcoinsObjects2= [];
gdjs.menuCode.GDcoinsObjects3= [];
gdjs.menuCode.GDcoinsObjects4= [];
gdjs.menuCode.GDcoinsObjects5= [];
gdjs.menuCode.GDcoins2Objects1= [];
gdjs.menuCode.GDcoins2Objects2= [];
gdjs.menuCode.GDcoins2Objects3= [];
gdjs.menuCode.GDcoins2Objects4= [];
gdjs.menuCode.GDcoins2Objects5= [];
gdjs.menuCode.GDkey_9595lockerObjects1= [];
gdjs.menuCode.GDkey_9595lockerObjects2= [];
gdjs.menuCode.GDkey_9595lockerObjects3= [];
gdjs.menuCode.GDkey_9595lockerObjects4= [];
gdjs.menuCode.GDkey_9595lockerObjects5= [];
gdjs.menuCode.GDr_9595buttonObjects1= [];
gdjs.menuCode.GDr_9595buttonObjects2= [];
gdjs.menuCode.GDr_9595buttonObjects3= [];
gdjs.menuCode.GDr_9595buttonObjects4= [];
gdjs.menuCode.GDr_9595buttonObjects5= [];
gdjs.menuCode.GDl_9595buttonObjects1= [];
gdjs.menuCode.GDl_9595buttonObjects2= [];
gdjs.menuCode.GDl_9595buttonObjects3= [];
gdjs.menuCode.GDl_9595buttonObjects4= [];
gdjs.menuCode.GDl_9595buttonObjects5= [];
gdjs.menuCode.GDbackObjects1= [];
gdjs.menuCode.GDbackObjects2= [];
gdjs.menuCode.GDbackObjects3= [];
gdjs.menuCode.GDbackObjects4= [];
gdjs.menuCode.GDbackObjects5= [];
gdjs.menuCode.GDlockObjects1= [];
gdjs.menuCode.GDlockObjects2= [];
gdjs.menuCode.GDlockObjects3= [];
gdjs.menuCode.GDlockObjects4= [];
gdjs.menuCode.GDlockObjects5= [];
gdjs.menuCode.GDcamObjects1= [];
gdjs.menuCode.GDcamObjects2= [];
gdjs.menuCode.GDcamObjects3= [];
gdjs.menuCode.GDcamObjects4= [];
gdjs.menuCode.GDcamObjects5= [];
gdjs.menuCode.GDfonikObjects1= [];
gdjs.menuCode.GDfonikObjects2= [];
gdjs.menuCode.GDfonikObjects3= [];
gdjs.menuCode.GDfonikObjects4= [];
gdjs.menuCode.GDfonikObjects5= [];


gdjs.menuCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{/* Unknown instruction - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimeScale(runtimeScene) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("skin1"), gdjs.menuCode.GDskin1Objects1);
{for(var i = 0, len = gdjs.menuCode.GDskin1Objects1.length ;i < len;++i) {
    gdjs.menuCode.GDskin1Objects1[i].setColor("255;0;0");
}
}}

}


};gdjs.menuCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
{gdjs.evtTools.window.setGameResolutionResizeMode(runtimeScene, "adaptWidth");
}}

}


{



}


};gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDskin1Objects2Objects = Hashtable.newFrom({"skin1": gdjs.menuCode.GDskin1Objects2});
gdjs.menuCode.asyncCallback66842748 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_choose", false);
}}
gdjs.menuCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.menuCode.asyncCallback66842748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDhat_95959595buttonObjects2Objects = Hashtable.newFrom({"hat_button": gdjs.menuCode.GDhat_9595buttonObjects2});
gdjs.menuCode.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 9;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 17;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats2", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 18;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 27;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats3", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 28;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 36;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats4", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 37;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 45;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats5", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 46;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 54;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats6", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 55;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 63;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats7", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 64;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 72;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats8", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 73;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 82;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats9", false);
}}

}


};gdjs.menuCode.asyncCallback66843428 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.menuCode.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.menuCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.menuCode.asyncCallback66843428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDstoreObjects2Objects = Hashtable.newFrom({"store": gdjs.menuCode.GDstoreObjects2});
gdjs.menuCode.asyncCallback66832116 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "store", false);
}}
gdjs.menuCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.menuCode.asyncCallback66832116(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDbgObjects2Objects = Hashtable.newFrom({"bg": gdjs.menuCode.GDbgObjects2});
gdjs.menuCode.asyncCallback66469300 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "fons", false);
}}
gdjs.menuCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.menuCode.asyncCallback66469300(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDadd_95959595buttonObjects2Objects = Hashtable.newFrom({"add_button": gdjs.menuCode.GDadd_9595buttonObjects2});
gdjs.menuCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.menuCode.asyncCallback66459924 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.menuCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.menuCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.menuCode.asyncCallback66459924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.menuCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("skin1"), gdjs.menuCode.GDskin1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDskin1Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.menuCode.GDskin1Objects2 */
{for(var i = 0, len = gdjs.menuCode.GDskin1Objects2.length ;i < len;++i) {
    gdjs.menuCode.GDskin1Objects2[i].setAnimation(gdjs.randomInRange(1, 23));
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true);
}
{ //Subevents
gdjs.menuCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_button"), gdjs.menuCode.GDhat_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDhat_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.menuCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("store"), gdjs.menuCode.GDstoreObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDstoreObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.menuCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bg"), gdjs.menuCode.GDbgObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDbgObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.menuCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("add_button"), gdjs.menuCode.GDadd_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.menuCode.mapOfGDgdjs_9546menuCode_9546GDadd_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66469052);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.menuCode.eventsList8(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.menuCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_button"), gdjs.menuCode.GDhat_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.menuCode.GDhat_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.menuCode.GDhat_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.menuCode.GDhat_9595buttonObjects2[k] = gdjs.menuCode.GDhat_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.menuCode.GDhat_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66798524);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.menuCode.GDhat_9595buttonObjects2 */
{for(var i = 0, len = gdjs.menuCode.GDhat_9595buttonObjects2.length ;i < len;++i) {
    gdjs.menuCode.GDhat_9595buttonObjects2[i].setAnimationName("hat_button");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("bg"), gdjs.menuCode.GDbgObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.menuCode.GDbgObjects2.length;i<l;++i) {
    if ( gdjs.menuCode.GDbgObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.menuCode.GDbgObjects2[k] = gdjs.menuCode.GDbgObjects2[i];
        ++k;
    }
}
gdjs.menuCode.GDbgObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66800660);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.menuCode.GDbgObjects2 */
{for(var i = 0, len = gdjs.menuCode.GDbgObjects2.length ;i < len;++i) {
    gdjs.menuCode.GDbgObjects2[i].setAnimationName("bg");
}
}}

}


{



}


};gdjs.menuCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}}

}


{



}


{


gdjs.menuCode.eventsList0(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cam"), gdjs.menuCode.GDcamObjects1);
{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "hat", runtimeScene, runtimeScene.getScene().getVariables().get("hat"));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("hat")));
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.menuCode.GDcamObjects1.length !== 0 ? gdjs.menuCode.GDcamObjects1[0] : null), true, "hud", 0);
}{for(var i = 0, len = gdjs.menuCode.GDcamObjects1.length ;i < len;++i) {
    gdjs.menuCode.GDcamObjects1[i].hide();
}
}
{ //Subevents
gdjs.menuCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(66841252);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.menuCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


gdjs.menuCode.eventsList10(runtimeScene);
}


};

gdjs.menuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.menuCode.GDskin1Objects1.length = 0;
gdjs.menuCode.GDskin1Objects2.length = 0;
gdjs.menuCode.GDskin1Objects3.length = 0;
gdjs.menuCode.GDskin1Objects4.length = 0;
gdjs.menuCode.GDskin1Objects5.length = 0;
gdjs.menuCode.GDmenutwxtObjects1.length = 0;
gdjs.menuCode.GDmenutwxtObjects2.length = 0;
gdjs.menuCode.GDmenutwxtObjects3.length = 0;
gdjs.menuCode.GDmenutwxtObjects4.length = 0;
gdjs.menuCode.GDmenutwxtObjects5.length = 0;
gdjs.menuCode.GDplayObjects1.length = 0;
gdjs.menuCode.GDplayObjects2.length = 0;
gdjs.menuCode.GDplayObjects3.length = 0;
gdjs.menuCode.GDplayObjects4.length = 0;
gdjs.menuCode.GDplayObjects5.length = 0;
gdjs.menuCode.GDhatsObjects1.length = 0;
gdjs.menuCode.GDhatsObjects2.length = 0;
gdjs.menuCode.GDhatsObjects3.length = 0;
gdjs.menuCode.GDhatsObjects4.length = 0;
gdjs.menuCode.GDhatsObjects5.length = 0;
gdjs.menuCode.GDstore_9595textObjects1.length = 0;
gdjs.menuCode.GDstore_9595textObjects2.length = 0;
gdjs.menuCode.GDstore_9595textObjects3.length = 0;
gdjs.menuCode.GDstore_9595textObjects4.length = 0;
gdjs.menuCode.GDstore_9595textObjects5.length = 0;
gdjs.menuCode.GDbg_9595textObjects1.length = 0;
gdjs.menuCode.GDbg_9595textObjects2.length = 0;
gdjs.menuCode.GDbg_9595textObjects3.length = 0;
gdjs.menuCode.GDbg_9595textObjects4.length = 0;
gdjs.menuCode.GDbg_9595textObjects5.length = 0;
gdjs.menuCode.GDadd_9595textObjects1.length = 0;
gdjs.menuCode.GDadd_9595textObjects2.length = 0;
gdjs.menuCode.GDadd_9595textObjects3.length = 0;
gdjs.menuCode.GDadd_9595textObjects4.length = 0;
gdjs.menuCode.GDadd_9595textObjects5.length = 0;
gdjs.menuCode.GDhat_9595buttonObjects1.length = 0;
gdjs.menuCode.GDhat_9595buttonObjects2.length = 0;
gdjs.menuCode.GDhat_9595buttonObjects3.length = 0;
gdjs.menuCode.GDhat_9595buttonObjects4.length = 0;
gdjs.menuCode.GDhat_9595buttonObjects5.length = 0;
gdjs.menuCode.GDbgObjects1.length = 0;
gdjs.menuCode.GDbgObjects2.length = 0;
gdjs.menuCode.GDbgObjects3.length = 0;
gdjs.menuCode.GDbgObjects4.length = 0;
gdjs.menuCode.GDbgObjects5.length = 0;
gdjs.menuCode.GDadd_9595buttonObjects1.length = 0;
gdjs.menuCode.GDadd_9595buttonObjects2.length = 0;
gdjs.menuCode.GDadd_9595buttonObjects3.length = 0;
gdjs.menuCode.GDadd_9595buttonObjects4.length = 0;
gdjs.menuCode.GDadd_9595buttonObjects5.length = 0;
gdjs.menuCode.GDstoreObjects1.length = 0;
gdjs.menuCode.GDstoreObjects2.length = 0;
gdjs.menuCode.GDstoreObjects3.length = 0;
gdjs.menuCode.GDstoreObjects4.length = 0;
gdjs.menuCode.GDstoreObjects5.length = 0;
gdjs.menuCode.GDNewSpriteObjects1.length = 0;
gdjs.menuCode.GDNewSpriteObjects2.length = 0;
gdjs.menuCode.GDNewSpriteObjects3.length = 0;
gdjs.menuCode.GDNewSpriteObjects4.length = 0;
gdjs.menuCode.GDNewSpriteObjects5.length = 0;
gdjs.menuCode.GDAre_9595you_9595casualObjects1.length = 0;
gdjs.menuCode.GDAre_9595you_9595casualObjects2.length = 0;
gdjs.menuCode.GDAre_9595you_9595casualObjects3.length = 0;
gdjs.menuCode.GDAre_9595you_9595casualObjects4.length = 0;
gdjs.menuCode.GDAre_9595you_9595casualObjects5.length = 0;
gdjs.menuCode.GDtouch_9595me_9595to_9595playObjects1.length = 0;
gdjs.menuCode.GDtouch_9595me_9595to_9595playObjects2.length = 0;
gdjs.menuCode.GDtouch_9595me_9595to_9595playObjects3.length = 0;
gdjs.menuCode.GDtouch_9595me_9595to_9595playObjects4.length = 0;
gdjs.menuCode.GDtouch_9595me_9595to_9595playObjects5.length = 0;
gdjs.menuCode.GDAre_9595you_9595casual2Objects1.length = 0;
gdjs.menuCode.GDAre_9595you_9595casual2Objects2.length = 0;
gdjs.menuCode.GDAre_9595you_9595casual2Objects3.length = 0;
gdjs.menuCode.GDAre_9595you_9595casual2Objects4.length = 0;
gdjs.menuCode.GDAre_9595you_9595casual2Objects5.length = 0;
gdjs.menuCode.GDtouch_9595me_9595to_9595play2Objects1.length = 0;
gdjs.menuCode.GDtouch_9595me_9595to_9595play2Objects2.length = 0;
gdjs.menuCode.GDtouch_9595me_9595to_9595play2Objects3.length = 0;
gdjs.menuCode.GDtouch_9595me_9595to_9595play2Objects4.length = 0;
gdjs.menuCode.GDtouch_9595me_9595to_9595play2Objects5.length = 0;
gdjs.menuCode.GDgrass_9595blockObjects1.length = 0;
gdjs.menuCode.GDgrass_9595blockObjects2.length = 0;
gdjs.menuCode.GDgrass_9595blockObjects3.length = 0;
gdjs.menuCode.GDgrass_9595blockObjects4.length = 0;
gdjs.menuCode.GDgrass_9595blockObjects5.length = 0;
gdjs.menuCode.GDblockObjects1.length = 0;
gdjs.menuCode.GDblockObjects2.length = 0;
gdjs.menuCode.GDblockObjects3.length = 0;
gdjs.menuCode.GDblockObjects4.length = 0;
gdjs.menuCode.GDblockObjects5.length = 0;
gdjs.menuCode.GDmenuObjects1.length = 0;
gdjs.menuCode.GDmenuObjects2.length = 0;
gdjs.menuCode.GDmenuObjects3.length = 0;
gdjs.menuCode.GDmenuObjects4.length = 0;
gdjs.menuCode.GDmenuObjects5.length = 0;
gdjs.menuCode.GDhomeObjects1.length = 0;
gdjs.menuCode.GDhomeObjects2.length = 0;
gdjs.menuCode.GDhomeObjects3.length = 0;
gdjs.menuCode.GDhomeObjects4.length = 0;
gdjs.menuCode.GDhomeObjects5.length = 0;
gdjs.menuCode.GDresetObjects1.length = 0;
gdjs.menuCode.GDresetObjects2.length = 0;
gdjs.menuCode.GDresetObjects3.length = 0;
gdjs.menuCode.GDresetObjects4.length = 0;
gdjs.menuCode.GDresetObjects5.length = 0;
gdjs.menuCode.GDspikeObjects1.length = 0;
gdjs.menuCode.GDspikeObjects2.length = 0;
gdjs.menuCode.GDspikeObjects3.length = 0;
gdjs.menuCode.GDspikeObjects4.length = 0;
gdjs.menuCode.GDspikeObjects5.length = 0;
gdjs.menuCode.GDend_9595homeObjects1.length = 0;
gdjs.menuCode.GDend_9595homeObjects2.length = 0;
gdjs.menuCode.GDend_9595homeObjects3.length = 0;
gdjs.menuCode.GDend_9595homeObjects4.length = 0;
gdjs.menuCode.GDend_9595homeObjects5.length = 0;
gdjs.menuCode.GDend_9595resetObjects1.length = 0;
gdjs.menuCode.GDend_9595resetObjects2.length = 0;
gdjs.menuCode.GDend_9595resetObjects3.length = 0;
gdjs.menuCode.GDend_9595resetObjects4.length = 0;
gdjs.menuCode.GDend_9595resetObjects5.length = 0;
gdjs.menuCode.GDrobot_9595enemyObjects1.length = 0;
gdjs.menuCode.GDrobot_9595enemyObjects2.length = 0;
gdjs.menuCode.GDrobot_9595enemyObjects3.length = 0;
gdjs.menuCode.GDrobot_9595enemyObjects4.length = 0;
gdjs.menuCode.GDrobot_9595enemyObjects5.length = 0;
gdjs.menuCode.GDslime_9595enemyObjects1.length = 0;
gdjs.menuCode.GDslime_9595enemyObjects2.length = 0;
gdjs.menuCode.GDslime_9595enemyObjects3.length = 0;
gdjs.menuCode.GDslime_9595enemyObjects4.length = 0;
gdjs.menuCode.GDslime_9595enemyObjects5.length = 0;
gdjs.menuCode.GDrob_9595enemy_9595rightObjects1.length = 0;
gdjs.menuCode.GDrob_9595enemy_9595rightObjects2.length = 0;
gdjs.menuCode.GDrob_9595enemy_9595rightObjects3.length = 0;
gdjs.menuCode.GDrob_9595enemy_9595rightObjects4.length = 0;
gdjs.menuCode.GDrob_9595enemy_9595rightObjects5.length = 0;
gdjs.menuCode.GDrob_9595enemy_9595leftObjects1.length = 0;
gdjs.menuCode.GDrob_9595enemy_9595leftObjects2.length = 0;
gdjs.menuCode.GDrob_9595enemy_9595leftObjects3.length = 0;
gdjs.menuCode.GDrob_9595enemy_9595leftObjects4.length = 0;
gdjs.menuCode.GDrob_9595enemy_9595leftObjects5.length = 0;
gdjs.menuCode.GDheroObjects1.length = 0;
gdjs.menuCode.GDheroObjects2.length = 0;
gdjs.menuCode.GDheroObjects3.length = 0;
gdjs.menuCode.GDheroObjects4.length = 0;
gdjs.menuCode.GDheroObjects5.length = 0;
gdjs.menuCode.GDsawObjects1.length = 0;
gdjs.menuCode.GDsawObjects2.length = 0;
gdjs.menuCode.GDsawObjects3.length = 0;
gdjs.menuCode.GDsawObjects4.length = 0;
gdjs.menuCode.GDsawObjects5.length = 0;
gdjs.menuCode.GDcoin_9595markerObjects1.length = 0;
gdjs.menuCode.GDcoin_9595markerObjects2.length = 0;
gdjs.menuCode.GDcoin_9595markerObjects3.length = 0;
gdjs.menuCode.GDcoin_9595markerObjects4.length = 0;
gdjs.menuCode.GDcoin_9595markerObjects5.length = 0;
gdjs.menuCode.GDcoin_9595marker2Objects1.length = 0;
gdjs.menuCode.GDcoin_9595marker2Objects2.length = 0;
gdjs.menuCode.GDcoin_9595marker2Objects3.length = 0;
gdjs.menuCode.GDcoin_9595marker2Objects4.length = 0;
gdjs.menuCode.GDcoin_9595marker2Objects5.length = 0;
gdjs.menuCode.GDcoinsObjects1.length = 0;
gdjs.menuCode.GDcoinsObjects2.length = 0;
gdjs.menuCode.GDcoinsObjects3.length = 0;
gdjs.menuCode.GDcoinsObjects4.length = 0;
gdjs.menuCode.GDcoinsObjects5.length = 0;
gdjs.menuCode.GDcoins2Objects1.length = 0;
gdjs.menuCode.GDcoins2Objects2.length = 0;
gdjs.menuCode.GDcoins2Objects3.length = 0;
gdjs.menuCode.GDcoins2Objects4.length = 0;
gdjs.menuCode.GDcoins2Objects5.length = 0;
gdjs.menuCode.GDkey_9595lockerObjects1.length = 0;
gdjs.menuCode.GDkey_9595lockerObjects2.length = 0;
gdjs.menuCode.GDkey_9595lockerObjects3.length = 0;
gdjs.menuCode.GDkey_9595lockerObjects4.length = 0;
gdjs.menuCode.GDkey_9595lockerObjects5.length = 0;
gdjs.menuCode.GDr_9595buttonObjects1.length = 0;
gdjs.menuCode.GDr_9595buttonObjects2.length = 0;
gdjs.menuCode.GDr_9595buttonObjects3.length = 0;
gdjs.menuCode.GDr_9595buttonObjects4.length = 0;
gdjs.menuCode.GDr_9595buttonObjects5.length = 0;
gdjs.menuCode.GDl_9595buttonObjects1.length = 0;
gdjs.menuCode.GDl_9595buttonObjects2.length = 0;
gdjs.menuCode.GDl_9595buttonObjects3.length = 0;
gdjs.menuCode.GDl_9595buttonObjects4.length = 0;
gdjs.menuCode.GDl_9595buttonObjects5.length = 0;
gdjs.menuCode.GDbackObjects1.length = 0;
gdjs.menuCode.GDbackObjects2.length = 0;
gdjs.menuCode.GDbackObjects3.length = 0;
gdjs.menuCode.GDbackObjects4.length = 0;
gdjs.menuCode.GDbackObjects5.length = 0;
gdjs.menuCode.GDlockObjects1.length = 0;
gdjs.menuCode.GDlockObjects2.length = 0;
gdjs.menuCode.GDlockObjects3.length = 0;
gdjs.menuCode.GDlockObjects4.length = 0;
gdjs.menuCode.GDlockObjects5.length = 0;
gdjs.menuCode.GDcamObjects1.length = 0;
gdjs.menuCode.GDcamObjects2.length = 0;
gdjs.menuCode.GDcamObjects3.length = 0;
gdjs.menuCode.GDcamObjects4.length = 0;
gdjs.menuCode.GDcamObjects5.length = 0;
gdjs.menuCode.GDfonikObjects1.length = 0;
gdjs.menuCode.GDfonikObjects2.length = 0;
gdjs.menuCode.GDfonikObjects3.length = 0;
gdjs.menuCode.GDfonikObjects4.length = 0;
gdjs.menuCode.GDfonikObjects5.length = 0;

gdjs.menuCode.eventsList11(runtimeScene);

return;

}

gdjs['menuCode'] = gdjs.menuCode;
