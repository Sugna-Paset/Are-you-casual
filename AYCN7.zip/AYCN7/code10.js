gdjs.hats7Code = {};
gdjs.hats7Code.GDbackObjects2_1final = [];

gdjs.hats7Code.GDl_9595buttonObjects2_1final = [];

gdjs.hats7Code.GDr_9595buttonObjects2_1final = [];

gdjs.hats7Code.GDhat_95950Objects1= [];
gdjs.hats7Code.GDhat_95950Objects2= [];
gdjs.hats7Code.GDhat_95950Objects3= [];
gdjs.hats7Code.GDhat_95950Objects4= [];
gdjs.hats7Code.GDhat_95951Objects1= [];
gdjs.hats7Code.GDhat_95951Objects2= [];
gdjs.hats7Code.GDhat_95951Objects3= [];
gdjs.hats7Code.GDhat_95951Objects4= [];
gdjs.hats7Code.GDhat_95952Objects1= [];
gdjs.hats7Code.GDhat_95952Objects2= [];
gdjs.hats7Code.GDhat_95952Objects3= [];
gdjs.hats7Code.GDhat_95952Objects4= [];
gdjs.hats7Code.GDhat_95953Objects1= [];
gdjs.hats7Code.GDhat_95953Objects2= [];
gdjs.hats7Code.GDhat_95953Objects3= [];
gdjs.hats7Code.GDhat_95953Objects4= [];
gdjs.hats7Code.GDhat_95954Objects1= [];
gdjs.hats7Code.GDhat_95954Objects2= [];
gdjs.hats7Code.GDhat_95954Objects3= [];
gdjs.hats7Code.GDhat_95954Objects4= [];
gdjs.hats7Code.GDhat_95955Objects1= [];
gdjs.hats7Code.GDhat_95955Objects2= [];
gdjs.hats7Code.GDhat_95955Objects3= [];
gdjs.hats7Code.GDhat_95955Objects4= [];
gdjs.hats7Code.GDhat_95956Objects1= [];
gdjs.hats7Code.GDhat_95956Objects2= [];
gdjs.hats7Code.GDhat_95956Objects3= [];
gdjs.hats7Code.GDhat_95956Objects4= [];
gdjs.hats7Code.GDhat_95957Objects1= [];
gdjs.hats7Code.GDhat_95957Objects2= [];
gdjs.hats7Code.GDhat_95957Objects3= [];
gdjs.hats7Code.GDhat_95957Objects4= [];
gdjs.hats7Code.GDhat_95958Objects1= [];
gdjs.hats7Code.GDhat_95958Objects2= [];
gdjs.hats7Code.GDhat_95958Objects3= [];
gdjs.hats7Code.GDhat_95958Objects4= [];
gdjs.hats7Code.GDhat_95959Objects1= [];
gdjs.hats7Code.GDhat_95959Objects2= [];
gdjs.hats7Code.GDhat_95959Objects3= [];
gdjs.hats7Code.GDhat_95959Objects4= [];
gdjs.hats7Code.GDhat_959510Objects1= [];
gdjs.hats7Code.GDhat_959510Objects2= [];
gdjs.hats7Code.GDhat_959510Objects3= [];
gdjs.hats7Code.GDhat_959510Objects4= [];
gdjs.hats7Code.GDhat_959511Objects1= [];
gdjs.hats7Code.GDhat_959511Objects2= [];
gdjs.hats7Code.GDhat_959511Objects3= [];
gdjs.hats7Code.GDhat_959511Objects4= [];
gdjs.hats7Code.GDhat_959512Objects1= [];
gdjs.hats7Code.GDhat_959512Objects2= [];
gdjs.hats7Code.GDhat_959512Objects3= [];
gdjs.hats7Code.GDhat_959512Objects4= [];
gdjs.hats7Code.GDhat_959513Objects1= [];
gdjs.hats7Code.GDhat_959513Objects2= [];
gdjs.hats7Code.GDhat_959513Objects3= [];
gdjs.hats7Code.GDhat_959513Objects4= [];
gdjs.hats7Code.GDhat_959514Objects1= [];
gdjs.hats7Code.GDhat_959514Objects2= [];
gdjs.hats7Code.GDhat_959514Objects3= [];
gdjs.hats7Code.GDhat_959514Objects4= [];
gdjs.hats7Code.GDhat_959515Objects1= [];
gdjs.hats7Code.GDhat_959515Objects2= [];
gdjs.hats7Code.GDhat_959515Objects3= [];
gdjs.hats7Code.GDhat_959515Objects4= [];
gdjs.hats7Code.GDhat_959516Objects1= [];
gdjs.hats7Code.GDhat_959516Objects2= [];
gdjs.hats7Code.GDhat_959516Objects3= [];
gdjs.hats7Code.GDhat_959516Objects4= [];
gdjs.hats7Code.GDhat_959517Objects1= [];
gdjs.hats7Code.GDhat_959517Objects2= [];
gdjs.hats7Code.GDhat_959517Objects3= [];
gdjs.hats7Code.GDhat_959517Objects4= [];
gdjs.hats7Code.GDhat_959518Objects1= [];
gdjs.hats7Code.GDhat_959518Objects2= [];
gdjs.hats7Code.GDhat_959518Objects3= [];
gdjs.hats7Code.GDhat_959518Objects4= [];
gdjs.hats7Code.GDhat_959555Objects1= [];
gdjs.hats7Code.GDhat_959555Objects2= [];
gdjs.hats7Code.GDhat_959555Objects3= [];
gdjs.hats7Code.GDhat_959555Objects4= [];
gdjs.hats7Code.GDhat_959556Objects1= [];
gdjs.hats7Code.GDhat_959556Objects2= [];
gdjs.hats7Code.GDhat_959556Objects3= [];
gdjs.hats7Code.GDhat_959556Objects4= [];
gdjs.hats7Code.GDhat_959557Objects1= [];
gdjs.hats7Code.GDhat_959557Objects2= [];
gdjs.hats7Code.GDhat_959557Objects3= [];
gdjs.hats7Code.GDhat_959557Objects4= [];
gdjs.hats7Code.GDhat_959558Objects1= [];
gdjs.hats7Code.GDhat_959558Objects2= [];
gdjs.hats7Code.GDhat_959558Objects3= [];
gdjs.hats7Code.GDhat_959558Objects4= [];
gdjs.hats7Code.GDhat_959559Objects1= [];
gdjs.hats7Code.GDhat_959559Objects2= [];
gdjs.hats7Code.GDhat_959559Objects3= [];
gdjs.hats7Code.GDhat_959559Objects4= [];
gdjs.hats7Code.GDhat_959560Objects1= [];
gdjs.hats7Code.GDhat_959560Objects2= [];
gdjs.hats7Code.GDhat_959560Objects3= [];
gdjs.hats7Code.GDhat_959560Objects4= [];
gdjs.hats7Code.GDhat_959561Objects1= [];
gdjs.hats7Code.GDhat_959561Objects2= [];
gdjs.hats7Code.GDhat_959561Objects3= [];
gdjs.hats7Code.GDhat_959561Objects4= [];
gdjs.hats7Code.GDhat_959562Objects1= [];
gdjs.hats7Code.GDhat_959562Objects2= [];
gdjs.hats7Code.GDhat_959562Objects3= [];
gdjs.hats7Code.GDhat_959562Objects4= [];
gdjs.hats7Code.GDhat_959563Objects1= [];
gdjs.hats7Code.GDhat_959563Objects2= [];
gdjs.hats7Code.GDhat_959563Objects3= [];
gdjs.hats7Code.GDhat_959563Objects4= [];
gdjs.hats7Code.GDhat_9595randomObjects1= [];
gdjs.hats7Code.GDhat_9595randomObjects2= [];
gdjs.hats7Code.GDhat_9595randomObjects3= [];
gdjs.hats7Code.GDhat_9595randomObjects4= [];
gdjs.hats7Code.GDhat_9595dldoObjects1= [];
gdjs.hats7Code.GDhat_9595dldoObjects2= [];
gdjs.hats7Code.GDhat_9595dldoObjects3= [];
gdjs.hats7Code.GDhat_9595dldoObjects4= [];
gdjs.hats7Code.GDtext_9595pickObjects1= [];
gdjs.hats7Code.GDtext_9595pickObjects2= [];
gdjs.hats7Code.GDtext_9595pickObjects3= [];
gdjs.hats7Code.GDtext_9595pickObjects4= [];
gdjs.hats7Code.GDbuyObjects1= [];
gdjs.hats7Code.GDbuyObjects2= [];
gdjs.hats7Code.GDbuyObjects3= [];
gdjs.hats7Code.GDbuyObjects4= [];
gdjs.hats7Code.GDcostObjects1= [];
gdjs.hats7Code.GDcostObjects2= [];
gdjs.hats7Code.GDcostObjects3= [];
gdjs.hats7Code.GDcostObjects4= [];
gdjs.hats7Code.GDpickerObjects1= [];
gdjs.hats7Code.GDpickerObjects2= [];
gdjs.hats7Code.GDpickerObjects3= [];
gdjs.hats7Code.GDpickerObjects4= [];
gdjs.hats7Code.GDcoin_9595marker_9595hatsObjects1= [];
gdjs.hats7Code.GDcoin_9595marker_9595hatsObjects2= [];
gdjs.hats7Code.GDcoin_9595marker_9595hatsObjects3= [];
gdjs.hats7Code.GDcoin_9595marker_9595hatsObjects4= [];
gdjs.hats7Code.GDgrass_9595blockObjects1= [];
gdjs.hats7Code.GDgrass_9595blockObjects2= [];
gdjs.hats7Code.GDgrass_9595blockObjects3= [];
gdjs.hats7Code.GDgrass_9595blockObjects4= [];
gdjs.hats7Code.GDblockObjects1= [];
gdjs.hats7Code.GDblockObjects2= [];
gdjs.hats7Code.GDblockObjects3= [];
gdjs.hats7Code.GDblockObjects4= [];
gdjs.hats7Code.GDmenuObjects1= [];
gdjs.hats7Code.GDmenuObjects2= [];
gdjs.hats7Code.GDmenuObjects3= [];
gdjs.hats7Code.GDmenuObjects4= [];
gdjs.hats7Code.GDhomeObjects1= [];
gdjs.hats7Code.GDhomeObjects2= [];
gdjs.hats7Code.GDhomeObjects3= [];
gdjs.hats7Code.GDhomeObjects4= [];
gdjs.hats7Code.GDresetObjects1= [];
gdjs.hats7Code.GDresetObjects2= [];
gdjs.hats7Code.GDresetObjects3= [];
gdjs.hats7Code.GDresetObjects4= [];
gdjs.hats7Code.GDspikeObjects1= [];
gdjs.hats7Code.GDspikeObjects2= [];
gdjs.hats7Code.GDspikeObjects3= [];
gdjs.hats7Code.GDspikeObjects4= [];
gdjs.hats7Code.GDend_9595homeObjects1= [];
gdjs.hats7Code.GDend_9595homeObjects2= [];
gdjs.hats7Code.GDend_9595homeObjects3= [];
gdjs.hats7Code.GDend_9595homeObjects4= [];
gdjs.hats7Code.GDend_9595resetObjects1= [];
gdjs.hats7Code.GDend_9595resetObjects2= [];
gdjs.hats7Code.GDend_9595resetObjects3= [];
gdjs.hats7Code.GDend_9595resetObjects4= [];
gdjs.hats7Code.GDrobot_9595enemyObjects1= [];
gdjs.hats7Code.GDrobot_9595enemyObjects2= [];
gdjs.hats7Code.GDrobot_9595enemyObjects3= [];
gdjs.hats7Code.GDrobot_9595enemyObjects4= [];
gdjs.hats7Code.GDslime_9595enemyObjects1= [];
gdjs.hats7Code.GDslime_9595enemyObjects2= [];
gdjs.hats7Code.GDslime_9595enemyObjects3= [];
gdjs.hats7Code.GDslime_9595enemyObjects4= [];
gdjs.hats7Code.GDrob_9595enemy_9595rightObjects1= [];
gdjs.hats7Code.GDrob_9595enemy_9595rightObjects2= [];
gdjs.hats7Code.GDrob_9595enemy_9595rightObjects3= [];
gdjs.hats7Code.GDrob_9595enemy_9595rightObjects4= [];
gdjs.hats7Code.GDrob_9595enemy_9595leftObjects1= [];
gdjs.hats7Code.GDrob_9595enemy_9595leftObjects2= [];
gdjs.hats7Code.GDrob_9595enemy_9595leftObjects3= [];
gdjs.hats7Code.GDrob_9595enemy_9595leftObjects4= [];
gdjs.hats7Code.GDheroObjects1= [];
gdjs.hats7Code.GDheroObjects2= [];
gdjs.hats7Code.GDheroObjects3= [];
gdjs.hats7Code.GDheroObjects4= [];
gdjs.hats7Code.GDsawObjects1= [];
gdjs.hats7Code.GDsawObjects2= [];
gdjs.hats7Code.GDsawObjects3= [];
gdjs.hats7Code.GDsawObjects4= [];
gdjs.hats7Code.GDcoin_9595markerObjects1= [];
gdjs.hats7Code.GDcoin_9595markerObjects2= [];
gdjs.hats7Code.GDcoin_9595markerObjects3= [];
gdjs.hats7Code.GDcoin_9595markerObjects4= [];
gdjs.hats7Code.GDcoin_9595marker2Objects1= [];
gdjs.hats7Code.GDcoin_9595marker2Objects2= [];
gdjs.hats7Code.GDcoin_9595marker2Objects3= [];
gdjs.hats7Code.GDcoin_9595marker2Objects4= [];
gdjs.hats7Code.GDcoinsObjects1= [];
gdjs.hats7Code.GDcoinsObjects2= [];
gdjs.hats7Code.GDcoinsObjects3= [];
gdjs.hats7Code.GDcoinsObjects4= [];
gdjs.hats7Code.GDcoins2Objects1= [];
gdjs.hats7Code.GDcoins2Objects2= [];
gdjs.hats7Code.GDcoins2Objects3= [];
gdjs.hats7Code.GDcoins2Objects4= [];
gdjs.hats7Code.GDkey_9595lockerObjects1= [];
gdjs.hats7Code.GDkey_9595lockerObjects2= [];
gdjs.hats7Code.GDkey_9595lockerObjects3= [];
gdjs.hats7Code.GDkey_9595lockerObjects4= [];
gdjs.hats7Code.GDr_9595buttonObjects1= [];
gdjs.hats7Code.GDr_9595buttonObjects2= [];
gdjs.hats7Code.GDr_9595buttonObjects3= [];
gdjs.hats7Code.GDr_9595buttonObjects4= [];
gdjs.hats7Code.GDl_9595buttonObjects1= [];
gdjs.hats7Code.GDl_9595buttonObjects2= [];
gdjs.hats7Code.GDl_9595buttonObjects3= [];
gdjs.hats7Code.GDl_9595buttonObjects4= [];
gdjs.hats7Code.GDbackObjects1= [];
gdjs.hats7Code.GDbackObjects2= [];
gdjs.hats7Code.GDbackObjects3= [];
gdjs.hats7Code.GDbackObjects4= [];
gdjs.hats7Code.GDlockObjects1= [];
gdjs.hats7Code.GDlockObjects2= [];
gdjs.hats7Code.GDlockObjects3= [];
gdjs.hats7Code.GDlockObjects4= [];
gdjs.hats7Code.GDcamObjects1= [];
gdjs.hats7Code.GDcamObjects2= [];
gdjs.hats7Code.GDcamObjects3= [];
gdjs.hats7Code.GDcamObjects4= [];
gdjs.hats7Code.GDfonikObjects1= [];
gdjs.hats7Code.GDfonikObjects2= [];
gdjs.hats7Code.GDfonikObjects3= [];
gdjs.hats7Code.GDfonikObjects4= [];


gdjs.hats7Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cam"), gdjs.hats7Code.GDcamObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.hats7Code.GDcamObjects1.length !== 0 ? gdjs.hats7Code.GDcamObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.hats7Code.GDcamObjects1.length ;i < len;++i) {
    gdjs.hats7Code.GDcamObjects1[i].hide();
}
}}

}


};gdjs.hats7Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.hats7Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}
{ //Subevents
gdjs.hats7Code.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDbackObjects2Objects = Hashtable.newFrom({"back": gdjs.hats7Code.GDbackObjects2});
gdjs.hats7Code.asyncCallback68098276 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu", false);
}{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}
gdjs.hats7Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.hats7Code.asyncCallback68098276(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDl_95959595buttonObjects2Objects = Hashtable.newFrom({"l_button": gdjs.hats7Code.GDl_9595buttonObjects2});
gdjs.hats7Code.asyncCallback68099548 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats6", false);
}}
gdjs.hats7Code.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))), (runtimeScene) => (gdjs.hats7Code.asyncCallback68099548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDbackObjects3Objects = Hashtable.newFrom({"back": gdjs.hats7Code.GDbackObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDr_95959595buttonObjects3Objects = Hashtable.newFrom({"r_button": gdjs.hats7Code.GDr_9595buttonObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDl_95959595buttonObjects3Objects = Hashtable.newFrom({"l_button": gdjs.hats7Code.GDl_9595buttonObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDr_95959595buttonObjects1Objects = Hashtable.newFrom({"r_button": gdjs.hats7Code.GDr_9595buttonObjects1});
gdjs.hats7Code.asyncCallback68103444 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "hats8", false);
}}
gdjs.hats7Code.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.hats7Code.asyncCallback68103444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.hats7Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hats7Code.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDbackObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats7Code.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hats7Code.GDl_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDl_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats7Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.hats7Code.GDbackObjects2.length = 0;

gdjs.hats7Code.GDl_9595buttonObjects2.length = 0;

gdjs.hats7Code.GDr_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.hats7Code.GDbackObjects2_1final.length = 0;
gdjs.hats7Code.GDl_9595buttonObjects2_1final.length = 0;
gdjs.hats7Code.GDr_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hats7Code.GDbackObjects3);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDbackObjects3Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hats7Code.GDbackObjects3.length; j < jLen ; ++j) {
        if ( gdjs.hats7Code.GDbackObjects2_1final.indexOf(gdjs.hats7Code.GDbackObjects3[j]) === -1 )
            gdjs.hats7Code.GDbackObjects2_1final.push(gdjs.hats7Code.GDbackObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hats7Code.GDr_9595buttonObjects3);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDr_95959595buttonObjects3Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hats7Code.GDr_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.hats7Code.GDr_9595buttonObjects2_1final.indexOf(gdjs.hats7Code.GDr_9595buttonObjects3[j]) === -1 )
            gdjs.hats7Code.GDr_9595buttonObjects2_1final.push(gdjs.hats7Code.GDr_9595buttonObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hats7Code.GDl_9595buttonObjects3);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDl_95959595buttonObjects3Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.hats7Code.GDl_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.hats7Code.GDl_9595buttonObjects2_1final.indexOf(gdjs.hats7Code.GDl_9595buttonObjects3[j]) === -1 )
            gdjs.hats7Code.GDl_9595buttonObjects2_1final.push(gdjs.hats7Code.GDl_9595buttonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.hats7Code.GDbackObjects2_1final, gdjs.hats7Code.GDbackObjects2);
gdjs.copyArray(gdjs.hats7Code.GDl_9595buttonObjects2_1final, gdjs.hats7Code.GDl_9595buttonObjects2);
gdjs.copyArray(gdjs.hats7Code.GDr_9595buttonObjects2_1final, gdjs.hats7Code.GDr_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{

gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hats7Code.GDr_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDr_95959595buttonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats7Code.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68097524);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats7Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959555Objects2Objects = Hashtable.newFrom({"hat_55": gdjs.hats7Code.GDhat_959555Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959556Objects2Objects = Hashtable.newFrom({"hat_56": gdjs.hats7Code.GDhat_959556Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959557Objects2Objects = Hashtable.newFrom({"hat_57": gdjs.hats7Code.GDhat_959557Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959558Objects2Objects = Hashtable.newFrom({"hat_58": gdjs.hats7Code.GDhat_959558Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959559Objects2Objects = Hashtable.newFrom({"hat_59": gdjs.hats7Code.GDhat_959559Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959560Objects2Objects = Hashtable.newFrom({"hat_60": gdjs.hats7Code.GDhat_959560Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959561Objects2Objects = Hashtable.newFrom({"hat_61": gdjs.hats7Code.GDhat_959561Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959562Objects2Objects = Hashtable.newFrom({"hat_62": gdjs.hats7Code.GDhat_959562Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects1Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects1});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959563Objects1Objects = Hashtable.newFrom({"hat_63": gdjs.hats7Code.GDhat_959563Objects1});
gdjs.hats7Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_55"), gdjs.hats7Code.GDhat_959555Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959555Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_55");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_56"), gdjs.hats7Code.GDhat_959556Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959556Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_56");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_57"), gdjs.hats7Code.GDhat_959557Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959557Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_57");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_58"), gdjs.hats7Code.GDhat_959558Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959558Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_58");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_59"), gdjs.hats7Code.GDhat_959559Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959559Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_59");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_60"), gdjs.hats7Code.GDhat_959560Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959560Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_60");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_61"), gdjs.hats7Code.GDhat_959561Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959561Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_61");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_62"), gdjs.hats7Code.GDhat_959562Objects2);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959562Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_62");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDlockObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDlockObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDlockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hat_63"), gdjs.hats7Code.GDhat_959563Objects1);
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects1Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959563Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "hat_63");
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDlockObjects1 */
{for(var i = 0, len = gdjs.hats7Code.GDlockObjects1.length ;i < len;++i) {
    gdjs.hats7Code.GDlockObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.hats7Code.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats7Code.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDbuyObjects2Objects = Hashtable.newFrom({"buy": gdjs.hats7Code.GDbuyObjects2});
gdjs.hats7Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("key_locker"), gdjs.hats7Code.GDkey_9595lockerObjects3);
/* Reuse gdjs.hats7Code.GDlockObjects3 */
{for(var i = 0, len = gdjs.hats7Code.GDkey_9595lockerObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDkey_9595lockerObjects3[i].setPosition((( gdjs.hats7Code.GDlockObjects3.length === 0 ) ? 0 :gdjs.hats7Code.GDlockObjects3[0].getCenterXInScene()),(( gdjs.hats7Code.GDlockObjects3.length === 0 ) ? 0 :gdjs.hats7Code.GDlockObjects3[0].getCenterYInScene()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("buy"), gdjs.hats7Code.GDbuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDbuyObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects2);
gdjs.copyArray(runtimeScene.getObjects("key_locker"), gdjs.hats7Code.GDkey_9595lockerObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDkey_9595lockerObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDkey_9595lockerObjects2[i].setPosition(999,-(999));
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects2[i].setString("...");
}
}}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDbuyObjects2Objects = Hashtable.newFrom({"buy": gdjs.hats7Code.GDbuyObjects2});
gdjs.hats7Code.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats7Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats7Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats7Code.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats7Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats7Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats7Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats7Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats7Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats7Code.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats7Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats7Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats7Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats7Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats7Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats7Code.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats7Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats7Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats7Code.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats7Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats7Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats7Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats7Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats7Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats7Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats7Code.GDcoins2Objects3);
{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "coin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}{for(var i = 0, len = gdjs.hats7Code.GDcoins2Objects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcoins2Objects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};gdjs.hats7Code.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 55;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats7Code.GDcostObjects2, gdjs.hats7Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_55", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats7Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats7Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats7Code.eventsList11(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 56;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats7Code.GDcostObjects2, gdjs.hats7Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_56", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats7Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats7Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats7Code.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 57;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats7Code.GDcostObjects2, gdjs.hats7Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_57", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats7Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats7Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats7Code.eventsList13(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 58;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats7Code.GDcostObjects2, gdjs.hats7Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_58", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats7Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats7Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats7Code.eventsList14(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 59;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats7Code.GDcostObjects2, gdjs.hats7Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_59", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats7Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats7Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats7Code.eventsList15(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 60;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats7Code.GDcostObjects2, gdjs.hats7Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_60", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats7Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats7Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats7Code.eventsList16(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 61;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats7Code.GDcostObjects2, gdjs.hats7Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_61", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats7Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats7Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats7Code.eventsList17(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 62;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats7Code.GDcostObjects2, gdjs.hats7Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_62", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats7Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats7Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats7Code.eventsList18(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 63;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.hats7Code.GDcostObjects2, gdjs.hats7Code.GDcostObjects3);

{gdjs.evtTools.storage.writeNumberInJSONFile("storage", "hat_63", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.hats7Code.GDcostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats7Code.GDcostObjects3[0].getVariables()).getFromIndex(0))));
}
{ //Subevents
gdjs.hats7Code.eventsList19(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.hats7Code.GDcostObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects2[i].returnVariable(gdjs.hats7Code.GDcostObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects2[i].returnVariable(gdjs.hats7Code.GDcostObjects2[i].getVariables().getFromIndex(0)).setString("ok");
}
}}

}


};gdjs.hats7Code.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("buy"), gdjs.hats7Code.GDbuyObjects2);
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDbuyObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.hats7Code.GDcostObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.hats7Code.GDcostObjects2[0].getVariables()).getFromIndex(0)));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats7Code.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959555Objects2Objects = Hashtable.newFrom({"hat_55": gdjs.hats7Code.GDhat_959555Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959555Objects3Objects = Hashtable.newFrom({"hat_55": gdjs.hats7Code.GDhat_959555Objects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959555Objects2Objects = Hashtable.newFrom({"hat_55": gdjs.hats7Code.GDhat_959555Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats7Code.GDhat_959555Objects2, gdjs.hats7Code.GDhat_959555Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959555Objects3Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].setString("15");
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].returnVariable(gdjs.hats7Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(15);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(55);
}}

}


{

/* Reuse gdjs.hats7Code.GDhat_959555Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959555Objects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(55);
}}

}


};gdjs.hats7Code.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_55"), gdjs.hats7Code.GDhat_959555Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959555Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats7Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDtext_9595pickObjects2[i].setString("повязка на лоб");
}
}
{ //Subevents
gdjs.hats7Code.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959556Objects2Objects = Hashtable.newFrom({"hat_56": gdjs.hats7Code.GDhat_959556Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959556Objects3Objects = Hashtable.newFrom({"hat_56": gdjs.hats7Code.GDhat_959556Objects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959556Objects2Objects = Hashtable.newFrom({"hat_56": gdjs.hats7Code.GDhat_959556Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats7Code.GDhat_959556Objects2, gdjs.hats7Code.GDhat_959556Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959556Objects3Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].setString("25");
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].returnVariable(gdjs.hats7Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(25);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(56);
}}

}


{

/* Reuse gdjs.hats7Code.GDhat_959556Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959556Objects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(56);
}}

}


};gdjs.hats7Code.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_56"), gdjs.hats7Code.GDhat_959556Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959556Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats7Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDtext_9595pickObjects2[i].setString("безумная кастрюля");
}
}
{ //Subevents
gdjs.hats7Code.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959557Objects2Objects = Hashtable.newFrom({"hat_57": gdjs.hats7Code.GDhat_959557Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959557Objects3Objects = Hashtable.newFrom({"hat_57": gdjs.hats7Code.GDhat_959557Objects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959557Objects2Objects = Hashtable.newFrom({"hat_57": gdjs.hats7Code.GDhat_959557Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats7Code.GDhat_959557Objects2, gdjs.hats7Code.GDhat_959557Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959557Objects3Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].setString("50");
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].returnVariable(gdjs.hats7Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(57);
}}

}


{

/* Reuse gdjs.hats7Code.GDhat_959557Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959557Objects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(57);
}}

}


};gdjs.hats7Code.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_57"), gdjs.hats7Code.GDhat_959557Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959557Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats7Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDtext_9595pickObjects2[i].setString("глаз решимости");
}
}
{ //Subevents
gdjs.hats7Code.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959558Objects2Objects = Hashtable.newFrom({"hat_58": gdjs.hats7Code.GDhat_959558Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959558Objects3Objects = Hashtable.newFrom({"hat_58": gdjs.hats7Code.GDhat_959558Objects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959558Objects2Objects = Hashtable.newFrom({"hat_58": gdjs.hats7Code.GDhat_959558Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats7Code.GDhat_959558Objects2, gdjs.hats7Code.GDhat_959558Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959558Objects3Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].setString("40");
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].returnVariable(gdjs.hats7Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(40);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(58);
}}

}


{

/* Reuse gdjs.hats7Code.GDhat_959558Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959558Objects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(58);
}}

}


};gdjs.hats7Code.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_58"), gdjs.hats7Code.GDhat_959558Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959558Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats7Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDtext_9595pickObjects2[i].setString("пакет на голову");
}
}
{ //Subevents
gdjs.hats7Code.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959559Objects2Objects = Hashtable.newFrom({"hat_59": gdjs.hats7Code.GDhat_959559Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959559Objects3Objects = Hashtable.newFrom({"hat_59": gdjs.hats7Code.GDhat_959559Objects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959559Objects2Objects = Hashtable.newFrom({"hat_59": gdjs.hats7Code.GDhat_959559Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats7Code.GDhat_959559Objects2, gdjs.hats7Code.GDhat_959559Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959559Objects3Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].setString("30");
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].returnVariable(gdjs.hats7Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(30);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(59);
}}

}


{

/* Reuse gdjs.hats7Code.GDhat_959559Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959559Objects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(59);
}}

}


};gdjs.hats7Code.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_59"), gdjs.hats7Code.GDhat_959559Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959559Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats7Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDtext_9595pickObjects2[i].setString("маска на глаза");
}
}
{ //Subevents
gdjs.hats7Code.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959560Objects2Objects = Hashtable.newFrom({"hat_60": gdjs.hats7Code.GDhat_959560Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959560Objects3Objects = Hashtable.newFrom({"hat_60": gdjs.hats7Code.GDhat_959560Objects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959560Objects2Objects = Hashtable.newFrom({"hat_60": gdjs.hats7Code.GDhat_959560Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.eventsList32 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats7Code.GDhat_959560Objects2, gdjs.hats7Code.GDhat_959560Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959560Objects3Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].setString("100");
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].returnVariable(gdjs.hats7Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(100);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(60);
}}

}


{

/* Reuse gdjs.hats7Code.GDhat_959560Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959560Objects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(60);
}}

}


};gdjs.hats7Code.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_60"), gdjs.hats7Code.GDhat_959560Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959560Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats7Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDtext_9595pickObjects2[i].setString("звёздный шлем");
}
}
{ //Subevents
gdjs.hats7Code.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959561Objects2Objects = Hashtable.newFrom({"hat_61": gdjs.hats7Code.GDhat_959561Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959561Objects3Objects = Hashtable.newFrom({"hat_61": gdjs.hats7Code.GDhat_959561Objects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959561Objects2Objects = Hashtable.newFrom({"hat_61": gdjs.hats7Code.GDhat_959561Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats7Code.GDhat_959561Objects2, gdjs.hats7Code.GDhat_959561Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959561Objects3Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].setString("66");
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].returnVariable(gdjs.hats7Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(66);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(61);
}}

}


{

/* Reuse gdjs.hats7Code.GDhat_959561Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959561Objects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(61);
}}

}


};gdjs.hats7Code.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_61"), gdjs.hats7Code.GDhat_959561Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959561Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats7Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDtext_9595pickObjects2[i].setString("маска радости");
}
}
{ //Subevents
gdjs.hats7Code.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959562Objects2Objects = Hashtable.newFrom({"hat_62": gdjs.hats7Code.GDhat_959562Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959562Objects3Objects = Hashtable.newFrom({"hat_62": gdjs.hats7Code.GDhat_959562Objects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects3});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959562Objects2Objects = Hashtable.newFrom({"hat_62": gdjs.hats7Code.GDhat_959562Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats7Code.GDhat_959562Objects2, gdjs.hats7Code.GDhat_959562Objects3);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959562Objects3Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects3);
{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].setString("99");
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects3.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects3[i].returnVariable(gdjs.hats7Code.GDcostObjects3[i].getVariables().getFromIndex(0)).setNumber(99);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(62);
}}

}


{

/* Reuse gdjs.hats7Code.GDhat_959562Objects2 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959562Objects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(62);
}}

}


};gdjs.hats7Code.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_62"), gdjs.hats7Code.GDhat_959562Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959562Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats7Code.GDtext_9595pickObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDtext_9595pickObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDtext_9595pickObjects2[i].setString("маска печали");
}
}
{ //Subevents
gdjs.hats7Code.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959563Objects1Objects = Hashtable.newFrom({"hat_63": gdjs.hats7Code.GDhat_959563Objects1});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959563Objects2Objects = Hashtable.newFrom({"hat_63": gdjs.hats7Code.GDhat_959563Objects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects2});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959563Objects1Objects = Hashtable.newFrom({"hat_63": gdjs.hats7Code.GDhat_959563Objects1});
gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects1Objects = Hashtable.newFrom({"lock": gdjs.hats7Code.GDlockObjects1});
gdjs.hats7Code.eventsList38 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.hats7Code.GDhat_959563Objects1, gdjs.hats7Code.GDhat_959563Objects2);

gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959563Objects2Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects2[i].setString("100");
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects2[i].returnVariable(gdjs.hats7Code.GDcostObjects2[i].getVariables().getFromIndex(0)).setNumber(100);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(63);
}}

}


{

/* Reuse gdjs.hats7Code.GDhat_959563Objects1 */
gdjs.copyArray(runtimeScene.getObjects("lock"), gdjs.hats7Code.GDlockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959563Objects1Objects, gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDlockObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(63);
}}

}


};gdjs.hats7Code.eventsList39 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hat_63"), gdjs.hats7Code.GDhat_959563Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.hats7Code.mapOfGDgdjs_9546hats7Code_9546GDhat_9595959563Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("text_pick"), gdjs.hats7Code.GDtext_9595pickObjects1);
{for(var i = 0, len = gdjs.hats7Code.GDtext_9595pickObjects1.length ;i < len;++i) {
    gdjs.hats7Code.GDtext_9595pickObjects1[i].setString("талант");
}
}
{ //Subevents
gdjs.hats7Code.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.eventsList40 = function(runtimeScene) {

{


gdjs.hats7Code.eventsList10(runtimeScene);
}


{


gdjs.hats7Code.eventsList21(runtimeScene);
}


{


gdjs.hats7Code.eventsList23(runtimeScene);
}


{


gdjs.hats7Code.eventsList25(runtimeScene);
}


{


gdjs.hats7Code.eventsList27(runtimeScene);
}


{


gdjs.hats7Code.eventsList29(runtimeScene);
}


{


gdjs.hats7Code.eventsList31(runtimeScene);
}


{


gdjs.hats7Code.eventsList33(runtimeScene);
}


{


gdjs.hats7Code.eventsList35(runtimeScene);
}


{


gdjs.hats7Code.eventsList37(runtimeScene);
}


{


gdjs.hats7Code.eventsList39(runtimeScene);
}


};gdjs.hats7Code.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68124092);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats7Code.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.eventsList42 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.hats7Code.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hats7Code.GDbackObjects2.length;i<l;++i) {
    if ( gdjs.hats7Code.GDbackObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hats7Code.GDbackObjects2[k] = gdjs.hats7Code.GDbackObjects2[i];
        ++k;
    }
}
gdjs.hats7Code.GDbackObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68169380);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDbackObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDbackObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDbackObjects2[i].setAnimationName("back");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("r_button"), gdjs.hats7Code.GDr_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hats7Code.GDr_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.hats7Code.GDr_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hats7Code.GDr_9595buttonObjects2[k] = gdjs.hats7Code.GDr_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.hats7Code.GDr_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68170212);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDr_9595buttonObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDr_9595buttonObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDr_9595buttonObjects2[i].setAnimationName("r_button");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("l_button"), gdjs.hats7Code.GDl_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.hats7Code.GDl_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.hats7Code.GDl_9595buttonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.hats7Code.GDl_9595buttonObjects2[k] = gdjs.hats7Code.GDl_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.hats7Code.GDl_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68170980);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.hats7Code.GDl_9595buttonObjects2 */
{for(var i = 0, len = gdjs.hats7Code.GDl_9595buttonObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDl_9595buttonObjects2[i].setAnimationName("l_button");
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.hats7Code.eventsList43 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 55;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_55"), gdjs.hats7Code.GDhat_959555Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats7Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDpickerObjects2[i].setPosition((( gdjs.hats7Code.GDhat_959555Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959555Objects2[0].getCenterXInScene()),(( gdjs.hats7Code.GDhat_959555Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959555Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 56;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_56"), gdjs.hats7Code.GDhat_959556Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats7Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDpickerObjects2[i].setPosition((( gdjs.hats7Code.GDhat_959556Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959556Objects2[0].getCenterXInScene()),(( gdjs.hats7Code.GDhat_959556Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959556Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 57;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_57"), gdjs.hats7Code.GDhat_959557Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats7Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDpickerObjects2[i].setPosition((( gdjs.hats7Code.GDhat_959557Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959557Objects2[0].getCenterXInScene()),(( gdjs.hats7Code.GDhat_959557Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959557Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 58;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_58"), gdjs.hats7Code.GDhat_959558Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats7Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDpickerObjects2[i].setPosition((( gdjs.hats7Code.GDhat_959558Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959558Objects2[0].getCenterXInScene()),(( gdjs.hats7Code.GDhat_959558Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959558Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 59;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_59"), gdjs.hats7Code.GDhat_959559Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats7Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDpickerObjects2[i].setPosition((( gdjs.hats7Code.GDhat_959559Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959559Objects2[0].getCenterXInScene()),(( gdjs.hats7Code.GDhat_959559Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959559Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 60;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_60"), gdjs.hats7Code.GDhat_959560Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats7Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDpickerObjects2[i].setPosition((( gdjs.hats7Code.GDhat_959560Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959560Objects2[0].getCenterXInScene()),(( gdjs.hats7Code.GDhat_959560Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959560Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 61;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_61"), gdjs.hats7Code.GDhat_959561Objects2);
gdjs.copyArray(runtimeScene.getObjects("hat_62"), gdjs.hats7Code.GDhat_959562Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats7Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDpickerObjects2[i].setPosition((( gdjs.hats7Code.GDhat_959561Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959561Objects2[0].getCenterXInScene()),(( gdjs.hats7Code.GDhat_959562Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959562Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 62;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_62"), gdjs.hats7Code.GDhat_959562Objects2);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats7Code.GDpickerObjects2);
{for(var i = 0, len = gdjs.hats7Code.GDpickerObjects2.length ;i < len;++i) {
    gdjs.hats7Code.GDpickerObjects2[i].setPosition((( gdjs.hats7Code.GDhat_959562Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959562Objects2[0].getCenterXInScene()),(( gdjs.hats7Code.GDhat_959562Objects2.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959562Objects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 63;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hat_63"), gdjs.hats7Code.GDhat_959563Objects1);
gdjs.copyArray(runtimeScene.getObjects("picker"), gdjs.hats7Code.GDpickerObjects1);
{for(var i = 0, len = gdjs.hats7Code.GDpickerObjects1.length ;i < len;++i) {
    gdjs.hats7Code.GDpickerObjects1[i].setPosition((( gdjs.hats7Code.GDhat_959563Objects1.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959563Objects1[0].getCenterXInScene()),(( gdjs.hats7Code.GDhat_959563Objects1.length === 0 ) ? 0 :gdjs.hats7Code.GDhat_959563Objects1[0].getCenterYInScene()));
}
}}

}


};gdjs.hats7Code.eventsList44 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(68172932);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.hats7Code.eventsList43(runtimeScene);} //End of subevents
}

}


};gdjs.hats7Code.eventsList45 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coins2"), gdjs.hats7Code.GDcoins2Objects1);
gdjs.copyArray(runtimeScene.getObjects("cost"), gdjs.hats7Code.GDcostObjects1);
{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "coin", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{for(var i = 0, len = gdjs.hats7Code.GDcoins2Objects1.length ;i < len;++i) {
    gdjs.hats7Code.GDcoins2Objects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}{for(var i = 0, len = gdjs.hats7Code.GDcostObjects1.length ;i < len;++i) {
    gdjs.hats7Code.GDcostObjects1[i].returnVariable(gdjs.hats7Code.GDcostObjects1[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "hat", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
{ //Subevents
gdjs.hats7Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.hats7Code.eventsList2(runtimeScene);
}


{


gdjs.hats7Code.eventsList7(runtimeScene);
}


{


gdjs.hats7Code.eventsList9(runtimeScene);
}


{


gdjs.hats7Code.eventsList41(runtimeScene);
}


{



}


{


gdjs.hats7Code.eventsList42(runtimeScene);
}


{


gdjs.hats7Code.eventsList44(runtimeScene);
}


};

gdjs.hats7Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.hats7Code.GDhat_95950Objects1.length = 0;
gdjs.hats7Code.GDhat_95950Objects2.length = 0;
gdjs.hats7Code.GDhat_95950Objects3.length = 0;
gdjs.hats7Code.GDhat_95950Objects4.length = 0;
gdjs.hats7Code.GDhat_95951Objects1.length = 0;
gdjs.hats7Code.GDhat_95951Objects2.length = 0;
gdjs.hats7Code.GDhat_95951Objects3.length = 0;
gdjs.hats7Code.GDhat_95951Objects4.length = 0;
gdjs.hats7Code.GDhat_95952Objects1.length = 0;
gdjs.hats7Code.GDhat_95952Objects2.length = 0;
gdjs.hats7Code.GDhat_95952Objects3.length = 0;
gdjs.hats7Code.GDhat_95952Objects4.length = 0;
gdjs.hats7Code.GDhat_95953Objects1.length = 0;
gdjs.hats7Code.GDhat_95953Objects2.length = 0;
gdjs.hats7Code.GDhat_95953Objects3.length = 0;
gdjs.hats7Code.GDhat_95953Objects4.length = 0;
gdjs.hats7Code.GDhat_95954Objects1.length = 0;
gdjs.hats7Code.GDhat_95954Objects2.length = 0;
gdjs.hats7Code.GDhat_95954Objects3.length = 0;
gdjs.hats7Code.GDhat_95954Objects4.length = 0;
gdjs.hats7Code.GDhat_95955Objects1.length = 0;
gdjs.hats7Code.GDhat_95955Objects2.length = 0;
gdjs.hats7Code.GDhat_95955Objects3.length = 0;
gdjs.hats7Code.GDhat_95955Objects4.length = 0;
gdjs.hats7Code.GDhat_95956Objects1.length = 0;
gdjs.hats7Code.GDhat_95956Objects2.length = 0;
gdjs.hats7Code.GDhat_95956Objects3.length = 0;
gdjs.hats7Code.GDhat_95956Objects4.length = 0;
gdjs.hats7Code.GDhat_95957Objects1.length = 0;
gdjs.hats7Code.GDhat_95957Objects2.length = 0;
gdjs.hats7Code.GDhat_95957Objects3.length = 0;
gdjs.hats7Code.GDhat_95957Objects4.length = 0;
gdjs.hats7Code.GDhat_95958Objects1.length = 0;
gdjs.hats7Code.GDhat_95958Objects2.length = 0;
gdjs.hats7Code.GDhat_95958Objects3.length = 0;
gdjs.hats7Code.GDhat_95958Objects4.length = 0;
gdjs.hats7Code.GDhat_95959Objects1.length = 0;
gdjs.hats7Code.GDhat_95959Objects2.length = 0;
gdjs.hats7Code.GDhat_95959Objects3.length = 0;
gdjs.hats7Code.GDhat_95959Objects4.length = 0;
gdjs.hats7Code.GDhat_959510Objects1.length = 0;
gdjs.hats7Code.GDhat_959510Objects2.length = 0;
gdjs.hats7Code.GDhat_959510Objects3.length = 0;
gdjs.hats7Code.GDhat_959510Objects4.length = 0;
gdjs.hats7Code.GDhat_959511Objects1.length = 0;
gdjs.hats7Code.GDhat_959511Objects2.length = 0;
gdjs.hats7Code.GDhat_959511Objects3.length = 0;
gdjs.hats7Code.GDhat_959511Objects4.length = 0;
gdjs.hats7Code.GDhat_959512Objects1.length = 0;
gdjs.hats7Code.GDhat_959512Objects2.length = 0;
gdjs.hats7Code.GDhat_959512Objects3.length = 0;
gdjs.hats7Code.GDhat_959512Objects4.length = 0;
gdjs.hats7Code.GDhat_959513Objects1.length = 0;
gdjs.hats7Code.GDhat_959513Objects2.length = 0;
gdjs.hats7Code.GDhat_959513Objects3.length = 0;
gdjs.hats7Code.GDhat_959513Objects4.length = 0;
gdjs.hats7Code.GDhat_959514Objects1.length = 0;
gdjs.hats7Code.GDhat_959514Objects2.length = 0;
gdjs.hats7Code.GDhat_959514Objects3.length = 0;
gdjs.hats7Code.GDhat_959514Objects4.length = 0;
gdjs.hats7Code.GDhat_959515Objects1.length = 0;
gdjs.hats7Code.GDhat_959515Objects2.length = 0;
gdjs.hats7Code.GDhat_959515Objects3.length = 0;
gdjs.hats7Code.GDhat_959515Objects4.length = 0;
gdjs.hats7Code.GDhat_959516Objects1.length = 0;
gdjs.hats7Code.GDhat_959516Objects2.length = 0;
gdjs.hats7Code.GDhat_959516Objects3.length = 0;
gdjs.hats7Code.GDhat_959516Objects4.length = 0;
gdjs.hats7Code.GDhat_959517Objects1.length = 0;
gdjs.hats7Code.GDhat_959517Objects2.length = 0;
gdjs.hats7Code.GDhat_959517Objects3.length = 0;
gdjs.hats7Code.GDhat_959517Objects4.length = 0;
gdjs.hats7Code.GDhat_959518Objects1.length = 0;
gdjs.hats7Code.GDhat_959518Objects2.length = 0;
gdjs.hats7Code.GDhat_959518Objects3.length = 0;
gdjs.hats7Code.GDhat_959518Objects4.length = 0;
gdjs.hats7Code.GDhat_959555Objects1.length = 0;
gdjs.hats7Code.GDhat_959555Objects2.length = 0;
gdjs.hats7Code.GDhat_959555Objects3.length = 0;
gdjs.hats7Code.GDhat_959555Objects4.length = 0;
gdjs.hats7Code.GDhat_959556Objects1.length = 0;
gdjs.hats7Code.GDhat_959556Objects2.length = 0;
gdjs.hats7Code.GDhat_959556Objects3.length = 0;
gdjs.hats7Code.GDhat_959556Objects4.length = 0;
gdjs.hats7Code.GDhat_959557Objects1.length = 0;
gdjs.hats7Code.GDhat_959557Objects2.length = 0;
gdjs.hats7Code.GDhat_959557Objects3.length = 0;
gdjs.hats7Code.GDhat_959557Objects4.length = 0;
gdjs.hats7Code.GDhat_959558Objects1.length = 0;
gdjs.hats7Code.GDhat_959558Objects2.length = 0;
gdjs.hats7Code.GDhat_959558Objects3.length = 0;
gdjs.hats7Code.GDhat_959558Objects4.length = 0;
gdjs.hats7Code.GDhat_959559Objects1.length = 0;
gdjs.hats7Code.GDhat_959559Objects2.length = 0;
gdjs.hats7Code.GDhat_959559Objects3.length = 0;
gdjs.hats7Code.GDhat_959559Objects4.length = 0;
gdjs.hats7Code.GDhat_959560Objects1.length = 0;
gdjs.hats7Code.GDhat_959560Objects2.length = 0;
gdjs.hats7Code.GDhat_959560Objects3.length = 0;
gdjs.hats7Code.GDhat_959560Objects4.length = 0;
gdjs.hats7Code.GDhat_959561Objects1.length = 0;
gdjs.hats7Code.GDhat_959561Objects2.length = 0;
gdjs.hats7Code.GDhat_959561Objects3.length = 0;
gdjs.hats7Code.GDhat_959561Objects4.length = 0;
gdjs.hats7Code.GDhat_959562Objects1.length = 0;
gdjs.hats7Code.GDhat_959562Objects2.length = 0;
gdjs.hats7Code.GDhat_959562Objects3.length = 0;
gdjs.hats7Code.GDhat_959562Objects4.length = 0;
gdjs.hats7Code.GDhat_959563Objects1.length = 0;
gdjs.hats7Code.GDhat_959563Objects2.length = 0;
gdjs.hats7Code.GDhat_959563Objects3.length = 0;
gdjs.hats7Code.GDhat_959563Objects4.length = 0;
gdjs.hats7Code.GDhat_9595randomObjects1.length = 0;
gdjs.hats7Code.GDhat_9595randomObjects2.length = 0;
gdjs.hats7Code.GDhat_9595randomObjects3.length = 0;
gdjs.hats7Code.GDhat_9595randomObjects4.length = 0;
gdjs.hats7Code.GDhat_9595dldoObjects1.length = 0;
gdjs.hats7Code.GDhat_9595dldoObjects2.length = 0;
gdjs.hats7Code.GDhat_9595dldoObjects3.length = 0;
gdjs.hats7Code.GDhat_9595dldoObjects4.length = 0;
gdjs.hats7Code.GDtext_9595pickObjects1.length = 0;
gdjs.hats7Code.GDtext_9595pickObjects2.length = 0;
gdjs.hats7Code.GDtext_9595pickObjects3.length = 0;
gdjs.hats7Code.GDtext_9595pickObjects4.length = 0;
gdjs.hats7Code.GDbuyObjects1.length = 0;
gdjs.hats7Code.GDbuyObjects2.length = 0;
gdjs.hats7Code.GDbuyObjects3.length = 0;
gdjs.hats7Code.GDbuyObjects4.length = 0;
gdjs.hats7Code.GDcostObjects1.length = 0;
gdjs.hats7Code.GDcostObjects2.length = 0;
gdjs.hats7Code.GDcostObjects3.length = 0;
gdjs.hats7Code.GDcostObjects4.length = 0;
gdjs.hats7Code.GDpickerObjects1.length = 0;
gdjs.hats7Code.GDpickerObjects2.length = 0;
gdjs.hats7Code.GDpickerObjects3.length = 0;
gdjs.hats7Code.GDpickerObjects4.length = 0;
gdjs.hats7Code.GDcoin_9595marker_9595hatsObjects1.length = 0;
gdjs.hats7Code.GDcoin_9595marker_9595hatsObjects2.length = 0;
gdjs.hats7Code.GDcoin_9595marker_9595hatsObjects3.length = 0;
gdjs.hats7Code.GDcoin_9595marker_9595hatsObjects4.length = 0;
gdjs.hats7Code.GDgrass_9595blockObjects1.length = 0;
gdjs.hats7Code.GDgrass_9595blockObjects2.length = 0;
gdjs.hats7Code.GDgrass_9595blockObjects3.length = 0;
gdjs.hats7Code.GDgrass_9595blockObjects4.length = 0;
gdjs.hats7Code.GDblockObjects1.length = 0;
gdjs.hats7Code.GDblockObjects2.length = 0;
gdjs.hats7Code.GDblockObjects3.length = 0;
gdjs.hats7Code.GDblockObjects4.length = 0;
gdjs.hats7Code.GDmenuObjects1.length = 0;
gdjs.hats7Code.GDmenuObjects2.length = 0;
gdjs.hats7Code.GDmenuObjects3.length = 0;
gdjs.hats7Code.GDmenuObjects4.length = 0;
gdjs.hats7Code.GDhomeObjects1.length = 0;
gdjs.hats7Code.GDhomeObjects2.length = 0;
gdjs.hats7Code.GDhomeObjects3.length = 0;
gdjs.hats7Code.GDhomeObjects4.length = 0;
gdjs.hats7Code.GDresetObjects1.length = 0;
gdjs.hats7Code.GDresetObjects2.length = 0;
gdjs.hats7Code.GDresetObjects3.length = 0;
gdjs.hats7Code.GDresetObjects4.length = 0;
gdjs.hats7Code.GDspikeObjects1.length = 0;
gdjs.hats7Code.GDspikeObjects2.length = 0;
gdjs.hats7Code.GDspikeObjects3.length = 0;
gdjs.hats7Code.GDspikeObjects4.length = 0;
gdjs.hats7Code.GDend_9595homeObjects1.length = 0;
gdjs.hats7Code.GDend_9595homeObjects2.length = 0;
gdjs.hats7Code.GDend_9595homeObjects3.length = 0;
gdjs.hats7Code.GDend_9595homeObjects4.length = 0;
gdjs.hats7Code.GDend_9595resetObjects1.length = 0;
gdjs.hats7Code.GDend_9595resetObjects2.length = 0;
gdjs.hats7Code.GDend_9595resetObjects3.length = 0;
gdjs.hats7Code.GDend_9595resetObjects4.length = 0;
gdjs.hats7Code.GDrobot_9595enemyObjects1.length = 0;
gdjs.hats7Code.GDrobot_9595enemyObjects2.length = 0;
gdjs.hats7Code.GDrobot_9595enemyObjects3.length = 0;
gdjs.hats7Code.GDrobot_9595enemyObjects4.length = 0;
gdjs.hats7Code.GDslime_9595enemyObjects1.length = 0;
gdjs.hats7Code.GDslime_9595enemyObjects2.length = 0;
gdjs.hats7Code.GDslime_9595enemyObjects3.length = 0;
gdjs.hats7Code.GDslime_9595enemyObjects4.length = 0;
gdjs.hats7Code.GDrob_9595enemy_9595rightObjects1.length = 0;
gdjs.hats7Code.GDrob_9595enemy_9595rightObjects2.length = 0;
gdjs.hats7Code.GDrob_9595enemy_9595rightObjects3.length = 0;
gdjs.hats7Code.GDrob_9595enemy_9595rightObjects4.length = 0;
gdjs.hats7Code.GDrob_9595enemy_9595leftObjects1.length = 0;
gdjs.hats7Code.GDrob_9595enemy_9595leftObjects2.length = 0;
gdjs.hats7Code.GDrob_9595enemy_9595leftObjects3.length = 0;
gdjs.hats7Code.GDrob_9595enemy_9595leftObjects4.length = 0;
gdjs.hats7Code.GDheroObjects1.length = 0;
gdjs.hats7Code.GDheroObjects2.length = 0;
gdjs.hats7Code.GDheroObjects3.length = 0;
gdjs.hats7Code.GDheroObjects4.length = 0;
gdjs.hats7Code.GDsawObjects1.length = 0;
gdjs.hats7Code.GDsawObjects2.length = 0;
gdjs.hats7Code.GDsawObjects3.length = 0;
gdjs.hats7Code.GDsawObjects4.length = 0;
gdjs.hats7Code.GDcoin_9595markerObjects1.length = 0;
gdjs.hats7Code.GDcoin_9595markerObjects2.length = 0;
gdjs.hats7Code.GDcoin_9595markerObjects3.length = 0;
gdjs.hats7Code.GDcoin_9595markerObjects4.length = 0;
gdjs.hats7Code.GDcoin_9595marker2Objects1.length = 0;
gdjs.hats7Code.GDcoin_9595marker2Objects2.length = 0;
gdjs.hats7Code.GDcoin_9595marker2Objects3.length = 0;
gdjs.hats7Code.GDcoin_9595marker2Objects4.length = 0;
gdjs.hats7Code.GDcoinsObjects1.length = 0;
gdjs.hats7Code.GDcoinsObjects2.length = 0;
gdjs.hats7Code.GDcoinsObjects3.length = 0;
gdjs.hats7Code.GDcoinsObjects4.length = 0;
gdjs.hats7Code.GDcoins2Objects1.length = 0;
gdjs.hats7Code.GDcoins2Objects2.length = 0;
gdjs.hats7Code.GDcoins2Objects3.length = 0;
gdjs.hats7Code.GDcoins2Objects4.length = 0;
gdjs.hats7Code.GDkey_9595lockerObjects1.length = 0;
gdjs.hats7Code.GDkey_9595lockerObjects2.length = 0;
gdjs.hats7Code.GDkey_9595lockerObjects3.length = 0;
gdjs.hats7Code.GDkey_9595lockerObjects4.length = 0;
gdjs.hats7Code.GDr_9595buttonObjects1.length = 0;
gdjs.hats7Code.GDr_9595buttonObjects2.length = 0;
gdjs.hats7Code.GDr_9595buttonObjects3.length = 0;
gdjs.hats7Code.GDr_9595buttonObjects4.length = 0;
gdjs.hats7Code.GDl_9595buttonObjects1.length = 0;
gdjs.hats7Code.GDl_9595buttonObjects2.length = 0;
gdjs.hats7Code.GDl_9595buttonObjects3.length = 0;
gdjs.hats7Code.GDl_9595buttonObjects4.length = 0;
gdjs.hats7Code.GDbackObjects1.length = 0;
gdjs.hats7Code.GDbackObjects2.length = 0;
gdjs.hats7Code.GDbackObjects3.length = 0;
gdjs.hats7Code.GDbackObjects4.length = 0;
gdjs.hats7Code.GDlockObjects1.length = 0;
gdjs.hats7Code.GDlockObjects2.length = 0;
gdjs.hats7Code.GDlockObjects3.length = 0;
gdjs.hats7Code.GDlockObjects4.length = 0;
gdjs.hats7Code.GDcamObjects1.length = 0;
gdjs.hats7Code.GDcamObjects2.length = 0;
gdjs.hats7Code.GDcamObjects3.length = 0;
gdjs.hats7Code.GDcamObjects4.length = 0;
gdjs.hats7Code.GDfonikObjects1.length = 0;
gdjs.hats7Code.GDfonikObjects2.length = 0;
gdjs.hats7Code.GDfonikObjects3.length = 0;
gdjs.hats7Code.GDfonikObjects4.length = 0;

gdjs.hats7Code.eventsList45(runtimeScene);

return;

}

gdjs['hats7Code'] = gdjs.hats7Code;
